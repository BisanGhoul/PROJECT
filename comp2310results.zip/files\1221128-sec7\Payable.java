package java_project_2;
//lour shaltaf 
// 1221128
//7l
//This is a public interface named Payable.
public interface Payable {
	 public boolean isAuthorized();// Declaration of the isAuthorized method.
}