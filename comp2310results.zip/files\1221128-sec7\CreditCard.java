package java_project_2;

//the name lour shaltaf
//the id 1221128
//the lab section 7l
import java.util.Date;
//This class represents a credit card payment and extends the CustomerPayment class while implementing the Payable interface.
class CreditCard extends CustomerPayment implements Payable {
  private double chargingFee; // The charging fee for the credit card payment.
  private Date expiryDate;// The expiry date of the credit card.
//no - argu constructor 
  public CreditCard() {
  }
  // Constructor for creating a CreditCard object with the specified customer name, ID, payment amount, charging fee,
  // and expiry date.
  public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
      super(customerName, customerId, amount);
      this.chargingFee = chargingFee;
      this.expiryDate = expiryDate;
  }

  // the getter and the setter
  public double getChargingFee() {
      return chargingFee;
  }

  public void setChargingFee(double chargingFee) {
      this.chargingFee = chargingFee;
  }

  public Date getExpiryDate() {
      return expiryDate;
  }

  public void setExpiryDate(Date expiryDate) {
      this.expiryDate = expiryDate;
  }
  // Calculate the payment amount for the credit card. In this case, it returns the original amount plus the charging fee.
  @Override
  public double calculatePayment() {
      return getAmount() + chargingFee;
  }
  // Check if the credit card is authorized for payment. It compares the expiry date of the credit card with the current date,
  // and if the expiry date is before or equal to the current date, it is considered authorized.
  @Override
  public boolean isAuthorized() {
      Date currentDate = new Date();
      return(currentDate.compareTo(expiryDate) <= 0);
  }
// Return a string representation of the CreditCard object.
  @Override
  public String toString() {
      return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", " + super.toString() + "]";
  }
}