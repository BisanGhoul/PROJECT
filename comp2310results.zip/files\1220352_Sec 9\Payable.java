package projectone;

public  abstract interface Payable {// an interface its contains an abstract method should do override for it 
 public abstract boolean isAuthorized(); 
}
