//Name:Noor Nasir
//ID:1220769
//Lab Section : 11L
public interface Payable {
	public abstract boolean isAuthorized();
 
}
