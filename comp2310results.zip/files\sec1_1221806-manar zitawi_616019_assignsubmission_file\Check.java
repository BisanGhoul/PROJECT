/*name:manar zitawi
id:1221806
sec 1*/
package project;

public class Check extends CustomerPayment implements Payaple{
	private int accountNumber;
	private double accountBalance;
	private int type;
	public static final int CASHIER = 1, CERTIFIED = 2, PERSONAL = 3;
	
	public Check() {
		
	}
	public Check(String customerName, int customerId, double amount,int accountNumber,double accountBalance, int type) {
	super(customerName,  customerId, amount);
	this.accountNumber=accountNumber;
	this.accountBalance=accountBalance;
	this.type=type;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
	 public boolean isAuthorized() {
	        boolean isAuthorized = (type == CASHIER || accountBalance >= amount);
	        if ((type == CERTIFIED || type == PERSONAL) && accountBalance >= amount)
	        	
			{
				deductAmountFromBalance();
			}

			return isAuthorized;
	    
	 }
	
	@Override
    public double calculatePayment() {
        return super.amount;
    }
	
	public void deductAmountFromBalance() {
		accountBalance -= amount;
	}
	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type
				+ ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}
	
}
