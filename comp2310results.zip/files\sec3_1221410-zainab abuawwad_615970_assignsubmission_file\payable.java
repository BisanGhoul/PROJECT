package lab8;
/*
 * Name: zainab abu awwad
 * Id: 1221410
 * lab: 3
 */
public interface payable {
	public boolean isAuthorized();

}
