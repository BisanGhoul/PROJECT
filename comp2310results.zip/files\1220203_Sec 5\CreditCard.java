//Malak Hamdi Obaid
//1220203 
//Lab section 5
package proj_1220203_sec5;
import java.util.*;

public class CreditCard extends CustomerPayment implements Payable  {
	private double chargingFee;
	private Date expiryDate;
	
	// no arg constructor 
	public CreditCard() {
	}
	// all arg constructor 
	 public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate){
		super(customerName, customerId, amount);
		this.chargingFee=chargingFee;
		this.expiryDate = expiryDate;
	 }
	 //setters and getters 
	  public double getChargingFee() {
		return chargingFee;
	}
	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	//authorized if the expiryDate is greater than or equal to the current date
	@Override
	    public boolean isAuthorized() {
		Date currentDate = new Date();
	    if (expiryDate.compareTo(currentDate) >= 0) {
	        return true;  // Credit card is authorized
	    } else {
	        return false; //Credit card isn't authorized
	    }
	    }
	
	@Override
	 protected double calculatePayment() {
	        return amount+chargingFee;
	    }
	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", customerName="
				+ customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}
	
	

}
