package java_project_2;

//the name lour shaltaf
//the id 1221128
//the lab section 7l

//This class represents a check payment and extends the CustomerPayment class while implementing the Payable interface.
class Check extends CustomerPayment implements Payable {
	  // Constants defining the check types.
  public static final int CASHIER = 1;
  public static final int CERTIFIED = 2;
  public static final int PERSONAL = 3;

  private int accountNumber; // The account number associated with the check.
  private double accountBalance;// The balance in the account.
  private int type;// The type of the check.
  
  public void deductAmountFromBalance() {
      // Deduct the payment amount from the account balance
      setAccountBalance(getAccountBalance() - getAmount());
  }
  
//no _argu constructor 
  public Check() {
  }
  // Constructor for creating a Check object with the specified customer name, ID, payment amount, account number,
  // account balance, and check type.
  public Check(String customerName, int customerId, double amount, int accountNumber, double accountBalance,
          int type) {
      super(customerName, customerId, amount); // Call the superclass constructor to initialize customer-related attributes.
      this.accountNumber = accountNumber;
      this.accountBalance = accountBalance;
      this.type = type;
  }
//getter and setter 
  public int getAccountNumber() {
      return accountNumber;
  }

  public void setAccountNumber(int accountNumber) {
      this.accountNumber = accountNumber;
  }

  public double getAccountBalance() {
      return accountBalance;
  }

  public void setAccountBalance(double accountBalance) {
      this.accountBalance = accountBalance;
  }

  public int getType() {
      return type;
  }

  public void setType(int type) {
      this.type = type;
  }
  // Calculate the payment amount for the check. In this case, it returns the original amount without any modifications.

  @Override
  public double calculatePayment() {
      return getAmount();
  }
  // Check if the check is authorized for payment. It checks if the check type is cashier or if it is certified or personal
  // and the check's amount is less than or equal to the account balance.
  @Override
  public boolean isAuthorized() {
	  deductAmountFromBalance();
      if (type == CASHIER || accountBalance >=0)
    	  return true;
      return false;
  }
// Return a string representation of the Check object.
  @Override
  public String toString() {
      return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type + ", "
              + super.toString() + "]";
  }

}
