package projectjava;
/*sara shrouf
1220481
lap8
*/
import java.util.Date;
public class CreditCard extends CustomerPayment implements Payable{
	private double chargingFee;
	private Date expiryDate;
	
	public CreditCard() {
		super();
		
	}
	public CreditCard(String customerName, int customerId, double amount,double chargingFee,Date expiryDate) {
		super(customerName, customerId, amount);
		this.chargingFee=chargingFee;
		this.expiryDate=expiryDate;
	}
	public double getChargingFee() {
		return chargingFee;
	}
	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	@Override 
	public double calculatePayment() {
	return this.amount+this.chargingFee;

	}
	@Override
	public String toString() {
		return "CreditCard [chargingFee= "+this.chargingFee+" expiryDate= "+this.expiryDate+ super.toString()+"]";
	}
	@Override
	public boolean isAuthorized() {
		int comp=expiryDate.compareTo(new Date());
		
		if(comp>=0) {
			return true;
		}
		else
			return false;
			
	}

}
