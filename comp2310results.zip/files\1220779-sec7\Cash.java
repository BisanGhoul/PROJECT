package projectBzu;

public class Cash extends CustomerPayment {

    private double discountRate;

    public Cash() {
        // Default constructor
    }

    public Cash(String customerName, int customerId, double amount, double discountRate) {
        super(customerName, customerId, amount);
        this.discountRate = discountRate;
    }

    public double getDiscountRate() {
        return discountRate;
    }

    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }

    // Override calculatePayment method from CustomerPayment
    @Override
    public double calculatePayment() {
        return getAmount() - (getAmount() * (discountRate / 100));
    }

    @Override
    void printPaymentInfo() {
        System.out.println(toString() + " Payment " + calculatePayment());
    }

    @Override
    public String toString() {
        return "Cash [discountRate=" + discountRate + "]";
    }
}
