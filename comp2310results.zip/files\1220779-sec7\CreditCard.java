package projectBzu;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable {

    private double chargingFee;
    private Date expiryDate;

    public CreditCard() {
        // Default constructor
    }

    public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
        super(customerName, customerId, amount);
        this.chargingFee = chargingFee;
        this.expiryDate = expiryDate;
    }

    public void setChargingFee(double chargingFee) {
        this.chargingFee = chargingFee;
    }

    public double getChargingFee() {
        return chargingFee;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    @Override
    public double calculatePayment() {
        return getAmount() + chargingFee;
    }

    @Override
    public boolean isAuthorized() {
        return expiryDate.compareTo(new Date()) >= 0;
    }

    @Override
    public String toString() {
        return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + "]";
    }

    @Override
    public void printPaymentInfo() {
  System.out.println(toString()+"Payment "+calculatePayment());
    }
}
