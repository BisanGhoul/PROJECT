//Malak Hamdi Obaid
//1220203 
//Lab section 5
package proj_1220203_sec5;

public  class Cash extends CustomerPayment {
	private double discountRate ;
	
	// no arg constructor 
	public Cash(){	
	}
	
	// all arg constructor 
    public Cash(String customerName, int customerId, double amount , double discountRate) {
		super(customerName, customerId, amount);
		this.discountRate=discountRate;
	}
    //setter and getter 
	public double getDiscountRate() {
		return discountRate;
	}
	
	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}

	@Override
	protected double calculatePayment() {
	return amount-(amount*discountRate/100.0);	
	}

    @Override
	public String toString() {
		return "Cash [discountRate=" + discountRate + ", customerName=" + customerName + ", customerId=" + customerId
			+ ", amount=" + amount + "]";
}


}
