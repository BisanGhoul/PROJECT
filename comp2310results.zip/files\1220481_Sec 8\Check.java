package projectjava;
/*sara shrouf
1220481
lap8
*/
public class Check extends CustomerPayment implements Payable {
	
	public static final int CASHIER=1;
	public static final int CERTIFIED=2;
	public static final int PERSONAL=3;
	private int accountNumber;
	private double accountBalance;
	private int type;
	
	
	public Check() {
		super();
	}
	public Check(String customerName, int customerId, double amount,int accountNumber,double accountBalance,int type) {
		super(customerName, customerId, amount);
		this.accountNumber=accountNumber;
		this.accountBalance=accountBalance;
		this.type=type;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public void deductAmountFromBalance() {
		//if(this.type!=CASHIER) {
			this.accountBalance-=this.amount;
		}
	
	@Override
	public double calculatePayment() {
		return this.amount;
	}
	@Override
	public String toString() {
		return "check [accountNumber= "+this.accountNumber+" accountBalance= "+this.accountBalance+" type= "+this.type+ super.toString()+"]";
				
	}
	@Override
	public boolean isAuthorized() {
		
			
		if(this.type==CASHIER||this.amount<=this.accountBalance) {
			if(this.getType()!=Check.CASHIER) 
				this.deductAmountFromBalance();
		return true;
		}
			
		else return false;
			
		
	}
}
	
	


