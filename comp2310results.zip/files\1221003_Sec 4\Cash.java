package Java_Project;

import java.util.*;

public class Cash extends CustomerPayment {
	
	private double discountRate;
	
public Cash() {
	
}
	
public Cash(String customerName , int customerId ,double amount ,double discountRate) {
	
	super( customerName ,  customerId , amount);
	
	this.discountRate = discountRate;
	
}

@Override

protected double calculatePayment() {
	
	return amount - amount * (discountRate /100.0);
		
}

@Override
public String toString() {
	return "Cash [discountRate=" + discountRate + ", customerName=" + customerName + ", customerId=" + customerId
			+ ", amount=" + amount + "]";
}

public double getDiscountRate() {
	return discountRate;
}

public void setDiscountRate(double discountRate) {
	this.discountRate = discountRate;
}
		

}
