package ProjectPhaze1;

public interface Payable {

 // Abstract method for comparison
	boolean isAuthorized();

	
}
