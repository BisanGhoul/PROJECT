//name: malik arqoup
//id = 1211686
public  abstract class CustomerPayment  implements Comparable<CustomerPayment> {

    protected String customerName ;
    protected   int customerld ;
    protected double amount ;


    public CustomerPayment() {
    }

    public CustomerPayment(String customer_name, int customer_ld,double amount) {
        this.customerName = customer_name;
        this.customerld=customer_ld;
        this.amount=amount;

    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getCustomerld() {
        return customerld;
    }

    public void setCustomerld(int customerld) {
        this.customerld = customerld;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    abstract protected double CalculatePatment();
    public void PrintPaymentinfo(){
        System.out.println(toString()  +"Payment = "+CalculatePatment());    }


    @Override
    public int compareTo(CustomerPayment x){

        if (this.CalculatePatment() > x.CalculatePatment()){
            return -1 ;

        }else if (this.CalculatePatment() < x.CalculatePatment())
        {
            return  1 ;

        }else {

            return 0;

        }
    }

    @Override
    public String toString() {
        return
                "customerName='" + customerName + '\'' +
                        ", customerld=" + customerld +
                        ", amount=" + amount+"]";
    }
}
