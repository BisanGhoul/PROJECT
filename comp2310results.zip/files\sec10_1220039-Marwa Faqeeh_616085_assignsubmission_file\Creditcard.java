//marwa mahmmoud faqeeh 1220039 s10
import java.util.*;;

public class Creditcard extends Customerpayment implements Payable {
	private double chargingFee;
	private Date expiryDate;

	public Creditcard() {

	}

	public Creditcard(String customerName, int customerID, double amount, double chargingFee, Date expiryDate) {
		super(customerName, customerID, amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}

	public double getChargingFee() {
		return chargingFee;
	}

	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public String toString() {
		return "Creditcard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", customerName="
				+ customerName + ", customerID=" + customerID + ", amount=" + amount + "]";
	}

	public double calculatePayment() {
		return amount + chargingFee;

	}

	public boolean isAuthorized() {
		Date d = new Date();
		if (d.compareTo(expiryDate) <= 0)
			return true;
		else
			return false;

	}

}
