//Name: Maen Foqaha - StudentID: 1220847 - Lab Section:2L - Instructor: Dr.Yousef Hassouneh

public interface Payable {
	public boolean isAuthorized();
}
