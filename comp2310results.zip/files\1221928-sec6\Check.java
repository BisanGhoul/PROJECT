/* Name:Dina Daoud
 * ID:1221928
 * Lab Section "6"
 */
package project;
//class Check is a subclass for CustomerPayment implements the Payable interface 
public class Check extends CustomerPayment implements Payable{
	
	private int accountNumber; 
	private double accountBalance;
	private int type;
	final static int CASHIER=1, CERTIFIED=2, PERSONAL=3;  // define constants
	
    //Constructors
	public Check() {
		
	}
	
	public Check(String customerName, int customerId, double amount,int accountNumber, double accountBalance, int type) {
		super(customerName,customerId,amount);
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
	}
    //Setters and Getters
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	
	public double getAccountBalance() {
		return accountBalance;
	}

	public void setType(int type) {
		
	}
	
	public int getType() {
		return type;
	}

	public static int getCashier() {
		return CASHIER;
	}

	public static int getCertified() {
		return CERTIFIED;
	}

	public static int getPersonal() {
		return PERSONAL;
	}
	//this method for deduct amount from accountBalance 
	public void deductAmountFromBalance() {
		if(type == CERTIFIED || type == PERSONAL) {
			accountBalance -= amount;
		}
	}
	
	@Override
	protected double calculatePayment() {  //calculating payment 
		return super.amount;               //Payment = amount
	}
	
	@Override
	public boolean isAuthorized() {      //to return true if it is authorized and false if not
		if((type == CASHIER) || ((getAmount())<=accountBalance)) {
			deductAmountFromBalance();  //calling deductAmountFromBalance method 
			return true;
		}
		else 
			return false;
	}
	
	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type
				+ ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}
	
	
	
	
}


