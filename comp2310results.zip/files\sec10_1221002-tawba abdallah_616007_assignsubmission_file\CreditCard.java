//Name:Tawba Atta Ibrahim Abdallah Id:1221002 Sec:10L.
package projectjava;
import java.util.*;
public class CreditCard extends CustomerPayment implements Payable {
private double chargingFee;
private Date expiryDate;
public CreditCard() {
	super();
	this.chargingFee=0.0;
	this.expiryDate=new Date();
	
}

public CreditCard(String custumerName, int custumerId, double amount,double chargingFee, Date expiryDate) {
	 super(custumerName,custumerId,amount);
	this.chargingFee = chargingFee;
	this.expiryDate = expiryDate;
}
public double getChargingFee() {
	return chargingFee;
}
public void setChargingFee(double chargingFee) {
	this.chargingFee = chargingFee;
}
public Date getExpiryDate() {
	return expiryDate;
}
public void setExpiryDate(Date expiryDate) {
	this.expiryDate = expiryDate;
}
@Override
protected double calculatepayment() {
	return (super.amount+this.chargingFee);
}
@Override
public boolean isAuthorized() {
	Date currentDate=new Date();
	if(expiryDate.getTime()>currentDate.getTime()||expiryDate.getTime()==currentDate.getTime()){
		return true;
	}
	else {
		return false;
	}
}

@Override
public String toString() {
	return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate +super.toString() + " Payment=";
}

}
