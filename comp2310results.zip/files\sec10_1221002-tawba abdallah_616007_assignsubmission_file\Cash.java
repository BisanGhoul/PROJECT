//Name:Tawba Atta Ibrahim Abdallah Id:1221002 Sec:10L.
package projectjava;

public class Cash extends CustomerPayment {
private double discountRate;
	

public Cash() {
	super();
	this.discountRate=0.0;
}


public Cash(String custumerName, int custumerId, double amount,double discountRate) {
	 super(custumerName,custumerId,amount);
	this.discountRate = discountRate;
}

public double getDiscountRate() {
	return discountRate;
}

public void setDiscountRate(double discountRate) {
	this.discountRate = discountRate;
}
@Override
protected double calculatepayment() {
	
	return super.amount-((this.discountRate*super.amount)/100);
}

@Override
public String toString() {
	return "Cash [discountRate=" + discountRate+ super.toString() + " Payment=";
}


}
