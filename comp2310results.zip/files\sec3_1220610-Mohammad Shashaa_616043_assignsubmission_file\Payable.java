package project;
//Name : Mohammad shasha'a     ID : 1220610      lab section : 3;
public interface Payable {
	public boolean isAuthorized();

}
