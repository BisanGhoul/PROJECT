//saleh salameeen
//1211693
//lecture 9

package prj;

public interface Payable <CustomerPayment>{
	
	public boolean isAuthorized() ;
	
}
