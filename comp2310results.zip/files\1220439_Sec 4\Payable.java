/* Tasneem Ali Shelleh 
   1220439
   Lab section : 4 */
package finalProject;

public interface Payable {
	public abstract boolean isAuthorized();

}
