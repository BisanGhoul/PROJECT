//Name: Ali hamdan   ID: 1221227     Lab sec: 9
package javaproject;

public class Cash extends CustomerPayment{
	private double discountRate;
	
	public Cash() {}
	public Cash(String CustomerName, int CustomerId, double amount, double discountRate) {
		super(CustomerName,CustomerId,amount);
		this.discountRate = discountRate;
	}

	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}
	public double calculatePayment() {
        double discountAmount = amount * (discountRate / 100.0);
        return amount - discountAmount;
    }

	@Override
	public String toString() {
		return "Cash [discountRate=" + discountRate + ", customerName=" + customerName + ", customerId=" + customerId
				+ ", amount=" + amount + "]";
	}

	
	
}
