package lab8;
/*
 * Name: zainab abu awwad
 * Id: 1221410
 * lab: 3
 */
public class Cash extends CustomerPayment {
	private double discountRate;
	
	
	public Cash() {
		super();
		
	}

	public Cash(String customerName, int customerId, double amount,double discountRate) {
		super(customerName, customerId, amount);
		this.discountRate=discountRate;
	}

	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}

	@Override
	public String toString() {
		return "Cash [discountRate=" + discountRate +  ",customerName= "+customerName+ ",customerId= "+customerId+ ",amount= "+amount+"]";
	}

	

	@Override
	protected double calculatePyment() {
		double payamount;
		double per ;
		per =(amount*discountRate)/100;
		payamount=amount-per;
		return payamount;
	}
	
	
	

	

}
