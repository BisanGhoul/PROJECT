//NAME = VERONICA WAKILEH ID=1220245  LAB-SECTION=11
package javaproject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
public class Driver {

	public static void main(String[] args) {
		ArrayList <CostumerPayment> PM= new ArrayList<>();
		Check s1= new Check("Rana",7777,400,1111,350,Check.PERSONAL);
		Cash c1=new Cash("Ahmad",4444,150,5.0);
		Check s2 =new Check("Suha",5555,100,1111,200,Check.CASHIER);
		Check s3=new Check ("Rania",7777,600.0,1111,750,Check.CERTIFIED);
		CreditCard CD1 = new CreditCard("Randa",9999,170,20,new Date(124,05,03));
		CreditCard CD2 = new CreditCard("Hani",6666,150,10,new Date(120,06,07));
		if(s1.isAuthorized()) {
			PM.add(s1) ;
		}
		if(s2.isAuthorized())
			PM.add(s2) ;
		if(s3.isAuthorized()) {
			PM.add(s3) ;
		}
		if(CD1.isAuthorized())
			PM.add(CD1) ;
		if(CD2.isAuthorized())
			PM.add(CD2) ;
		PM.add(c1) ;
		
		Collections.sort(PM);
		for(int i=PM.size()-1;i>=0;i--) {
			PM.get(i).printPaymentInfo();
		}
		
		
		
		

	}

}
