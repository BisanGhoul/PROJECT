/*Haytham Hakam Aref Shehadeh
 * 1210991
 * 7L
 * */
package project; 
import java.util.Date; 
class CreditCard extends CustomerPayment implements Payable { 
//define private variables  
 private double charging_fee; 
 private Date expiry_date; 
//default constructer 
 public CreditCard() { 
 } 
//parametrized constructor 
 public CreditCard(String customerName, int customerId, double amount, double charging_fee, Date expiry_date) { 
  super(customerName, customerId, amount); 
  this.charging_fee = charging_fee; 
  this.expiry_date = expiry_date; 
 } 
//define setters and getters 
 public double get_charging_fee() { 
  return charging_fee; 
 } 
 
 public void set_charging_fee(double charging_fee) { 
  this.charging_fee = charging_fee; 
 } 
 
 public Date get_expiry_date() { 
  return expiry_date; 
 } 
 
 public void set_expiry_date(Date expiry_date) { 
  this.expiry_date = expiry_date; 
 } 
//overriden methods 
 @Override 
 public double calculatePayment() { 
  return amount + charging_fee; 
 } 
 
 @Override 
 public boolean isAuthorized() { 
  Date currentDate = new Date(); 
  return expiry_date.compareTo(currentDate) <= 0; 
 } 
 
 @Override 
 public String toString() { 
  return "CreditCard [charging fee=" + charging_fee + ", expiry date=" + expiry_date 
    + ", customer name apologies for the incomplete response. Here's the continuation of the Credit Card.java class:" 
 
    + ", customer id=" + customer_id + ", amount=" + amount + "]"; 
 } 
 
 @Override 
 public int compareTo() { 
  // TODO Auto-generated method stub 
  return 0; 
 } 
}