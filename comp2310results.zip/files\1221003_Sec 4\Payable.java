package Java_Project;

public interface Payable {
	
	public boolean isAuthorized();
	
}
