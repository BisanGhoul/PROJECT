// Name: [ Faris Ahmad Sawalmeh ].
// Id: [ 1220013 ].
// Lap Section No: [ 6L ].

import java.util.*;
public class CreditCard extends CustomerPayment implements Payable{
    double ChargingFee;
    Date expiryDate;

    @Override
    public String toString() {
        return "CreditCard [ChargingFee=" + ChargingFee + ", expiryDate=" + expiryDate + ", customerName="
                + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
    }

    public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
        super(customerName, customerId, amount);
        ChargingFee = chargingFee;
        this.expiryDate = expiryDate;
    }
    public CreditCard() {
        super();
    }

    public double getChargingFee() {
        return ChargingFee;
    }
    public void setChargingFee(double chargingFee) {
        ChargingFee = chargingFee;
    }
    public Date getExpiryDate() {
        return expiryDate;
    }
    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }
    @Override
    public double calculatePayment() {
        return amount + this.ChargingFee;
    }
    @Override
    public boolean isAuthorized() {
        if(this.expiryDate.compareTo(new Date()) >=0){
            return true;
        }
        return false;
    }
}