//Name: SuhaibKhalid || Section 11 || 1220893 
package SuhibProject;

public interface Payable {
	boolean isAuthorized();
	

}
