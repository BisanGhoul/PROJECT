package projectone;

public class Check extends CustomerPayment implements Payable {// check class is sub class of customer class use extends
																// word and implement the interface Payable
	final static int PERSONAL = 3;// define three constants to determine the check type  and its static because in sample run  thats put insted of int check .  this mothod use to use static variable or static method 
	final static int CASHIER = 1;
	final static int CERTFIED = 2;
	private int accountNumber;
	private double accountBalance;
	private int type;

	public Check() {
		super();

	}

	public Check(String customerName, int customerId, double amount, int accountNumber, double accountBalance,
			int type) {
		super(customerName, customerId, amount);
		this.accountBalance = accountBalance;
		this.accountNumber = accountNumber;
		this.type = type;

	}

	public int getAccountNumber() {// seter and getter for all data felied 
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type
				+ ", customerName=" + this.customerName + ", customerId=" + this.customerId + ", amount " + this.amount
				+ "]" + calculatePayment();
	}

	@Override
	public double calculatePayment() { // in this class  also make override for method calculate payment
		return amount;
	}

	public void deductAmountFormBalance() { // this method to deduct the ammout from the account balance 
		if (isAuthorized() == false) {
			setAccountBalance(this.amount - this.accountBalance);
		}
	}

	@Override
	public boolean isAuthorized() { // to check if the check is allowed or not return true or false 
		boolean flag = false;
		if (this.type == 1 || amount <= this.accountBalance) {
			flag = true;
		} else {
			flag = false;
		}
		return flag;

	}
}
