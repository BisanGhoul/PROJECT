package lab8;
/*
 * Name: zainab abu awwad
 * Id: 1221410
 * lab: 3
 */
import java.util.ArrayList;

public class Check extends CustomerPayment implements payable{
    static final int CASHIER=1;
    static final int CERTIFIED=2;
    static final int PERSONAL=3;
	private int accountNumber;
	private double accountBalance;
	private int type;
	
	public Check() {
		super();
		
	}
	public Check(String customerName, int customerId, double amount,int accountNumber,double accountBalance,int type) {
		super(customerName, customerId, amount);
		this.accountNumber=accountNumber;
		this.accountBalance=accountBalance;
		this.type=type;
		
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public void deductAmountFromBalance() {
       
		if(type==PERSONAL||type==CERTIFIED) {
			accountBalance-=amount;
		}
		
			
	
		
	}
	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type + ",customerName= "+customerName+ ",customerId= "+customerId+ ",amount= "+amount+"]";
	}
	
	
	@Override
	public boolean isAuthorized() {
		
		
			
			if(type==CASHIER||amount<=accountBalance ) {
				deductAmountFromBalance();
				
				return true;
			
			}
		
	
		else 
		
		
		    return false;
			
	}
	@Override
	protected double calculatePyment() {
		
		return amount;
	}
	
	
	
	
	
}
