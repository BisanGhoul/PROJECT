//Mustafa Fayed Mustafa Aamar
//1220814
// 4 sec
public abstract class CustomerPyment implements Comparable<CustomerPyment> {
    protected String customerName;
    protected int customerId;
    protected double amount;
    public CustomerPyment(){

    }
    public CustomerPyment(String customerName, int customerId, double amount) {
        this.customerName = customerName;
        this.customerId = customerId;
        this.amount = amount;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
protected abstract double calculatePayment();


    @Override
    public String toString() {
        return "CustomerPyment{" +
                "customerName='" + customerName + '\'' +
                ", customerId=" + customerId +
                ", amount=" + amount +
                '}';
    }

    void printPaymentInfo()
{
    System.out.println(toString() + " payment = " + calculatePayment());
}
public int compareTo(CustomerPyment A)
{
    return Double.compare(A.calculatePayment(),this.calculatePayment());
}

}
