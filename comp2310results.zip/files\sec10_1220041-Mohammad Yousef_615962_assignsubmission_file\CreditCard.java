//Mohammad Yousef
//1220041
//sec10


package project;
import java.util.*;

public class CreditCard extends CustomerPayment implements Payable<CreditCard> {

	private double chargingFee;
	private Date expiryDate;
	
	public CreditCard()
	{
		super();
	}
	public CreditCard(String customerName,int customerId,double amount,double chargingFee,Date expiryDate)
	{
		super(customerName,customerId,amount);
		this.chargingFee=chargingFee;
		this.expiryDate=expiryDate;
		
	}
	public double getChargingFee() {
		return chargingFee;
	}
	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	

	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", customerName="
				+ customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}



	
	
	@Override
	public boolean isAuthorized()
	{
		if (expiryDate.compareTo(new Date())==1 || expiryDate.compareTo(new Date())==0)
		{
			return true;
		}
		else return false;
	}
	
	
	
	
	@Override
	public double calculatePayment()
	{
		if(isAuthorized())
		{
			return this.amount+chargingFee;
		}
		else
			System.out.println("Payment unauthorized, expiry date overdue please try another card");
			return 0;
	}
			
			
			public void printPaymentInfo()
			{
				System.out.println(toString()+"calculated payment="+calculatePayment());
			}
	}
		
	
	
	
	
	
	
	
	
	
	
	
	
	

