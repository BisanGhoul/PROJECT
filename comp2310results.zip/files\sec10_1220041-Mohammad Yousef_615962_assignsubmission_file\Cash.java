//Mohammad Yousef
//1220041
//sec10


package project;

public class Cash extends CustomerPayment {
private double discountRate;
public Cash()
{
	super(); //or it could be implicitly called
}
public Cash( String customerName,int customerId,double amount ,double discountRate)
{
	super(customerName,customerId,amount);
	this.discountRate=discountRate;
}
public double getDiscountRate() {
	return discountRate;
}
public void setDiscountRate(double discountRate) {
	this.discountRate = discountRate;
}




@Override
public String toString() {
	return "Cash [discountRate=" + discountRate + ", customerName=" + customerName + ", customerId=" + customerId
			+ ", amount=" + amount + "]";
}
@Override
public double calculatePayment()
{
	return (this.getAmount() - (discountRate / 100) * this.getAmount());
}
public void printPaymentInfo()
{
	System.out.println(toString()+"calculated payment="+calculatePayment());
}}




