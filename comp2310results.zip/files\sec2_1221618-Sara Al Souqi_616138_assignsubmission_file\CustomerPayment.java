package newProject;

public abstract class CustomerPayment implements Comparable<CustomerPayment>
{
	protected String customerName;
	protected int customerId;
	protected double amount;
	
	public CustomerPayment() {
		
	}
	public CustomerPayment(String customerName, int customerId, double amount) {
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	protected abstract double calculatePayment() ;
	void printPaymentInfo()
	{
		System.out.println(toString());
		System.out.println("Payment = " + calculatePayment());
		
	}
	@Override
	public int compareTo(CustomerPayment CP ) {
		if (calculatePayment() == CP.calculatePayment())
				 return 0; 
			 else if(calculatePayment() < CP.calculatePayment())    
				 return 1;    
			 else    
				 return -1;    
		}
	
	@Override
	public String toString() {
		return "CustomerPayment [customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount
				+ "]";
	}
	
	
}
