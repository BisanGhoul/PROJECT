//Name: Ghada Sawalha id:1220064 labSection:6
package project;

import java.util.Date;
//Creating class CreditCard which is subclass of CustomerPayment" inheriting"
public class CreditCard extends CustomerPayment implements Payable {//we use the Payable interface to check if it isAuthorized 
//Data fields
private double chargingFee;
private Date expiryDate;
//no/arg constructor and calling the super class
CreditCard(){
	super();
}
//arg-constructor
public CreditCard(double chargingFee, Date expiryDate) {
	super();
	this.chargingFee = chargingFee;
	this.expiryDate = expiryDate;
}
//initializes all Data fields in this class and for the super class
public CreditCard(String coustemercustomerName, int customerId, double amount,double chargingFee, Date expiryDate) {
	super(coustemercustomerName, customerId, amount);
	this.chargingFee = chargingFee;
	this.expiryDate = expiryDate;
}
//Generating Setters and Getters for  data fields
public double getChargingFee() {
	return chargingFee;
}
public void setChargingFee(double chargingFee) {
	this.chargingFee = chargingFee;
}
public Date getExpiryDate() {
	return expiryDate;
}
public void setExpiryDate(Date expiryDate) {
	this.expiryDate = expiryDate;
}
//Abstract method to calculatePayment
protected   double calculatePayment() {
	return amount+chargingFee;
}
//toString method for CreditCard class and connect it with the toString at super class
@Override
public String toString() {
	return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + super.toString()+"]";
}
//printing all CreditCard user info
void printPaymentInfo() {
	System.out.println(toString()+"Payment ="+calculatePayment() );
}
//using Payable interface 
public boolean isAuthorized() {
	//check if its expiryDateis greater than or equal to the current date.
	Date currentDate = new Date();
	int comparision = expiryDate.compareTo(currentDate);
	if(comparision>=0) {
		return true;
	}
	else
	return false;
}

}
