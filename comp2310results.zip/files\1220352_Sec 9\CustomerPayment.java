package projectone;

public abstract class CustomerPayment implements Comparable<CustomerPayment> {// the super class of cash and check and creditcard and implements the interface Comparable 
	protected String customerName;// the data filed  in the class 
	protected int customerId;
	protected double amount;

	public CustomerPayment() { // no arg constractor 

	}

	public CustomerPayment(String customerName, int customerId, double amount) { // arg constractor thats give an initial value of the datafileds 
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
	}

	public String getCustomerName() { // setter and getter for all data filed 
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {// to string method 
		return "[customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount
				+ "]";
	}

	protected abstract double calculatePayment(); // this method to calculate the payment its an abstract method make override for it in sub classes

	public void printPaymentInfo() { 
		System.out.println( toString()+"    the payment  :" + calculatePayment() );
	}

	public int compareTo(CustomerPayment other) { // make an override for compareTo method becouse make implement the compareable interface 
		if (this.calculatePayment() > other.calculatePayment())// thats compare according to payment of two objects sort method depends on compare to method to sort the elements in arrays and array list because i need to sort the element in array list of customerPayment in decsending
			return -1;
		if (this.calculatePayment() < other.calculatePayment())// because of this i do that if grater than return  -1  and if less than return 1 if its equal return 0 
			return 1;
		else
			return 0;
		// return Double.compare(this.calculatePayment(), other.calculatePayment()); // also can do it by using the method compar in class double 
	}
}
