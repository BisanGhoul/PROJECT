//Name:Yasmin_Al_Shawawrh
//ID:1220848
//Lecture:3
//Lap:4

package project;

public class Cash extends CustomerPayment {//It is a subclass for the CustomerPayment
	private double discountRate;//private: accessible from this class just
	public Cash() {
		//no-arg constructor 
	}
	public Cash(String customerName, int customerld, double amount,double discountRate) {//constructor with arguments (constructor from the superclass)
		//superclass constructor aren't inherited but we can invoked it by using super keyword
		super(customerName, customerld, amount);//call superclass constructor(with arguments) 
		this.discountRate = discountRate;
	}
	public Cash(double discountRate) {//constructor with arguments (constructor using fields)
		//superclass constructor aren't inherited but we can invoked it by using super keyword
		super();//call superclass constructor(with no-arg) 
		this.discountRate = discountRate;
	}
	public double getDiscountRate() {//The get method returns discountRate value
		return discountRate;
	}
	public void setDiscountRate(double discountRate) {//The set method sets the value 
		this.discountRate = discountRate;
	}
	@Override
	public String toString() {//The toString method returns the String representation of the object
		return "Cash [discountRate=" + discountRate + super.toString()+"]";//we use super to call superclass method
	}
	@Override
	protected double calculatePayment() {//This method is calculated as the payment amount entered minus the discountRate percentage
		return (amount-((amount*discountRate)/100));
	}
}
