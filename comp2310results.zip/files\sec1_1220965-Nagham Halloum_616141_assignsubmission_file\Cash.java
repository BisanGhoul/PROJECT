//subset class to Customer super class
public class Cash extends CustomerPayment{
	private double discountRate;
	
	public Cash() {//no argument constructor
		super();
	}
	
	public Cash(String customerName,int customerId,double amount,double discountRate) {//parametrization constructor
		super(customerName,customerId,amount);//calling parametrization in super class
		this.discountRate = discountRate;
	}
	//setter and getter for properities cash class
	public double getDiscountRate() {
		return discountRate;
	}
	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}
	//the method for calculating payment cash class
	@Override
	public double calculatePayment() {
		return getAmount()-(getAmount()*this.discountRate/100);//payment amount minus the discountRate percentage
	}
	//the to string for cash class
	@Override
	public String toString() {
		return "Cash [discountRate=" + discountRate +"," + super.toString();
	}
	
}
