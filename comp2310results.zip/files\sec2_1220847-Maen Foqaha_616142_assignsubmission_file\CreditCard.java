//Name: Maen Foqaha - StudentID: 1220847 - Lab Section:2L - Instructor: Dr.Yousef Hassouneh
import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable {
	private double chargingFee;
	private Date expiryDate;
	public CreditCard() {
	}
	public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
		super(customerName, customerId, amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}
	public double getChargingFee() {
		return chargingFee;
	}
	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	@Override
	public boolean isAuthorized() {
		boolean flag=false;
		Date currentDate = new Date();
		flag= (!expiryDate.before(currentDate));
		return flag;
		}
	@Override
	protected double calculatePayment() { 
		return amount+chargingFee;
	}
	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + super.toString() + "]";
	}

}