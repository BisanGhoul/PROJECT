package project1;

public class Cash extends CustomerPayment {
	private double discountRate;
	public Cash() {//no_arg constructor
	}
	public Cash(String customerName,int customerId,double amount,double discountRate) {//arg constructor
		super ( customerName,customerId,amount);//calling customerPayment arg constructor
		this.discountRate = discountRate;
	}
	//setters and getters
	public void setDiscountRate(double discountRate) {
		this.discountRate=discountRate;
	}
	public double getDiscountRate() {
		return discountRate;
	}
	//to sting method 
	@Override
	public String toString() {
		return "Cash [discountRate=" + discountRate +",customerName = "+customerName+", customerId = "+customerId+", amount = "+amount +"]";
	}
	
	
	@Override
	protected double calculatePayment() {//implementation for calculatePayment method 
		double calculatePayment = amount-((discountRate/100)* amount);
		return calculatePayment;
	}

}
