/* Name:Dina Daoud
 * ID:1221928
 * Lab Section "6"
 */
package project;
// class Cash is a subclass for CustomerPayment
public class Cash extends CustomerPayment{
	//define data fields
	
	private double discountRate;
    //no-arg constructor to create objects
	public Cash() {

	}
    //Cash constructor
	public Cash(String customerName, int customerId, double amount,double discountRate) {
		super(customerName,customerId,amount);
		this.discountRate = discountRate;
	}
    //Setters and Getters
	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}
	
	public double getDiscountRate() {
		return discountRate;
	}
	
	@Override
    protected double calculatePayment() {            //a method for Calculate the payment 
		return amount - ((amount/100)*discountRate); 
	}

	@Override
	public String toString() {
		return "Cash [discountRate=" + discountRate + ", customerName=" + customerName + ", customerId=" + customerId
				+ ", amount=" + amount + "]";
	}
}
