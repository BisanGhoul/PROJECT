package java_project_2;

//the name lour shaltaf
//the id 1221128
//the lab section 7l

//This class represents a cash payment and extends the CustomerPayment class.
class Cash extends CustomerPayment {
  private double discountRate; // The discount rate for the cash payment.
  //no argument counstructor 
  public Cash() {
  }
  // Constructor for creating a Cash object with the specified customer name, ID, payment amount, and discount rate.
  public Cash(String customerName, int customerId, double amount, double discountRate) {
      super(customerName, customerId, amount);
      this.discountRate = discountRate;
  }
   //getter and setter 
  public double getDiscountRate() {
      return discountRate;
  }

  public void setDiscountRate(double discountRate) {
      this.discountRate = discountRate;
  }
// Calculate the payment amount after applying the discount.
  @Override
  public double calculatePayment() {
      return getAmount() - (getAmount() * (discountRate / 100.0));
  }
  // Return a string representation of the Cash object.
  @Override
  public String toString() {
      return "Cash [discountRate=" + discountRate + ", " + super.toString() + "]";
  }
}
