package projectJava;
public abstract class CustomerPayment implements Comparable<CustomerPayment>{
    protected String customerName ;
    protected int  customerld ;
    protected double amount ;
    
    public CustomerPayment() {}
    
    public CustomerPayment(String customerName,int  customerld,double amount) {
    	this.customerName=customerName;
    	this.customerld = customerld;
    	this.amount=amount;
    	
    }
    
    
    public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getCustomerld() {
		return customerld;
	}

	public void setCustomerld(int customerld) {
		this.customerld = customerld;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
     public int compareTo(CustomerPayment o) {
    	if (this.calculatePayment() > o.calculatePayment())
    		return -1;
    	if (this.calculatePayment() < o.calculatePayment())
    	    return 1;
    	else 
    		return 0;
    }
    protected abstract double calculatePayment ();
    
     void printPaymentlnfo()  {
		System.out.println(toString() + "Payment =  "+ this.calculatePayment());
	}

	@Override
	public String toString() {
		return "CustomerPayment [customerName=" + customerName + ", customerld=" + customerld + ", amount=" + amount
				+ "]";
	}

	

	
		
    
    
}