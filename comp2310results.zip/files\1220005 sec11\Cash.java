package project;

public  class  Cash extends CustomerPayment{
 private double dicountRate;
 
 
 Cash(){
	 
 }
 

public Cash(String name,int customerid,double amount ,double dicountRate) {
	super(name,customerid,amount);
	this.dicountRate = dicountRate;
}


public double getDicountRate() {
	return dicountRate;
}

public void setDicountRate(double dicountRate) {
	this.dicountRate = dicountRate;
}

public double CalculatePayment() {
	return getAmount()-(getAmount()*(this.dicountRate/100.0));
}





@Override
public String toString() {
	return "Cash [discountRate="+this.dicountRate+",customerName="+this.name+",customerId="+this.customerid+",amount="+this.amount+"]";
}





}




 


