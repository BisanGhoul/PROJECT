package project;
/*Ali Mashour Mohammad Kok
 * 1220375
 * Lab 4
 */
import java.util.*;

public class CreditCard extends CustomerPayment implements Payable<CreditCard>  {

	private double ChargingFee;
	private Date expiryDate;
	
	
	@Override
	public String toString() {
		return "CreditCard [ChargingFee=" + ChargingFee + ", expiryDate=" + expiryDate + ", customerName="
				+ customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}
	
	
	public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
		super(customerName, customerId, amount);
		ChargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}
	
	public CreditCard() {
		super();
		ChargingFee = 123;
		this.expiryDate = new Date();
	}
	
	
	public double getChargingFee() {
		return ChargingFee;
	}
	public void setChargingFee(double chargingFee) {
		ChargingFee = chargingFee;
	}
	
	
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	
	@Override
	public double calculatePayment() {
		return amount + this.ChargingFee;
	}
	
	@Override
	public boolean isAuthorized() {
		if(this.expiryDate.equals(new Date()) )
			return true;
		else if(this.expiryDate.after(new Date()))
			return true;
		else
			return false;
	}

	

}
