package project_1;

import java.util.*;
import java.text.SimpleDateFormat;
//import java.text.SimpleDateFormat;
import java.time.LocalDate;
public  class CreditCard extends CustomerPayment implements Payable{
	
	private double chargingFee;
	private Date expiryDate;
	
	CreditCard(){
		
	}
	CreditCard(String customerName, int customerId, double amount,double chargingFee, Date expiryDate) {
		super(customerName,customerId,amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	
	}
	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}
	public double getChargingFee() {
		return chargingFee;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	@Override
	 public double CalculatePayment(){
	 	double payment=amount+chargingFee;
	 	return payment;
	 }
	@Override 
	public boolean isAuthorized() {
		
		return (this.expiryDate).compareTo(new Date())>=0;
	}
	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + "]";
	}
	@Override
	public void PrintInfo() {
		SimpleDateFormat dateFormat=new SimpleDateFormat();
		 System.out.println(toString()+dateFormat.format(expiryDate));
		 System.out.println(CalculatePayment());
	   }
	
}
