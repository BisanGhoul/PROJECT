//Heba Mustafa 1221916
//Lab 4
//Lecture Section 3
package proj_1221916_s4;

public interface Payable {
public boolean isAuthorized();
}
