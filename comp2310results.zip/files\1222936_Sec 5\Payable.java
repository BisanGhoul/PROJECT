package Project1;

public interface Payable {
	public boolean isAuthorized();

}
