//nawras eyad omar yacoob,1221904,sec3,lab5//
package CustomerPackage;

public interface Payable {
	public boolean isAuthorized();
}
