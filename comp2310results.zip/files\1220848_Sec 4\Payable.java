//Name:Yasmin_Al_Shawawrh
//ID:1220848
//Lecture:3
//Lap:4

package project;

public interface Payable {
	public boolean isAuthorized();
}
//In the interface we only declare an abstract methods (public abstract methodName) ,but by default it is 
//abstract so we don't write the word abstract. And declare constants (public static final constantName) 