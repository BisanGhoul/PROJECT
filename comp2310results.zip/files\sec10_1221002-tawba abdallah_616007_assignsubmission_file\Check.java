//Name:Tawba Atta Ibrahim Abdallah Id:1221002 Sec:10L.
package projectjava;

public class Check extends CustomerPayment implements Payable {
public static final int CASHIER=1;
public static final int CERTIFIED=2;
public static final int PERSONAL=3;
private int  accountNumber;
private double accountBalance;
private int type ;
public Check() {
	super();
	this.accountNumber=0;
	this.accountBalance=0.0;
	this.type=0;
}
public Check(String custumerName, int custumerId, double amount,int accountNumber, double accountBalance, int type) {
	 super(custumerName,custumerId,amount);
	this.accountNumber = accountNumber;
	this.accountBalance = accountBalance;
	this.type = type;
	
}
public void deductAmountFromBalance() {
	accountBalance=accountBalance-amount;
	
	
	
}
public int getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}
public double getAccountBalance() {
	
	return accountBalance;
}
public void setAccountBalance(double accountBalance) {
	this.accountBalance = accountBalance;
}
public int getType() {
	return type;
}
public void setType(int type) {
	this.type = type;
}
@Override
protected double calculatepayment() {
	return super.amount;
}
@Override
public boolean isAuthorized() {
	if (this.type==CASHIER||super.amount<=accountBalance) {
		 if(this.type!=CASHIER&&super.amount<=accountBalance) { 
		    deductAmountFromBalance();}
	  return true;
	}else {
		return false;
	}
}
@Override
public String toString() {
	return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type="+type
			+super.toString()+" Payment=";
}


}
