//name: malik arqoup
//id = 1211686
public interface Payable {
    boolean isAuthorized();

}