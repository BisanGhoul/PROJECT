//Mohamed Ahmed Obied
//1210093_7L
public class Check extends  CustomerPayment implements PayAble{
private int AccountNumber ;
private double AccountBalance ;

private int type ;


 static  int  CASHIER=1;
 static  int CERTIFIED=2 ;

 static  int PERSONAL=3 ;

    public Check() {
    }

    public Check(String customerName, int customerld, double amount,
                  int AccountNumber ,double accountBalance, int type) {
        super(customerName, customerld, amount);
        this.AccountBalance = accountBalance;
        this.AccountNumber=AccountNumber ;
        this.type=type ;


    }

    public void setAccountBalance(double accountBalance) {
        this.AccountBalance = accountBalance;
    }

    public void setAccountNumber(int accountNumber) {
        this.AccountNumber = accountNumber;
    }

    public void setType(int type) {
        this.type = type;
    }

    public double getAccountBalance() {
        return AccountBalance;
    }

    public int getAccountNumber() {
        return AccountNumber;
    }

    public int getType() {
        return type;
    }
    public void DeductAmountFromBalance(){

        if (type == CERTIFIED || type == PERSONAL ){

            AccountBalance = getAccountBalance()-getAmount();

        }

    }

    @Override
public boolean isAuthorized(){
    if (getType() == CASHIER ){
        DeductAmountFromBalance();

        return true ;


    }else if ( getAmount() <=getAccountBalance()){
        DeductAmountFromBalance();

        return true;
    }


    else {
        return false ;
    }
}


    @Override
    public double calculatePatment(){

        return getAmount();
    }



    @Override
    public String toString() {
        return "Check[" +
                "AccountNumber=" + AccountNumber +
                ", AccountBalance=" + AccountBalance +
                ", type=" + type +" ,"+
                super.toString();
    }
}
