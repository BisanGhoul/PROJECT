/*Name :Hiba Abu Taha 
 * ID:1221211
 Dr.Yousuf Hasoneh
 */
package myproject22;

	public interface Payable {
		public boolean isAuthorized ( );
	}


