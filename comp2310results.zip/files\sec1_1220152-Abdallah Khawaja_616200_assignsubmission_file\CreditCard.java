//Name :Abdallah Khawaja  ID:1220152   SEC:1   LAB:1
package project1;

import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable {
	private double chargingFee;
	private Date expiryDate;

	public CreditCard() {
	
	}

	public CreditCard(double chargingFee, Date expiryDate) {
		super();
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}

	public CreditCard(String coustemercustomerName, int customerId, double amount, double chargingFee,
			Date expiryDate) {
		super(coustemercustomerName, customerId, amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}

	public double getChargingFee() {
		return chargingFee;
	}

	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	@Override
	protected double calculatePayment() {
		return amount + chargingFee;
	}

	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + super.toString() + "]";
	}
	@Override
	void printPaymentInfo() {
		System.out.println(toString() + "Payment =" + calculatePayment());
	}

	public boolean isAuthorized() {
		Date curentDate = new Date();
		int comparision ;
		comparision = expiryDate.compareTo(curentDate);
		if (comparision >= 0) {
			return true;
		} else
			return false;
	}

}