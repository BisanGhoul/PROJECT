/*Name :Hiba Abu Taha 
 * ID:1221211
Dr:yusuf hasoneh
*/
package myproject22;

public abstract  class CustomerPayment implements Comparable<CustomerPayment> {
	
	protected int customerId;
	protected double amount;
	protected String  customerName;
	
	public CustomerPayment () {
	}
	public CustomerPayment(String  customerName,int customerId,double amount) {
		this.customerId=customerId;
		this.amount=amount;
		this.customerName=customerName;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public double getAmount() {
		return amount;
	}
	
	public void setCustomerName(String  customerName) {
		this.customerName=customerName;
	}
	public void setCustomerId (int customerId ) {
		this.customerId=customerId;
	}
	public void setAmount (double amount ) {
		this.amount=amount;
	}
	protected abstract double calculatePayment () ;
	
	
	public int compareTo(CustomerPayment o) {
		if(calculatePayment()<o.calculatePayment()) {
			return 1;
		}
		else if(calculatePayment()>o.calculatePayment()) {
			return -1;
		}
		else {
			return 0;
		}
	}
	public void printPaymentInfo() {
		System.out.println(toString()+ "Payment = " +calculatePayment ());
	}
	
	public String toString() {
		return "CustomerPayment[customerName=" +customerName+",customerId = "+customerId+",amount" +amount+ "]";
	}
	
}
