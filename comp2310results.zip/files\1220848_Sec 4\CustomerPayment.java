//Name:Yasmin_Al_Shawawrh
//ID:1220848
//Lecture:3
//Lap:4

package project;

public abstract class CustomerPayment implements Comparable<CustomerPayment>{//This class implements the interface Comparable which is defined in java.
	//And it is Comparable based on the value returned by the method calculatePayment().
	
	//protected :accessible from this class , this package , and by a subclass of its class in another package
	protected String customerName;
	protected int customerld;
	protected double amount;
	public CustomerPayment(){
		//no-arg constructor
	}
	public CustomerPayment(String customerName, int customerld, double amount) {//constructor with arguments 
		this.customerName = customerName;
		this.customerld = customerld;
		this.amount = amount;
	}
	public String getCustomerName() {//The get method returns customerName value
		return customerName;
	}
	public void setCustomerName(String customerName) {//The set method sets the value
		this.customerName = customerName;
	}
	public int getCustomerld() {//The get method returns customerld value
		return customerld;
	}
	public void setCustomerld(int customerld) {//The set method sets the value
		this.customerld = customerld;
	}
	public double getAmount() {//The get method returns amount value
		return amount;
	}
	public void setAmount(double amount) {//The set method sets the value
		this.amount = amount;
	}
	@Override
	public String toString() {//The toString method returns the String representation of the object
		return " ,customerName=" + customerName + ", customerld=" + customerld + ", amount=" + amount ;
	}
	protected abstract double calculatePayment();//we define it abstract because we don't need to implement it in the superclass but implement it in the subclasses
	
	void printPaymentInfo() {//prints the properties and calculated payment by calling both the toString() as well as the calculatePayment() methods
		System.out.println(toString()+" Payment = "+calculatePayment());
	}
	@Override
	public int compareTo(CustomerPayment a) {//This method is override and it is compare by the value of payment and it is in descending order
		if(this.calculatePayment()<a.calculatePayment())//if it is less then return 1
			return 1;
		else if(this.calculatePayment()>a.calculatePayment())//if it is greater then return -1
			return -1;
		else return 0;//if equals return 0 
	}
}
