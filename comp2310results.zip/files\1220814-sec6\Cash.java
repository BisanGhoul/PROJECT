//Mustafa Fayed Mustafa Aamar
//1220814
// 4 sec
public class Cash extends CustomerPyment{
    private double discountRate;

    public Cash() {

    }
    public Cash(String customerName, int customerId, double amount, double discountRate) {
        super(customerName, customerId, amount);
        this.discountRate = discountRate;
    }

    public double getDiscountRate() {
        return discountRate;
    }

    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }

    @Override
    public String toString() {
        return "Cash{" +
                "discountRate=" + discountRate +
                ", customerName='" + customerName + '\'' +
                ", customerId=" + customerId +
                ", amount=" + amount +
                '}';
    }

    @Override
    protected double calculatePayment() {
        return getAmount()-(getAmount()*(getDiscountRate()/100));
    }

    @Override
    void printPaymentInfo()
    {
        System.out.println(toString() + " payment = " + calculatePayment());
    }
}
