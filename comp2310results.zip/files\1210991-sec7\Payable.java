/*Haytham Hakam Aref Shehadeh
 * 1210991
 * 7L
 * */
package project;
interface Payable {
    boolean isAuthorized();
}