//Name:Ellen_Izz,ID:1220806,lecture section:3.lab section:5
package project1;

public abstract class CustomerPayment implements Comparable<CustomerPayment>{
	protected String customerName;
	protected int customerId;
	protected double amount;
	
	public CustomerPayment() {
	}
	public CustomerPayment(String customerName, int customerId, double amount) {
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount
				;
	}
	//abstract method in abstract class
	protected abstract double CalculatePayment() ;
	
	
   void printPaymentInfo() {
	   System.out.println(toString()+" ,payment="+CalculatePayment()+"]" );
   }
	public int compareTo(CustomerPayment e) {
		if(CalculatePayment()>e.CalculatePayment())
			return -1;
		else if(CalculatePayment()<e.CalculatePayment())
			return 1;
		else
			return 0;
			
		
	}
 
}
