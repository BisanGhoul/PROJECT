/*
 * String name = "Yazeed Alhaddad";
 * int id = 1221902;
 * int labSec = 2;
 */
package ps;

public interface Payable {public boolean isAuthorized();}
