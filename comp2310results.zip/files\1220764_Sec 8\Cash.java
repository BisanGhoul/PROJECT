package project;

public class Cash extends CustomerPayment  {

	private double discountRate;
	
	public Cash () {
		
	}
	public Cash (String customerName, int customerId, double amount,double discountRate) {
		 super(customerName, customerId, amount);
		this.discountRate= discountRate;
	
	}
	public double getdiscountRate() {
		return discountRate;
	}
	public void setdistcountRate(double discountRate) {
		this.discountRate = discountRate;
	}
	@Override
	public double calculatePayment() {
		
		   return amount-(amount*discountRate/100) ;
	   }
	  @Override
	    public String toString() {
	        return "Cash [discountRate=" + discountRate + ", " + super.toString() + "]";
	    }

}
