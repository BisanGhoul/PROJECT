// Alaa Mansour 1223194 lab section 11

package alaa;

// Interface Payable
interface Payable {
    boolean isAuthorized();
}









