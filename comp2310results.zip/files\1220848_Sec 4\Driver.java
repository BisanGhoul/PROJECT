//Name:Yasmin_Al_Shawawrh
//ID:1220848
//Lecture:3
//Lap:4

package project;
import java.util.*;
public class Driver {

	public static void main(String[] args) {
		ArrayList<CustomerPayment> payments = new ArrayList<>();//The size of the arrayList cannot be modified and we define an array list to fill it with objects 
		CustomerPayment check1 = new Check("Rana",7777,400,1111,350,Check.PERSONAL);//object of a subtype can used whenever it's supertype value is required and this is call polymorphism 
		if (((Check)check1).isAuthorized() )//we add the type casting because the method isAuthorized() is undefined in CustomerPayment class
			payments.add(check1);//we check that if the object is authorized, then add it to the arrayList
		
		CustomerPayment cash = new Cash("Ahmad",4444,150,5.0);
		payments.add(cash);//add it to the arrayList
		
		CustomerPayment check2 = new Check("Suha",5555,100,1111,200,Check.CASHIER);
		if (((Check)check2).isAuthorized() )
			payments.add(check2);//we check that if the object is authorized, then add it to the arrayList
		
		CustomerPayment check3 = new Check("Rania",7777,600.0,1111,750,Check.CERTIFIED);
		if (((Check)check3).isAuthorized() )
			payments.add(check3);//we check that if the object is authorized, then add it to the arrayList
		
		CustomerPayment creditCard1 = new CreditCard("Randa",9999,170,20, new Date(124,05,03));
		if (((CreditCard)creditCard1).isAuthorized())
			payments.add(creditCard1);//we check that if the object is authorized, then add it to the arrayList
		
		CustomerPayment creditCard2 = new CreditCard("Hani",6666,150,10, new Date(120,06,07));
		if (((CreditCard)creditCard2).isAuthorized())
			payments.add(creditCard2);//we check that if the object is authorized, then add it to the arrayList
		Collections.sort(payments);// sort the arrayList. It is sorting in Ascending order so we make the compareTo method sort in descending order then the result is in descending order
		for (int i = 0;i< payments.size();i++)
			payments.get(i).printPaymentInfo();//print the arrayList by calling the method printPaymentInfo()
	}

}
