//Name: Ghada Sawalha id:1220064 labSection:6
package project;
//Creating class Cash which is subclass of CustomerPayment" inheriting"
public class Cash extends CustomerPayment {
//Data fields
private double discountRate;
//no/arg constructor and calling the super class
Cash(){
super();
}
//arg-constructor
public Cash(double discountRate) {
	super();
	this.discountRate = discountRate;
}
//initializes all Data fields in this class and for the super class
public Cash(String coustemercustomerName, int customerId, double amount,double discountRate) {
	super(coustemercustomerName, customerId, amount);
	this.discountRate = discountRate;
	
}
//Generating Setters and Getters for  data fields
public double getDiscountRate() {
	return discountRate;
}

public void setDiscountRate(double discountRate) {
	this.discountRate = discountRate;
}

//Abstract method to calculatePayment
protected   double calculatePayment() {
	double percentage = amount*discountRate/100;
	return amount- percentage;
}
//toString method for Cash class and connect it with the toString at super class
@Override
public String toString() {
	return "Cash [discountRate=" + discountRate + super.toString()+"]";
}
//printing all Cash user info
void printPaymentInfo() {
	System.out.println(toString()+"Payment ="+calculatePayment() );
}



}
