/*name:manar zitawi
id:1221806
sec 1*/
package project;

public interface Payaple {
	public boolean isAuthorized();

}
