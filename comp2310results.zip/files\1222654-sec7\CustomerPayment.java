//Aya abdelrahman fares shejaya ,1222654,lab 7

package proj;


//Abstract class representing a CustomerPayment, implements Payable interface and Comparable interface
public abstract class CustomerPayment implements Comparable<CustomerPayment> {
	 // store the protected customer name, customer ID, and payment amount
    protected String customerName;
    protected int customerId;
    protected double amount;

    // Constructor to initialize customer name, customer ID, and payment amount
    public CustomerPayment(String customerName, int customerId, double amount) {
        this.customerName = customerName;
        this.customerId = customerId;
        this.amount = amount;
    }
    // Abstract method to be implemented by subclasses to calculate payment
    protected abstract double calculatePayment();

    // Prints payment information using toString() method and calculated payment amount
    public void printPaymentInfo() {
        System.out.println(toString() + " Payment = " + calculatePayment());
    }
    
   // Implementation of compareTo method from Comparable interface
    @Override
    public int compareTo(CustomerPayment C) {
       if (calculatePayment()> C.calculatePayment())
    	   return -1;
       else if (calculatePayment() < C.calculatePayment())
    	   return 1;
       else 
    	   return 0;
       
    }

    // Getters and Setters
    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
    // toString method overridden to return an string (to be overridden in subclasses)
    @Override 
    public String toString() {
        return "customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "";
    }
}