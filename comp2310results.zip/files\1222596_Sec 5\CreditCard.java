// Name : Amir Rasmi Al-Rashayda
// ID_Num : 1222596
// LabSec : 5  
    
    // importing the Date class
    import java.util.Date;

    // CreditCard class extends the abstract class CustomerPayment and implements the Payable interface
    public class CreditCard extends CustomerPayment implements Payable {
        // private variables
        private Date expiryDate; // expiry date for credit card payments
        private Double chargingFee; // charging fee for credit card payments

        // full const
        public CreditCard(String customerName, int customerId, double amount,Double chargingFee, Date expiryDate) {
            super(customerName, customerId, amount); // Calling the constructor of the superclass
            this.chargingFee = chargingFee; // initializing chargingFee with the passed value
            this.expiryDate = expiryDate; // initializing expiryDate with the passed value
        }

        // no arg const
        public CreditCard() {

        }

        // getter/setter methods
        public Date getExpiryDate() {
            return expiryDate;
        }

        public void setExpiryDate(Date expiryDate) {
            this.expiryDate = expiryDate;
        }

        public Double getChargingFee() {
            return chargingFee;
        }

        public void setChargingFee(Double chargingFee) {
            this.chargingFee = chargingFee;
        }

        // Overriding the isAuthorized method from the Payable interface
        @Override
        public boolean isAuthorized() {
            //creditCard payment is authorized if its expiryDate is more than or equal to the current date
            return expiryDate.compareTo(new Date()) >= 0;
        }

        //overriding the calculatePayment method from the superclass
        @Override
        protected double calculatePayment() {
            //payment is the amount plus the chargingFee
            return amount + chargingFee;
        }

        // overriding the toString method from the superclass
        @Override
        public String toString() {
            // Returning a string representation of the object
            return "CreditCard [" +
                    "chargingFee=" + chargingFee +
                    ", expiryDate=" + expiryDate +
                    ", customerName=" + customerName +
                    ", customerId=" + customerId +
                    ", amount=" + amount +
                    ']';
        }
    }
