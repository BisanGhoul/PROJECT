/* Name: Reema Nathem Qashoo
 * ID: 1221009
 * lecture Section: 3
 * lab Section: 5
 */
package project;

public class Cash extends CustomerPayment {
private double discountRate;

public Cash() {
	super();
}

public Cash(String customerName, int customerId, double amount, double discountRate) {
	super(customerName, customerId, amount);
	this.discountRate = discountRate;
}

public double getDiscountRate() {
	return discountRate;
}

public void setDiscountRate(double discountRate) {
	this.discountRate = discountRate;
}
@Override 
protected double calculatePayment() {
	return (amount - ((discountRate/100)*amount));
}

@Override
public String toString() {
	return "Cash [discountRate=" + discountRate + ", customerName=" + customerName + ", customerId=" + customerId
			+ ", amount=" + amount + "]";
}

}
