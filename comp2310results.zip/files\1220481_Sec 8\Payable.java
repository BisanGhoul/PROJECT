package projectjava;
/*sara shrouf
1220481
lap8
*/
public interface  Payable {
	public abstract  boolean isAuthorized();

}
