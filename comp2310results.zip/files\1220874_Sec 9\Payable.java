//Name: Ibrahim Al Ardah || StudentID: 1220874 || Lab Section:9L
package project;

public interface Payable{
	public boolean isAuthorized();
}