//Name: Ghada Sawalha id:1220064 labSection:6
package project;
//Creating class Check which is subclass of CustomerPayment" inheriting"
public class Check extends CustomerPayment implements Payable{//we use the Payable interface to check if it isAuthorized
//Define types of checks as constants 
public static final int CASHIER = 1;
public static final int CERTIFIED = 2;
public static final int PERSONAL = 3;
//Data fields
private int accountNumber;
private double accountBalance;
private int type;
//no/arg constructor and calling the super class
Check(){
	super();
}
//arg-constructor
public Check(int accountNumber, double accountBalance, int type) {
	super();
	this.accountNumber = accountNumber;
	this.accountBalance = accountBalance;
	this.type = type;
}
//initializes all Data fields in this class and for the super class
public Check(String coustemercustomerName, int customerId, double amount,int accountNumber, double accountBalance, int type) {
	super(coustemercustomerName, customerId, amount);
	this.accountNumber = accountNumber;
	this.accountBalance = accountBalance;
	this.type = type;

}
//Generating Setters and Getters for  data fields
public int getAccountNumber() {
	return accountNumber;
}

public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}

public double getAccountBalance() {
	return accountBalance;
}

public void setAccountBalance(double accountBalance) {
	this.accountBalance = accountBalance;
}

public int getType() {
	return type;
}

public void setType(int type) {
	this.type = type;
}


//Abstract method to calculatePayment
protected   double calculatePayment() {
	return amount;
}
//toString method for Check class and connect it with the toString at super class
@Override
public String toString() {
	return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type + super.toString()+"]";
}
//printing all Check user info
void printPaymentInfo() {
	System.out.println(toString()+"Payment ="+calculatePayment() );
}
//using Payable interface 
public boolean isAuthorized() {
	//check if either the type of the check is CASHIER or if the amount of the payment is less than or equal to the accountBalance
	if(type ==CASHIER|| amount <= accountBalance) {
		deductAmountFromBalance();//if its 'check' and we decided to add it we check if type is PERSONAL or CERTIFIED
		return true;
	}
	else return false;
}
//deduct the amount of authorized Check payments (CERTIFIED and PERSONAL only) from the accountBalance 
public void deductAmountFromBalance() {
        if (type == CERTIFIED || type == PERSONAL) 
        	accountBalance=   accountBalance - amount;
        
}
}
