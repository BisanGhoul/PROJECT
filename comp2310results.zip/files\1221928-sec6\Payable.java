/* Name:Dina Daoud
 * ID:1221928
 * Lab Section "6"
 */
package project;

// interface Payable 
public interface Payable {
	
	public abstract boolean isAuthorized();	 //abstract method to use in Check and CreditCard
	
}

