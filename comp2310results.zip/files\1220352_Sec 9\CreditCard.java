package projectone;
import java.util.Date;
public class CreditCard extends CustomerPayment implements Payable {
private double chargingFee;
private Date ExpiryDate ;
public CreditCard() {
	super();
	
}
public CreditCard(String customerName, int customerId, double amount,double chargingFee ,Date ExpiryDate) {
	super(customerName, customerId, amount);
	this.chargingFee=chargingFee;
	this.ExpiryDate=ExpiryDate;

}
public double getChargingFee() {
	return chargingFee;
}
public void setChargingFee(double chargingFee) {
	this.chargingFee = chargingFee;
}
public Date getExpiryDate() {
	return ExpiryDate;
}
public void setExpiryDate(Date expiryDate) {
	ExpiryDate = expiryDate;
}
@Override
public String toString() {
	return "CreditCard [chargingFee=" + chargingFee + ", ExpiryDate=" + ExpiryDate + "]"+super.toString();
}
@Override
public double calculatePayment() {
	return amount+(chargingFee);
}
public boolean isAuthorized(){
	if (this.ExpiryDate .compareTo(new Date()) == 0 ||this.ExpiryDate .compareTo(new Date())== 1) {
		return true ;
	}
	else 
		return false ;
		
	}
}
