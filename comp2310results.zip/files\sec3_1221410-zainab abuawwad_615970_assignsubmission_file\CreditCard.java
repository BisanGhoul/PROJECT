package lab8;
/*
 * Name: zainab abu awwad
 * Id: 1221410
 * lab: 3
 */
import java.util.Date;
import java.util.Comparator;
public class CreditCard extends CustomerPayment implements payable{
	private double chargingFree;
	private Date expiryDate;
	public CreditCard() {
		super();
		
	}
	public CreditCard(String customerName, int customerId, double amount,double chargingFree,Date expiryDate) {
		super(customerName, customerId, amount);
		this.chargingFree=chargingFree;
		this.expiryDate=expiryDate;
	}
	public double getChargingFree() {
		return chargingFree;
	}
	public void setChargingFree(double chargingFree) {
		this.chargingFree = chargingFree;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	@Override
	public String toString() {
		return "CreditCard [chargingFree=" + chargingFree + ", expiryDate=" + expiryDate + " ,customerName= "+customerName+ ",customerId= "+customerId+ ",amount= "+amount+"]";
	}
	@Override
	public boolean isAuthorized() {
		if(getExpiryDate().compareTo(new Date())==0||getExpiryDate().compareTo(new Date())==1)
			return true ;
		else 
			return false;
			
		
		
	}
	@Override
	protected double calculatePyment() {
		
		return amount+getChargingFree();
	}
	
	
	
	

}
