/* Nagham Massis
 * 1220149
 * Lab-Sec = 7
 */
package Project;

public interface Payable{
	boolean isAuthorized();
}
