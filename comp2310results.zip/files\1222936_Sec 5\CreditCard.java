package Project1;
import java.util.*;
public class CreditCard extends CustomerPayment implements Payable {
	private double changingFee;
	private Date expiryDate;
	

	public CreditCard() {
		super();
	}
	
	

	public CreditCard(String customerName, int customerId, double amount,double changingFee,Date expiryDate) {
		super(customerName, customerId, amount);
		setChangingFee(changingFee);
		setExpiryDate(expiryDate);
	}


	public double getChangingFee() {
		return changingFee;
	}


	public void setChangingFee(double changingFee) {
		this.changingFee = changingFee;
	}


	public Date getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}


	@Override
	protected double calculatePayment() {
		return amount+changingFee;
	}
	
	@Override
	public String toString() {
		return "CreditCard [changingFee=" + changingFee + ", expiryDate=" + expiryDate + ", customerName="
				+ customerName + ", customerId=" + customerId + ", amount=" + amount + "]" ;
	}


	void printPaymentInfo() {
		System.out.println(toString()+" Payment = "+calculatePayment());
	}
	public boolean isAuthorized() {
		return  (expiryDate.compareTo(new Date())>=0) ;
	}

}
