// Name : Amir Rasmi Al-Rashayda
// ID_Num : 1222596
// LabSec : 5


    // Importing the ArrayList, Collections, and Date classes 
    import java.util.ArrayList;
    import java.util.Collections;
    import java.util.Date;

    // Driver class with the main method
    public class Driver {
        public static void main( String[] args ) {
            //creeating an ArrayList of CustomerPayment objects
            ArrayList<CustomerPayment> payments = new ArrayList<>();

            //creating a check object and adding it to the list if it is authorized
            Check check1 = new Check("Rana",7777,400,1111,350,Check.PERSONAL);
            if (check1.isAuthorized()) {
                check1.deductAmountFromBalance();
                payments.add(check1);
            }

            //creating a cash object and adding it to the list
            Cash cash1 = new Cash("Ahmad",4444,150,5.0);
            payments.add(cash1);

            //creating another Check object and adding it to the list if it is authorized
            Check check2 = new Check("Suha",5555,100,1111,200,Check.CASHIER);
            if (check2.isAuthorized()) {
                check2.deductAmountFromBalance();
                payments.add(check2);
            }

            //creating another check object and adding it to the list if it is authorized
            Check check3 = new Check("Rania",7777,600.0,1111,750,Check.CERTIFIED);
            if (check3.isAuthorized()) {
                check3.deductAmountFromBalance();
                payments.add(check3);
            }

            // Creating a CreditCard object and adding it to the list if it is authorized
            CreditCard creditCard1 = new CreditCard("Randa",9999,(double)170,(double) 20, new Date(124,05,03));
            if (creditCard1.isAuthorized()) {
                payments.add(creditCard1);
            }

            // Creating another CreditCard object and adding it to the list if it is authorized
            CreditCard creditCard2 = new CreditCard("Hani",6666,(double)150,(double) 10, new Date(120,06,07));
            if (creditCard2.isAuthorized()) {
                payments.add(creditCard2);
            }

            // sorting the list in "descending" order based on the calculated payment
            Collections.sort(payments);

            // printing the list
            for (CustomerPayment payment : payments) {
                payment.printPaymentInfo();
            }
        }
    }
