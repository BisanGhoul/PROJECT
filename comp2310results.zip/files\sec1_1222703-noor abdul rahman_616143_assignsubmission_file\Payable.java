package Testes;

public interface Payable {
	    boolean isAuthorized();
}
