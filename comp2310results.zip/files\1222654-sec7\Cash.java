//Aya abdelrahman fares shejaya ,1222654,lab 7

package proj;
//Class representing a cash payment, extends CustomerPayment class


public class Cash extends CustomerPayment {
	// Attribute to store discount rate
    private double discountRating;

   // Constructor to initialize customer name, customer ID, payment amount, and discount rate
    public Cash(String customerName, int customId, double amount, double discountRating) {
        super(customerName, customId, amount);
        this.discountRating = discountRating;
    }
 // Method to calculate payment amount
    @Override
    protected double calculatePayment() {
        return amount - (amount * (discountRating / 100.0));
    }

 // toString method overridden to include discount rate
    @Override
    public String toString() {
        return "Cash [discountRate=" + discountRating + ", " + super.toString() + "]";
    }

    // Getter and Setter for discountRate
    public double getDiscountRating() {
        return discountRating;
    }

    public void setDiscountRate(double discountRating) {
        this.discountRating = discountRating;
    }
}
