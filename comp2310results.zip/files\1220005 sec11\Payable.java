package project;

public interface Payable {
boolean isAuthorized();

}
