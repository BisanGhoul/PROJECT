//Mohamed Ahmed Obied
//1210093_7L
public class Cash extends  CustomerPayment{
    private double DiscountRate ;

    public Cash() {
    }

    public Cash(String customerName, int customerld, double amount, double discountRate) {
        super(customerName, customerld, amount);
        this.DiscountRate = discountRate;
    }

    public void setDiscountRate(double discountRate) {
        DiscountRate = discountRate;
    }

    public double getDiscountRate() {
        return DiscountRate;
    }

    @Override
    public double calculatePatment(){
  double x =getAmount() - (getAmount()*(getDiscountRate()/100));

        return x;
    }


    @Override
    public String toString() {
        return "Cash[" +
                "DiscountRate=" + DiscountRate +
                  super.toString();

    }
}
