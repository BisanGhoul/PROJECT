//Mohamed Ahmed Obied
//1210093_7L
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class driver {

    public static void main(String[] args) {

        ArrayList<CustomerPayment> A1 = new ArrayList<>();
        CustomerPayment check1 = new Check("Rana",7777,400,1111,350,Check.PERSONAL);
        CustomerPayment cash = new Cash("Ahmad",4444,150,5.0);
        CustomerPayment check2 = new Check("Suha",5555,100,1111,200,Check.CASHIER);
        CustomerPayment check3 = new Check("Rania",7777,600.0,1111,750,Check.CERTIFIED);
        CustomerPayment creditCard1 = new CreditCard("Randa",9999,170,20, new Date(124,05,03));
        CustomerPayment creditCard2 = new CreditCard("Hani",6666,150,10, new Date(120,06,07));


        if (((Check)check1).isAuthorized() )
            A1.add(check1);
        A1.add(cash);

        if (((Check)check2).isAuthorized() )
            A1.add(check2);

        if (((Check)check3).isAuthorized() ){
            A1.add(check3);


        }

        if (((CreditCard)creditCard1).isAuthorized())
            A1.add(creditCard1);

        if (((CreditCard)creditCard2).isAuthorized())
            A1.add(creditCard2);

        Collections.sort(A1);

        for (int i = 0;i< A1.size();i++)
            A1.get(i).printPaymentinfo();



    }

}


