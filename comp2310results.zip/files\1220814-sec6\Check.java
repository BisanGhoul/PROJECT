//Mustafa Fayed Mustafa Aamar
//1220814
// 4 sec
public class Check extends CustomerPyment implements Payable{
    public static final int CASHIER = 1;
    public static final int CERTIFIED = 2;
    public static final int PERSONAL = 3;
    private int accountNumber;
    private double accountBalance;
    private int type;

    public Check() {

    }

    public Check(String customerName, int customerId, double amount, int accountNumber, double accountBalance, int type) {
        super(customerName, customerId, amount);
        this.accountNumber = accountNumber;
        this.accountBalance = accountBalance;
        this.type = type;
    }
    public void deductAmountFromBalance()
    {
        this.accountBalance = this.accountBalance-getAmount();
    }
    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public double getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    @Override
    protected double calculatePayment() {
        return getAmount();
    }

    @Override
    public boolean isAuthorized() {
        if(type == CASHIER && calculatePayment() <= getAccountBalance())
        {
            return true;
        }
        else if (type == CERTIFIED && calculatePayment() <= getAccountBalance())
        {
            deductAmountFromBalance();
            return true;
        }
        else if (type == PERSONAL && calculatePayment() <= getAccountBalance()){
            return false;
        }
        return false;
    }


    @Override
    public String toString() {
        return "Check{" +
                "accountNumber=" + accountNumber +
                ", accountBalance=" + accountBalance +
                ", type=" + type +
                ", customerName='" + customerName + '\'' +
                ", customerId=" + customerId +
                ", amount=" + amount +
                '}';
    }

    @Override
    void printPaymentInfo()
    {
        System.out.println(toString() + " payment = " + calculatePayment());
    }


}
