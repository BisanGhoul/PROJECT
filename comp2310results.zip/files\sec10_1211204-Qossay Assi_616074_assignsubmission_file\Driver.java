// Qusai Assi
// 1211204
// lab_sec_10

package finalproject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class Driver {
	public static void main(String[] args) {

		ArrayList<CustomerPayment> payments = new ArrayList<>();

		payments.add(new Cash("Ahmad", 4444, 150, 5.0));

		Check check1 = new Check("Rana", 7777, 400, 1111, 350, Check.PERSONAL);
		if (check1.isAuthorized()) {
			check1.deductAmountFromBalance();
			payments.add(check1);
		}

		Check check2 = new Check("Suha", 5555, 100, 1111, 200, Check.CASHIER);
		payments.add(check2);

		Check check3 = new Check("Rania", 7777, 600.0, 1111, 750, Check.CERTIFIED);
		if (check3.isAuthorized()) {
			check3.deductAmountFromBalance();
			payments.add(check3);
		}

		CreditCard creditCard1 = new CreditCard("Randa", 9999, 170, 20, new Date(124, 05, 03));
		if (creditCard1.isAuthorized()) {
			payments.add(creditCard1);
		}

		CreditCard creditCard2 = new CreditCard("Hani", 6666, 150, 10, new Date(120, 06, 07));
		if (creditCard2.isAuthorized()) {
			payments.add(creditCard2);
		}

		Collections.sort(payments);
		for (CustomerPayment payment : payments) {
			payment.printPaymentInfo();
		}
	}
}
