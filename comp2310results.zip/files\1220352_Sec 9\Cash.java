package projectone;

public class Cash extends CustomerPayment{ // the sub class of customerPayment i use the reseved word extends
private double discountRate ;

public Cash() {
	super();
	
}

public Cash(String customerName, int customerId, double amount, double discountRate) { // arg constructor 
	super(customerName, customerId, amount);
	this .discountRate=discountRate;
}

public double getDiscountRate() {// setter and getter for the datafield 
	return discountRate;
}

public void setDiscountRate(double discountRate) {
	this.discountRate = discountRate;
}

@Override
public String toString() { // to string method return as string 
	return "Cash [discountRate=" + discountRate + "]"+super.toString();
}
@Override
public double calculatePayment() {// override for the abstract method in super class thats return the ammount - discountrate  
	return this.amount-(this.amount*this.discountRate/100);
}


}
