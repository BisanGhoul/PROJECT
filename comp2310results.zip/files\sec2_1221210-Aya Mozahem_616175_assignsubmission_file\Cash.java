package project_1;

public class Cash extends CustomerPayment implements Comparable<CustomerPayment> {
	
	private double discountRate;
	Cash(){
		
	}
	 Cash(String customerName, int customerId, double amount,double discountRate) {
		super(customerName,customerId,amount);
		this.discountRate=discountRate;
	}
	 public double getDiscountRate() {
			return discountRate;
		}
	 public void setDiscountRate(double discountRate) {
	     	 this.discountRate=discountRate;
		}
	 @Override
	 public String toString() {
	 	return "Cash [discountRate=" + discountRate + "]";
	 }
	 @Override
	 public double CalculatePayment(){
	 	double payment=amount-((discountRate/100)*amount);
	 	return payment;
	 }
		
	 @Override
	 public void PrintInfo() {
		 System.out.println(toString()+"customerName= " + customerName + ", customerId=" + customerId + ", amount=" + amount +CalculatePayment());
	 }
}
