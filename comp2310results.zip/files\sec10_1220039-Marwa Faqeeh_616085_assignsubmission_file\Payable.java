//marwa mahmmoud faqeeh 1220039 s10
public interface Payable {
	boolean isAuthorized() ;

}
