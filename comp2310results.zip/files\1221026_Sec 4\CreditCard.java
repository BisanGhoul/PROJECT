//Layan Salem Salem 
//1221026
//sec:4L
package javaProject;
import java.util.*;

public class CreditCard extends CustomerPayment implements Payable {
private double chargingFee;
private Date expiryDate;

public CreditCard() {
	
}

public CreditCard(String customerName, int customerId, double amount,double chargingFee, Date expiryDAate) {
	super( customerName,  customerId,  amount);
	this.chargingFee = chargingFee;
	this.expiryDate = expiryDAate;
}

public double getChargingFee() {
	return chargingFee;
}

public void setChargingFee(double chargingFee) {
	this.chargingFee = chargingFee;
}

public Date getExpiryDate() {
	return expiryDate;
}

public void setExpiryDate(Date expiryDAate) {
	this.expiryDate = expiryDAate;
}


public  boolean isAuthorized() {
	Date currentDate = new Date();
	
	if ((expiryDate.compareTo(currentDate)>0)|| (expiryDate.compareTo(currentDate)==0))
	return true;
	
	else return false;
	
}
@Override
protected   double calculatePayment() {
	
	return amount + chargingFee;
}

@Override
public String toString() {
	return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", customerName=" + customerName
			+ ", customerId=" + customerId + ", amount=" + amount + "]";
}



}
