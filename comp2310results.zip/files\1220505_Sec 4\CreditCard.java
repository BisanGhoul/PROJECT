//Yara Qaraqe
//1220505
//lab 4l

import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable{
    private double chaargingFee;
    private Date expiryDate;

    public CreditCard() {
    }

    public CreditCard(String customerName, int customerId, double amount, double chaargingFee, Date expiryDate) {
        super(customerName, customerId, amount);
        this.chaargingFee = chaargingFee;
        this.expiryDate = expiryDate;
    }

    public double getChaargingFee() {
        return chaargingFee;
    }

    public void setChaargingFee(double chaargingFee) {
        this.chaargingFee = chaargingFee;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    @Override
    public String toString() {
        return "CreditCard [chaargingFee=" + chaargingFee + ", expiryDate=" + expiryDate + ", customerName=" + super.customerName + ", customerId=" + super.customerId + ", amount=" + super.amount + "]";
    }

    @Override
    public boolean isAuthorized() {
        Date currentDate = new Date();
        return expiryDate.after(currentDate);
    }

    @Override
    protected double calculatePayment() {
        return getAmount() + chaargingFee;
    }


}