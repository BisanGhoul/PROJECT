//Sadeel Dar Assi    1221471   S8  // 
package project;
public class Cash extends CustomerPayment {
	private double discountRate;
	
	public Cash() {
		
	}
	
	public Cash(String customerName , int customerId , double amount , double discountRate) {
		
		super(customerName,customerId,amount);
		this.discountRate = discountRate;
	}
	
	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}

	@Override
	public double calculatePayment() {
		return amount - (amount * discountRate / 100);
	}	
    @Override
    public String toString() {
        return "Cash [" +
        		"discountRate=" + discountRate +
                ", customerName=" + customerName  +
                ", customerId=" + customerId +
                ", amount=" + amount + 
                ']';
    }
    public void printPaymentInfo() {
        System.out.println(this.toString());
        System.out.println(" Payment: " + calculatePayment());
    }
}


