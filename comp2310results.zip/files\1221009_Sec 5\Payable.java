/* Name: Reema Nathem Qashoo
 * ID: 1221009
 * lecture Section: 3
 * lab Section: 5
 */
package project;

public interface Payable {
public boolean isAuthorized();
}
