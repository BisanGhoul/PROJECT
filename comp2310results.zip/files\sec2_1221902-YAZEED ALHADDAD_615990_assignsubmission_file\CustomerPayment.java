/*
 * String name = "Yazeed Alhaddad";
 * int id = 1221902;
 * int labSec = 2;
 */
package ps;


public abstract class CustomerPayment implements Comparable<CustomerPayment> {
protected String customerName;
protected int customerId;
protected double amount;

public CustomerPayment() {

}


public CustomerPayment(String customerName, int customerId, double amount) {
	super();
	this.customerName = customerName;
	this.customerId = customerId;
	this.amount = amount;
}


public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}

protected abstract double calculatePayment();

public void printPaymentInfo() {
	System.out.println(toString() +"Payment = " +  calculatePayment());

}



public String toString() {
	return "CustomerPayment [customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
}


@Override
public int compareTo(CustomerPayment O) {
	if(calculatePayment() > O.calculatePayment()) {
		return -1;
	}
	else if(calculatePayment() < O.calculatePayment()) {
		return 1;
	}
	else {
		return 0;
	}



}


}
