/* Nagham Massis
 * 1220149
 * Lab-Sec = 7
 */
package Project;
import java.util.*;
public class CreditCard extends CustomerPayment implements Payable {
	private double chargingFree;
	private Date expiryDate;
	
	public CreditCard() {
	}
	
	public CreditCard(String customerName, int customerId, double amount,double chargingFree, Date expiryDate) {
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
		this.chargingFree = chargingFree;
		this.expiryDate = expiryDate;
	}


	public double getChargingFree() {
		return chargingFree;
	}

	public void setChargingFree(double chargingFree) {
		this.chargingFree = chargingFree;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	
	@Override
	public String toString() {
		return "CreditCard [chargingFree=" + chargingFree + ", expiryDate=" + expiryDate + ", customerName="
				+ customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}

	@Override
	protected double calculatePayment() {
		return amount + chargingFree;
	}
	
	@Override
	public boolean isAuthorized() {
		Date currentDate = new Date();
		if(expiryDate.compareTo(currentDate) >= 0)
			return true;
		else 
			return false;
	}
	
	

}
