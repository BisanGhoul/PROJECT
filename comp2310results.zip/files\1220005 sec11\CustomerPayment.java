package project;

public abstract class CustomerPayment implements Comparable<CustomerPayment> {
 protected String name;
 protected  int customerid;
 protected double amount;
 
 
 CustomerPayment(){
	 
 }
 
 
 
 public CustomerPayment(String name, int customerid, double amount) {
	super();
	this.name = name;
	this.customerid = customerid;
	this.amount = amount;
}
 

public CustomerPayment(double amount) {
	super();
	this.amount = amount;
}





public String getName() {
	return name;
}



public void setName(String name) {
	this.name = name;
}



public int getCustomerid() {
	return customerid;
}



public void setCustomerid(int customerid) {
	this.customerid = customerid;
}



public double getAmount() {
	return amount;
}



public void setAmount(double amount) {
	this.amount = amount;
}



public abstract double CalculatePayment();
 
 public void printPaymentInfo() {
	 System.out.println(toString()+"payment :"+CalculatePayment());
 }
 @Override
 public int compareTo(CustomerPayment p) {
	 return Double.compare(p.CalculatePayment(),this.CalculatePayment());
 }


@Override
public String toString() {
	return "CustomerPayment [name=" + name + ", customerid=" + customerid + ", amount=" + amount + "]";
}
 
 
 
 
 
}
