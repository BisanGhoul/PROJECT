/*Name: Masa Ahmad Awad
ID : 1220290
Lab : 4*/



package project;

import java.util.*;



	
	
	public class CreditCard extends CustomerPayment implements Payable {
	    private double chargingFee;
	    private Date expiryDate;

	    // All field constructor
	    public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
	        super(customerName, customerId, amount);
	        this.chargingFee = chargingFee;
	        this.expiryDate = expiryDate;
	    }

	 // Getter and setter methods
	    public double getChargingFee() {
	        return chargingFee;
	    }

	    public void setChargingFee(double chargingFee) {
	        this.chargingFee = chargingFee;
	    }

	    public Date getExpiryDate() {
	        return expiryDate;
	    }

	    public void setExpiryDate(Date expiryDate) {
	        this.expiryDate = expiryDate;
	    }

	 
	 // Implementation of Payable interface
	    @Override
	    public boolean isAuthorized() {
	        Date currentDate = new Date();
	        return expiryDate.compareTo(currentDate) >= 0;
	    }
	    
	 // Overridden method for calculatePayment

	    @Override
	    public double calculatePayment() {
	        return amount + chargingFee;
	    }

	    @Override
	    public String toString() {
	        return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", " + super.toString() + "]";
	    }
	}

	


