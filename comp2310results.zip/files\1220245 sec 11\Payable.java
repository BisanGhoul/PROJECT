//NAME = VERONICA WAKILEH ID=1220245  LAB-SECTION=11
package javaproject;

public interface Payable {
boolean isAuthorized();
}
