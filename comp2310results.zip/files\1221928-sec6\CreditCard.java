/* Name:Dina Daoud
 * ID:1221928
 * Lab Section "6"
 */
package project;

import java.util.Date;
//class CreditCard is a subclass for CustomerPayment and implements Payable
public class CreditCard extends CustomerPayment implements Payable{
	//define data fields
	private double chargingFee;
	private Date expiryDate;
	//no-arg constructor
	public CreditCard() {
	
	}
    //CreditCard constructor to create objects
	public CreditCard(String customerName, int customerId, double amount,double chargingFee, Date expiryDate) {
		super(customerName,customerId,amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}
    //Setters and Getters
	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}
	
	public double getChargingFee() {
		return chargingFee;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	public Date getExpiryDate() {
		return expiryDate;
	}
	
	@Override
	public boolean isAuthorized() {
		Date currentDate = new Date();
		if(expiryDate.compareTo(currentDate)==0 || (this.expiryDate).compareTo(currentDate)== 1)
			return true;
		else
			return false;
	}
	
	@Override
	protected double calculatePayment() {           //to calculate the payment by adding the chargingFee to amount
		return (super.amount) + (this.chargingFee);
	}

	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", customerName="
				+ customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}
	
	
	

}
