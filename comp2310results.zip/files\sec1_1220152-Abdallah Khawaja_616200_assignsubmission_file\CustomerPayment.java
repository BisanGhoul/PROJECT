//Name :Abdallah Khawaja  ID:1220152   SEC:1   LAB:1
package project1;
public abstract class CustomerPayment implements Comparable<CustomerPayment> {
	protected String customerName;
	protected int customerId;
	protected double amount;

	public CustomerPayment() {
    
	}

	public CustomerPayment(String customerName, int customerId, double amount) {
		super();
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
	}

	public String getcustomerName() {
		return customerName;
	}

	public void setcustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	
    abstract double calculatePayment();
	
	abstract void printPaymentInfo();

	
	
	public String toString() {
		return " , customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount;
	}
	
	public int compareTo(CustomerPayment C) {
		return Double.compare(C.calculatePayment(), this.calculatePayment());
	}

}