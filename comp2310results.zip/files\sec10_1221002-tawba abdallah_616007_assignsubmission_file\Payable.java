//Name:Tawba Atta Ibrahim Abdallah Id:1221002 Sec:10L.
package projectjava;

public interface Payable {
public boolean isAuthorized();

}
