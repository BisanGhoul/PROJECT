package Project;
/*     Name  :Maisam Ayed Iftayeh
ID num  :1221197
lecture sec:3
lab sec  :4 */
public interface Payable {
	public abstract boolean isAuthorized();

}
