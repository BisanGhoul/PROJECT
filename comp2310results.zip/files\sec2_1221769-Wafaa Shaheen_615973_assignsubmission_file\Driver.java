/* Student Name: Wafaa Shaheen
 * Student Id: 1221769
 * Lab Section: 2
 */

package project;

import java.util.*;

public class Driver {
	
	public static void main(String[] args) { 
		
	
	ArrayList<CustomerPayment> payments = new ArrayList<CustomerPayment>();
	
    Cash cashPayment = new Cash("Ahmad", 4444, 150,5.0);
    payments.add(cashPayment);
    
    Check checkPayment1 = new Check("Rana", 7777, 400,1111,350,Check.PERSONAL);

    if (((Check)checkPayment1).isAuthorized()) {
        payments.add(checkPayment1);
    }
    
    Check checkPayment2=new Check("Suha",5555,100,1111,200,Check.CASHIER);
    if (((Check)checkPayment2).isAuthorized()) {
        payments.add(checkPayment2);
    } 
     
    Check checkPayment3=new Check("Rania",7777,600.0,1111,750,Check.CERTIFIED);
    if (((Check)checkPayment3).isAuthorized()) {
        payments.add(checkPayment3);
    }
    
    CreditCard creditPayment1=new CreditCard("Randa",9999,170,20, new Date(124,05,03));
    if (((CreditCard)creditPayment1).isAuthorized()) { 
        payments.add(creditPayment1);
    }
    CreditCard creditPayment2=new CreditCard("Hani",6666,150,10, new Date(120,06,07));
    if (((CreditCard)creditPayment2).isAuthorized()) {
        payments.add(creditPayment2);
    }
    
    
    Collections.sort(payments);
    for (int i=0;i<payments.size();i++) {
       (payments.get(i)).printPaymentInfo();
      }
    
   
}
}
