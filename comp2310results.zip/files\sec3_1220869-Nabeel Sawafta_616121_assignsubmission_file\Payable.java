//Nabeel Sawafta
//1220869
//3L
public interface Payable {
public boolean isAuthorized();
}
