//Name: Ghada Sawalha id:1220064 labSection:6
package project;
//Creating Payable interface
public interface Payable {
 public boolean isAuthorized();
}
