
import java.util.*;

public class Driver {
    public static void main(String[] args) {
        ArrayList<CustomerPayment> payments=new ArrayList<>();

        Check check1=new Check("Rana",7777,400,1111,350,Check.PERSONAL);
        Check check2=new Check("suha",5555,100,1111,200,Check.CASHIER);
        Check check3=new Check("Rania",7777,600.0,1111,750,Check.CERTIFIED);
        Cash cash=new Cash("Ahmad",4444,150,5.0);
        CreditCard creditCard1=new CreditCard("Randa",9999,170,20,new Date(124,5,3));
        CreditCard creditCard2=new CreditCard("Hani",6666,150,10,new Date(120,6,7));



       if (check1.isAuthorized()) payments.add(check1);
       if (check2.isAuthorized()) payments.add(check2);
       if (check3.isAuthorized()) payments.add(check3);
       if (creditCard1.isAuthorized()) payments.add(creditCard1);
       if (creditCard2.isAuthorized()) payments.add(creditCard2);
       payments.add(cash);
       Collections.sort(payments);//sort descending order based on the calculated payment and using comparable
       for(CustomerPayment p:payments)
          p.printPaymentInfo();

    }
}