package java_project_2;

//the name lour shaltaf
//the id 1221128
//the lab section 7l
import java.util.*;
public class Driver {

	public static void main(String[] args) {
		 ArrayList<CustomerPayment> payments = new ArrayList<>();// Create an ArrayList to store CustomerPayment objects.
	        CustomerPayment check1 = new Check("Rana",7777,400,1111,350,Check.PERSONAL);// Create a Check object.
	        if (((Check)check1).isAuthorized() ) // Check if the check is authorized.
	            payments.add(check1);

	        CustomerPayment cash = new Cash("Ahmad",4444,150,5.0);// Create a Cash object.
	        payments.add(cash);// Add the cash payment to the payments list.

	        CustomerPayment check2 = new Check("Suha",5555,100,1111,200,Check.CASHIER);// Create another Check object.
	        if (((Check)check2).isAuthorized() )// Check if the check is authorized.
	            payments.add(check2);// Add the check to the payments list.

	        CustomerPayment check3 = new Check("Rania",7777,600.0,1111,750,Check.CERTIFIED); // Create another Check object.
	        if (((Check)check3).isAuthorized() )// Check if the check is authorized.
	            payments.add(check3);// Add the check to the payments list.


	        CustomerPayment creditCard1 = new CreditCard("Randa",9999,170,20, new Date(124,05,03));// Create a CreditCard object.
	        if (((CreditCard)creditCard1).isAuthorized())// Check if the credit card is authorized.
	            payments.add(creditCard1);// Add the credit card payment to the payments list

	        CustomerPayment creditCard2 = new CreditCard("Hani",6666,150,10, new Date(120,06,07)); // Create another CreditCard object.
	        if (((CreditCard)creditCard2).isAuthorized())// Check if the credit card is authorized.
	            payments.add(creditCard2);// Add the credit card payment to the payments list.
	        Collections.sort(payments);// Sort the payments list based on the compareTo method implementation.
	        for (int i = 0;i< payments.size();i++)
	            payments.get(i).printPaymentInfo();// Print the payment information for each payment in the list.



	    }

	}


