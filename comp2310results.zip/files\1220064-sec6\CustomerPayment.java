//Name: Ghada Sawalha id:1220064 labSection:6
package project;
//The Abstract Class and the super Class
public abstract class CustomerPayment implements Comparable<CustomerPayment>{//here we implement the Comparable interface
//Data Fields(The properties)
protected String customerName;
protected int customerId;
protected double amount;
//no-arg constructor
CustomerPayment(){
}
//creating an all-arg constructor that initializes all Data fields in this class
public CustomerPayment(String customerName, int customerId, double amount) {
	super();
	this.customerName = customerName;
	this.customerId = customerId;
	this.amount = amount;
}
//Generating Setters and Getters for  data fields
public String getcustomerName() {
	return customerName;
}
public void setcustomerName(String customerName) {
	this.customerName = customerName;
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
//Abstract methods
protected  abstract double calculatePayment();
abstract void printPaymentInfo();
	
//toString() method for the super class(CustomerPayment)
@Override
public String toString() {
	return " , customerName=" + customerName + ", customerId=" + customerId
			+ ", amount=" + amount ;
}
//Comparable interface here we compare two CustomerPayment according to calculatePayment
public int compareTo(CustomerPayment diff) {
    return Double.compare(this.calculatePayment(), diff.calculatePayment());
}


}
