//NAME = VERONICA WAKILEH ID=1220245  LAB-SECTION=11
package javaproject;

public abstract class CostumerPayment implements Comparable<CostumerPayment> {
	
	protected String costumerName;
	protected int costumerId;
	protected double amount;
	public CostumerPayment() {
	
	}
	public CostumerPayment(String costumerName, int costumerId, double amount) {
		this.costumerName = costumerName;
		this.costumerId = costumerId;
		this.amount = amount;
	}



	public String getCostumerName() {
		return costumerName;
	}
	public void setCostumerName(String costumerName) {
		this.costumerName = costumerName;
	}
	public int getCostumerId() {
		return costumerId;
	}
	public void setCostumerId(int costumerId) {
		this.costumerId = costumerId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public int compareTo(CostumerPayment s) {
		if(this.calculatePayment()>s.calculatePayment())
			return 1;
		else if(this.calculatePayment()<s.calculatePayment())
			return -1;
		else return 0;
		
	}
	
	protected abstract double calculatePayment();
	
	public  void printPaymentInfo() {
		System.out.println(toString()+"Payment=" +calculatePayment());
	}
   
}
