//NAME = VERONICA WAKILEH ID=1220245  LAB-SECTION=11
package javaproject;

public class Cash extends CostumerPayment  {
private double discountRate;
public Cash() {
	
}

public Cash(String costumerName, int costumerId, double amount, double discountRate) {
	super(costumerName, costumerId, amount);
	this.discountRate = discountRate;
}

public double getDiscountRate() {
	return discountRate;
}
public void setDiscountRate(double discountRate) {
	this.discountRate = discountRate;
}
   



@Override
public String toString() {
	return "Cash [discountRate=" + discountRate + ", costumerName=" + costumerName + ", costumerId=" + costumerId
			+ ", amount=" + amount + "]";
}


public double calculatePayment() {
	return this.amount-(this.amount *getDiscountRate()*0.01);
}


}
