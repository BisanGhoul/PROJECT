package project_1;

public class Check extends CustomerPayment implements Payable  {

	private int accountNumber;
	private double accountBalance;
    private int type;
    public static final int CASHIER=1;
    public static final int CERTIFIED=2;
    public static final int PERSONAL=3;
    
    Check() {
    	
    }
    Check(String customerName, int customerId, double amount,int accountNumber, double accountBalance, int type) {
    	super(customerName,customerId,amount);
    	this.accountNumber=accountNumber;
    	this.accountBalance = accountBalance;
    	this.type = type;
    }
    public int getAccountNumber() {
    	return accountNumber;
    }
    public void setAccountNumber(int accountNumber) {
    	this.accountNumber = accountNumber;
    }
    public double getAccountBalance() {
    	return accountBalance;
    }
    public void setAccountBalance(double accountBalance) {
    	this.accountBalance = accountBalance;
    }
    public int getType() {
    	return type;
    }
    public void setType(int type) {
    	if( type==CASHIER || type==CERTIFIED || type==PERSONAL)
    		this.type = type;
    	else
    		System.out.println("invalid type");
    }
    @Override
	public String toString() {
		return "check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type + "]";
	}
   public void deductAmountFromBalance() {
	     double o=accountBalance-amount;
   }
   
   @Override  
   public double CalculatePayment () {
   	double payment=amount;
   	return payment;
   }
   @Override 
   public boolean isAuthorized() {
   		if(type==CASHIER ||  amount<=accountBalance) {
   			deductAmountFromBalance();
   			return true;
   		}
   		else
   			return false;
   }
   @Override 
   public void PrintInfo() {
	   String typeName;
	   if(type == CASHIER)
		   typeName="Cashier";
	   else if(type == CERTIFIED)
		   typeName="Certified";
	   else if(type==PERSONAL)
		   typeName="personal";
	   
	   typeName="anonymous";
		   
	   System.out.println(toString()+"customerName" +customerName + ", customerId=" + customerId + ", amount="+"Calculate Payment"+CalculatePayment());
   }
   
}
