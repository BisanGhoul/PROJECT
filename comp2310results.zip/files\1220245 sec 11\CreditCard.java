//NAME = VERONICA WAKILEH ID=1220245  LAB-SECTION=11
package javaproject;
import java.util.Date;
public class CreditCard extends CostumerPayment implements Payable {
private double chargingFee;
private Date expiryDate;
public CreditCard() {
	
}
	
public CreditCard(String costumerName, int costumerId, double amount, double chargingFee, Date expiryDate) {
	super(costumerName, costumerId, amount);
	this.chargingFee = chargingFee;
	this.expiryDate = expiryDate;
}


	public double calculatePayment() {
		return this.amount+ getChargingFee();
	}


	public double getChargingFee() {
		return chargingFee;
	}
	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", costumerName="
				+ costumerName + ", costumerId=" + costumerId + ", amount=" + amount + "]";
	}

	@Override
	public boolean isAuthorized() {
		Date CurrentDate=new Date();
		int result= this.getExpiryDate().compareTo(CurrentDate) ;
		if (result>0)
			return true;
		else return false;
			
	}

}
