package project_1;

public interface Payable {
	
	public abstract boolean isAuthorized();

}
