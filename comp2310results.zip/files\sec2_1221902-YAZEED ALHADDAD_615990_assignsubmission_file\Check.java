/*
 * String name = "Yazeed Alhaddad";
 * int id = 1221902;
 * int labSec = 2;
 */
package ps;

public class Check extends CustomerPayment implements Payable {
	//declare vars
	public static final int CASHIER=1;
	public static final int CERTIFIED=2;
	public static final int PERSONAL=3;
	private int accountNumber;
	private double accountBalance;
	private int type;
	//no-arg constructor
	public Check(){}
	//all-arg constructor
	public Check(String customerName, int customerId, double amount, int accountNumber, double accountBalance, int type) {
		super(customerName, customerId, amount);
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
	}
	//getter
	public int getAccountNumber() {
		return accountNumber;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public int getType() {
		return type;
	}

	//setter
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public void setType(int type) {
		this.type = type;
	}

	public void deductAmountFromBalance() {
		this.accountBalance = this.accountBalance - this.amount;
	}

	//Overrided methods
	@Override
	protected double calculatePayment() {

		return super.amount;
	}

	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type
				+ ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}

	@Override
	public boolean isAuthorized() {
		if(this.amount <= getAccountBalance() && (type == PERSONAL || type == CERTIFIED)) {
			deductAmountFromBalance();
			return true;
		}
		else if(this.amount <= getAccountBalance() || type == CASHIER ) {
			return true;
		}
		else
			return false;
	}
}
