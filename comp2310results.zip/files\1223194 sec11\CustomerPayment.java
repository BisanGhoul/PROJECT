// Alaa Mansour 1223194 lab section 11

package alaa;

public abstract class CustomerPayment implements Comparable<CustomerPayment>{
    protected String customerName;
    protected int customerID;
    protected double amount;
    
    public CustomerPayment() {
    	
    	
    }
    

    public CustomerPayment(String customerName, int customerID, double amount) {
        this.customerName = customerName;
        this.customerID = customerID;
        this.amount = amount;
    }
    
    

    public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public int getCustomerID() {
		return customerID;
	}


	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	public double calculatePayment() {
        return amount;
    }

    public void printPaymentInfo() {
        System.out.println(this.toString() + " Payment: " + calculatePayment());
    }

    @Override
    public int compareTo(CustomerPayment other) {
        return Double.compare(other.calculatePayment(), this.calculatePayment());
    }

    @Override
    public String toString() {
        return "CustomerPayment [customerName=" + customerName + ", customerID=" + customerID + ", amount=" + amount + "]";
    }
}


