package Project;
/*
 *  Name  : Rami Ayman Rimawi
 *   ID   : 1211583
 * LabSec : 8L
 */
public interface Payable {
	abstract boolean isAuthorized();
}
