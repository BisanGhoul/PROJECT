//Mohamed Ahmed Obied
//1210093_7L
import java.util.Date;

public class CreditCard extends CustomerPayment implements PayAble{

private double chargingFee ;
private Date expiryDate  ;

    public CreditCard() {
    }

    public CreditCard(String customerName, int customerld, double amount,
                      double chargingFee, Date expiryDate ) {
        super(customerName, customerld, amount);
        this.chargingFee = chargingFee;
        this.expiryDate =expiryDate ;
    }

    public void setChargingFee(double chargingFee) {
        this.chargingFee = chargingFee;
    }

    public void setexpiryDate (Date expiryDate ) {
        this.expiryDate  = expiryDate ;
    }

    public double getChargingFee() {
        return chargingFee;
    }

    public Date getexpiryDate () {
        return expiryDate ;
    }

    @Override
    public boolean isAuthorized(){
        Date D1 = new Date();

        if (getexpiryDate ().compareTo(D1)>=0 ==true){
            return true;
        }
        else {
            return false;
        }
    }


    @Override
    public double calculatePatment(){

        return getAmount() + getChargingFee();
    }


    @Override
    public String toString() {
        return "CreditCard[" +
                "chargingFee=" + chargingFee +
                ", date=" + expiryDate  +
                 super.toString();
    }
}
