//nawras eyad omar yacoob,1221904,sec3,lab5//
package CustomerPackage;

public class Cash extends CustomerPayment {
    private double discountRate;

    public Cash() {
    }

    public Cash(String customerName, int customerId, double amount, double discountRate) {
        super(customerName, customerId, amount);
        this.discountRate = discountRate;
    }

    public double getDiscountRate() {
        return discountRate;
    }

    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }

	@Override
	public double calculatePayment() {
		return amount - discountRate * amount / 100.0;
	}

    @Override
	public String toString() {
        return "Cash  [discountRate=" + discountRate + ", customerName=" + super.customerName + ", customerId=" + super.customerId + ", amount=" + super.amount + "]";
    }
}