package project;
import java.util.*;


public  class CreditCard extends CustomerPayment implements Payable{

	private double chargingFee;
	private Date expiryDate;
	
	CreditCard(){
		
	}
	
	
	
	public CreditCard(String name,int customerid,double amount,double chargingFee, Date expiryDate) {
		super(name,customerid,amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}



	public double getChargingFee() {
		return chargingFee;
	}
	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	public double CalculatePayment() {
		return getAmount()+chargingFee;
	}
	
	public boolean isAuthorized() {
		return this.expiryDate.compareTo(new Date())>=0;
	}
	




	@Override
	public String toString() {
		return "CreditCard [chargingFee="+this.chargingFee+",expiryDate="+this.expiryDate.toString()+",customerName="+this.name+",customerId="+ this.customerid + ", amount=" + this.amount + "]";
	}
	
	
	
	
	
	
}
