
public abstract class Customerpayment implements Comparable<Customerpayment> {
	protected String customerName;
	protected int customerID;
	protected double amount;

	public Customerpayment() {

	}

	public Customerpayment(String customerName, int customerID, double amount) {
		this.customerName = customerName;
		this.customerID = customerID;
		this.amount = amount;
	}

	//marwa mahmmoud faqeeh 1220039 s10
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	protected abstract double calculatePayment();

	public void paymentInfo() {
		System.out.println(toString() + "payment = " + calculatePayment());

	}

	@Override
	public String toString() {
		return "Customerpayment [customerName=" + customerName + ", customerID=" + customerID + ", amount=" + amount
				+ "]";
	}

	public int compareTo(Customerpayment obj) {
		double x = this.calculatePayment();
		double y = obj.calculatePayment();

		if (x < y)
			return 1;
		else if (y < x)
			return -1;
		else
			return 0;

	}

}
