/*Name: Masa Ahmad Awad
ID : 1220290
Lab : 4*/



package project;

import java.util.*;





	
	public abstract class CustomerPayment implements Comparable<CustomerPayment> {
	    protected String customerName;
	    protected int customerId;
	    protected double amount;

	    public CustomerPayment(String customerName, int customerId, double amount) {
	        this.customerName = customerName;
	        this.customerId = customerId;
	        this.amount = amount;
	    }
	    public String getCustomerName() {
	        return customerName;
	    }

	    public void setCustomerName(String customerName) {
	        this.customerName = customerName;
	    }

	    public int getCustomerId() {
	        return customerId;
	    }

	    public void setCustomerId(int customerId) {
	        this.customerId = customerId;
	    }

	    public double getAmount() {
	        return amount;
	    }

	    public void setAmount(double amount) {
	        this.amount = amount;
	    }


	    @Override
	    public int compareTo(CustomerPayment o) {
	        return Double.compare(o.calculatePayment(), this.calculatePayment());
	    }

	    @Override
	    public String toString() {
	        return "CustomerPayment [customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	    }
	    
	    public double calculatePayment() {
	        return amount;
	    }

	    public void printPaymentInfo() {
	        System.out.println(this.toString() + " Payment = " + calculatePayment());
	    }
	}







