package java_project_2;

//the name lour shaltaf
//the id 1221128
//the lab section 7l
//This class represents a customer payment and implements the Comparable interface with the type parameter CustomerPayment.
class CustomerPayment implements Comparable<CustomerPayment> {
 protected  String customerName; // The name of the customer.
 protected  int customerId;// The ID of the customer.
 protected double amount;// The payment amount.
//no-argu construstor
  public CustomerPayment() {
  }
  // Constructor for creating a CustomerPayment object with the specified customer name, ID, and amount.
  public CustomerPayment(String customerName, int customerId, double amount) {
      this.customerName = customerName;
      this.customerId = customerId;
      this.amount = amount;
  }
//getter and setter
  public String getCustomerName() {
      return customerName;
  }

  public void setCustomerName(String customerName) {
      this.customerName = customerName;
  }

  public int getCustomerId() {
      return customerId;
  }

  public void setCustomerId(int customerId) {
      this.customerId = customerId;
  }

  public double getAmount() {
      return amount;
  }

  public void setAmount(double amount) {
      this.amount = amount;
  }
  // Calculate the payment amount. In this case, it simply returns the original amount.
  protected double calculatePayment() {
      return amount;
  }
// Print the payment information.
   void printPaymentInfo() {
      System.out.println(toString() + " Payment = " + calculatePayment());
  }
  // Compare two CustomerPayment objects based on their calculated payment amounts.
  @Override
  public int compareTo(CustomerPayment o) {
      return Double.compare(o.calculatePayment(), this.calculatePayment());
  }
// Return a string representation of the CustomerPayment object.
  @Override
  public String toString() {
      return "CustomerPayment [customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount
              + "]";
  }
}
