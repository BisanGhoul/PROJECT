package project1;

public class Check extends CustomerPayment implements Payable {
	private int accountNumber;
	private double accountBalance ;
	final static int CASHIER=1,CERTIFIED=2,PERSONAL=3;//constant
	private int type;	
	public Check() {//no_arg constructor
	
	}
	
	public Check(String customerName,int customerId,double amount,int accountNumber, double accountBalance, int type) {//arg constructor
		super(customerName,customerId,amount);//calling customerPayment arg constructor
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
	}
//setters and getters
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" +accountBalance + ", type=" + type + ", customerName ="+customerName+", customerId ="+customerId+", amount ="+amount+"]";
	}
	public void deductAmountFromBalane() { 
		if (type == CASHIER ) {
			this.accountBalance = accountBalance;//if the type is CASHIER the accountBalance won't change 
		}
		else
		this.accountBalance=accountBalance - amount;//if the type is PERSONAL or CERTIFIED the accountBalance will change 
	}
	@Override
	public boolean isAuthorized () {
	if (type== CASHIER  ||amount <= accountBalance) {
		deductAmountFromBalane();
		return true;
		}
	else	
	  return false;
	}
	
	 @Override
		protected double calculatePayment() {//implement the calculatePayment method
			return amount;
		}
		
}
