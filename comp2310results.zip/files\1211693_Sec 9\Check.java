//saleh salameeen
//1211693
//lecture 9 

package  prj;
import java.util.*;

public class Check extends CustomerPayment implements Payable<CustomerPayment>{
	
	//CASHIER=1, CERTIFIED=2, PERSONAL=3
	static final int CASHIER = 1;
	static final int CERTIFIED = 2;
	static final int PERSONAL = 3;
	private double accountBalance;
	private int accountNumber;
	private int type;
	
	
	
	public Check() {
		
	}


	
	
	
	public Check(String customerName, int customerId, double amount,double accountBalance, int accountNumber, int type) {
		super(customerName,  customerId, amount);
		this.accountBalance = accountBalance;
		this.accountNumber = accountNumber;
		this.type = type;
	}
	
	
	
	


	public double getAccountBalance() {
		return accountBalance;
	}





	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}





	public int getAccountNumber() {
		return accountNumber;
	}





	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}





	public int getType() {
		return type;
	}





	public void setType(int type) {
		this.type = type;
	}





	
	
	/*@Override
	public String toString() {
		return "Check ["+super.toString() +accountBalance + ", accountNumber=" + accountNumber + ", type=" + type + "]";
	}*/
	
	
	@Override
	public String toString() {
		return "Check ["+"customerName=" + customerName + ", customerId=" + customerId
				+ ", amount=" + amount +"accountBalance=" + accountBalance + ", accountNumber=" + accountNumber + ", type=" + type
				+ "]";
	}





	@Override
	double calculatePayment() {
		 
		 return super.amount;
	 }
	
	
	
	
	public void deductAmountFromBalance() {
		if(type == CERTIFIED || type == PERSONAL) {
			
				super.amount = super.amount - this.accountBalance;
			
		}
		
		
	}

	public boolean isAuthorized() {
		
		return type == this.CASHIER || super.amount <= this.accountBalance  ;
			
		
		
	}
	



	@Override
	public int compareTo(CustomerPayment other) {
		return (int)(other.calculatePayment() - this.calculatePayment() );
	}
 
}
