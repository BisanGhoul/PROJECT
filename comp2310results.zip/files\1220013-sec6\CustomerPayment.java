// Name: [ Faris Ahmad Sawalmeh ].
// Id: [ 1220013 ].
// Lap Section No: [ 6L ].

public abstract class  CustomerPayment implements Comparable <CustomerPayment>{

    protected String customerName;
    protected int customerId;
    protected double amount;

    @Override
    public String toString() {
        return "CustomerPayment [customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount
                + "]";
    }
    public String getCustomerName() {
        return customerName;
    }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getCustomerId() {
        return customerId;
    }
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public double getAmount() {
        return amount;
    }
    public void setAmount(double amount) {
        this.amount = amount;
    }

    public CustomerPayment(String customerName, int customerId, double amount) {
        this.customerName = customerName;
        this.customerId = customerId;
        this.amount = amount;
    }
    public CustomerPayment() {

    }
    public abstract double  calculatePayment();
    void printPaymentInfo() {
        System.out.println(toString() + " Payment = "+ calculatePayment());
    }
    public int compareTo(CustomerPayment C) {
        if(calculatePayment() > C.calculatePayment())
            return -1;
        else if(calculatePayment() < C.calculatePayment())
            return 1;
        else
            return 0;
    }
}