//Name:Ellen_Izz,ID:1220806,lecture section:3.lab section:5
package project1;
import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable{
	private double chargingFee;
	private Date expiryDate;
	

	public CreditCard() {
	}
    

	public CreditCard(String customerName, int customerId, double amount,double chargingFee, Date expiryDate) {
		super(customerName,customerId,amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}
    

	public double getChargingFee() {
		return chargingFee;
	}


	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}


	public Date getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

     
	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate= " + expiryDate+","+super.toString();
	}


	@Override
	protected double CalculatePayment() {
		 
		return amount+chargingFee;
	}
	//expirydate greater than current date???????????????
	public  boolean isAuthorized() {
		 //expiryDate compare with the current Date
		//if the expiryDate greater than or equal the current date then it is authorized  
		int x=expiryDate.compareTo(new Date());
		int y=expiryDate.compareTo(new Date());
		if(y==0|| x==1) {
		return true;
	}
		else
			return false;	 
       }

}
