//name: malik arqoup
//id = 1211686
import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable{

    private double ChargingFee ;
    private Date ExpiryDate  ;

    public CreditCard() {
    }

    public CreditCard(String customerName, int customerld, double amount,
                      double chargingFee, Date expiryDate ) {
        super(customerName, customerld, amount);
        this.ChargingFee = chargingFee;
        this.ExpiryDate =expiryDate ;
    }

    public void setChargingFee(double chargingFee) {
        this.ChargingFee = chargingFee;
    }

    public void setexpiryDate (Date expiryDate ) {
        this.ExpiryDate  = expiryDate ;
    }

    public double getChargingFee() {
        return ChargingFee;
    }

    public Date getexpiryDate () {
        return ExpiryDate ;
    }

    @Override
    public boolean isAuthorized(){
        Date D1 = new Date();

        if (getexpiryDate ().compareTo(D1)>=0 ==true){
            return true;
        }
        else {
            return false;
        }
    }


    @Override
    public double CalculatePatment(){

        return getAmount() + getChargingFee();
    }


    @Override
    public String toString() {
        return "CreditCard[" +
                "chargingFee=" + ChargingFee +
                ", date=" + ExpiryDate  +
                super.toString();
    }
}
