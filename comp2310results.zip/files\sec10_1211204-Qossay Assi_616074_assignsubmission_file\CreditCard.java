// Qusai Assi
// 1211204
// lab_sec_10

package finalproject;

import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable {
	private double chargingFee;
	private Date expiryDate;

	public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
		super(customerName, customerId, amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}

	public double getChargingFee() {
		return chargingFee;
	}

	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public double calculatePayment() {
		return amount + chargingFee;
	}

	@Override
	public boolean isAuthorized() {
		return expiryDate.after(new Date());
	}

	@Override
	public String toString() {
		return super.toString() + ", chargingFee=" + chargingFee + ", expiryDate=" + expiryDate;
	}
}
