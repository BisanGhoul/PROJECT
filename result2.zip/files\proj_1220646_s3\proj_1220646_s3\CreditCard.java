package project1;
import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable {
	private double chargingFree;
	private Date expiryDate;
	
	public  CreditCard() {	//no_arg constructor
	}

	public CreditCard(String customerName,int customerId,double amount,double chargingFree, Date expiryDate) {//arg constructor
		super( customerName, customerId, amount);//calling customerPayment arg constructor
		this.chargingFree = chargingFree;
		this.expiryDate = expiryDate;
	}
//setters and getters
	public double getChargingFree() {
		return chargingFree;
	}

	public void setChargingFree(double chargingFree) {
		this.chargingFree = chargingFree;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public String toString() {
		return "CreditCard [chargingFree=" + chargingFree + ", expiryDate=" + expiryDate + ", customerName ="+customerName+", customerId ="+customerId+", amount ="+amount+ "]";
	}
	@Override
	protected double calculatePayment() {//implement the calculatePayment method
		return amount+chargingFree;
	}
	
	 public boolean isAuthorized () {//implement the isAuthorized method
		 Date currentDate=new Date();
		if (expiryDate.compareTo(currentDate)>=0) {
			return true;
		}
		else
			return false;
	 }
   
}
