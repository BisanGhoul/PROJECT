/*Name: Masa Ahmad Awad
ID : 1220290
Lab : 4*/



package project;

public interface Payable {
	
	 boolean isAuthorized();

}
