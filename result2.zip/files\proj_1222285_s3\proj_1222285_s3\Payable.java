/*name: izzeldeen sallam
 *id : 1222285
 * lab sec : 3
 * 
 * 
 * */
package project;

public interface Payable {

	public boolean isAuthorized();
}
