package pay;

public interface Payable {
    public abstract boolean isAuthorized();
}
