// Name : Amir Rasmi Al-Rashayda
// ID_Num : 1222596
// LabSec : 5 

    import java.lang.Comparable; 
    //imported the comparable interface 
    // declaring an abstract class CustomerPayment that implements the Comparable interface
    public abstract class CustomerPayment implements Comparable<CustomerPayment> {

        //protected class variables
        protected String customerName; //name of the customer
        protected int customerId; //ID of the customer
        protected double amount; //amount of the payment

        // full const
        public CustomerPayment(String customerName, int customerId, double amount) {
            this.customerName = customerName; // initializing customerName with the passed value
            this.customerId = customerId; // Initializing customerId with the passed value
            this.amount = amount; // initializing amount with the passed value
        }

        // no argument const
        public CustomerPayment() {

        }

        // getter/setter methods
        public String getCustomerName() {
            return customerName;
        }

    
        public void setCustomerName(String customerName) {
            this.customerName = customerName;
        }

        
        public int getCustomerId() {
            return customerId;
        }

        
        public void setCustomerId(int customerId) {
            this.customerId = customerId;
        }

        
        public double getAmount() {
            return amount;
        }

        
        public void setAmount(double amount) {
            this.amount = amount;
        }

        // abstract method calculatePayment() that will be implemented in the subclasses since it's implementation is different for every subclass 
        abstract protected double calculatePayment(); // protected in the uml "#"

        // to print payment informations
        void printPaymentInfo() {
            // Printing the string representation of the object and the calculated payment
            System.out.println(this.toString() + " Payment = " + calculatePayment());
        }

        // Overriding the compareTo method from the Comparable interface
        @Override
        public int compareTo(CustomerPayment o) {
            // comparing the calculated payment of the current object with the passed object
            return Double.compare(o.calculatePayment(), this.calculatePayment());
        }

        // overriding the toString method from the Object
        @Override
        public String toString() {
            // returning a string representation of the object exactly as shown in the example
            return "CustomerPayment [" +
                    "customerName=" + customerName +
                    ", customerId=" + customerId +
                    ", amount=" + amount +
                    ']';
        }
    }
