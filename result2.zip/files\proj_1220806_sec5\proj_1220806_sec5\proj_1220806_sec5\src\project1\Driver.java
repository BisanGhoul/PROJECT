 //Name:Ellen_Izz,ID:1220806,lecture section:3.lab section:5
package project1;
import java.util.*;

 
public class Driver {

	public static void main(String[] args) {
		 ArrayList <CustomerPayment>payments=new ArrayList<>();	 
		 CustomerPayment Check1= new Check("Rana",7777,400,1111,350,Check.PERSONAL);
		 
			 if(((Check) Check1).isAuthorized()) {
				 payments.add(Check1);
			 }
			 
		 
		 CustomerPayment cash=new Cash("Ahmad",4444,150,5.0);
		 payments.add(cash);
			
		 
		 
		 CustomerPayment check2=new Check("Suha",5555,100,1111,200,Check.CASHIER);
		
			 if(((Check) check2).isAuthorized()) {
				 payments.add(check2);
			 }
			 
		 
		 CustomerPayment check3 =new Check("Rania",7777,600.0,1111,750,Check.CERTIFIED);
		
			 if(((Check) check3).isAuthorized()) {
				 payments.add(check3);
			 }
			  
		 
		 CustomerPayment CreditCard1=new CreditCard("Randa",9999,170,20,new Date(124,05,03));
		
			 if(((CreditCard) CreditCard1).isAuthorized()) {
				 payments.add(CreditCard1);
			 }
			 
		 
		 CustomerPayment CreditCard2=new CreditCard("Hani",6666,150,10,new Date(120,06,07));
		
			 if(((CreditCard) CreditCard2).isAuthorized()) {
				 payments.add(CreditCard2);
			 }
			  
		 
		 
		 
		 Collections.sort( payments);
			//sorting according to calculate Payment
		 //Array list because it's dynamic array it takes type object
		 
	 
		 for(int i=0;i<payments.size();i++) {
			 payments.get(i).printPaymentInfo();
			 
		 }
		 
		 
	} 
		 
		 
		 
		 
		 
		 
		 

	

}
