//name: malik arqoup
//id = 1211686
public class Check extends  CustomerPayment implements Payable{
    private int Accountnumber ;
    private double Accountbalance;

    private int type ;


    static  int  CASHIER=1;
    static  int CERTIFIED=2 ;

    static  int PERSONAL=3 ;

    public Check() {
    }

    public Check(String customerName, int customerld, double amount,
                 int AccountNumber ,double AccountBalance, int type) {
        super(customerName, customerld, amount);
        this.Accountbalance = AccountBalance;
        this.Accountnumber=AccountNumber ;
        this.type=type ;


    }

    public void setAccountBalance(double accountBalance) {
        this.Accountbalance = accountBalance;
    }

    public void setAccountNumber(int accountNumber) {
       this.Accountnumber = accountNumber;
    }

    public void setType(int type) {
        this.type = type;
    }

    public double getAccountBalance() {
        return Accountbalance;
    }

    public int getAccountNumber() {
        return Accountnumber;
    }

    public int getType() {
        return type;
    }
    public void DeductAmountFromBalance(){

        if (type == CERTIFIED || type == PERSONAL ){
            Accountbalance = getAccountBalance() - getAmount();

        }

    }

    @Override
    public boolean isAuthorized(){
        if (getType() == CASHIER ){
            DeductAmountFromBalance();

            return true ;


        }else if ( getAmount() <=getAccountBalance()){
            DeductAmountFromBalance();

            return true;
        }


        else {
            return false ;
        }
    }


    @Override
    public double CalculatePatment(){

        return getAmount();
    }



    @Override
    public String toString() {
        return "Check[" +
                "AccountNumber=" + Accountnumber +
                ", AccountBalance=" + Accountbalance +
                ", type=" + type +" ,"+
                super.toString();
    }
}
