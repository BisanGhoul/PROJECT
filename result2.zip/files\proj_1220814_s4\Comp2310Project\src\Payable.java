//Mustafa Fayed Mustafa Aamar
//1220814
// 4 sec
public interface Payable {
    boolean isAuthorized();
}
