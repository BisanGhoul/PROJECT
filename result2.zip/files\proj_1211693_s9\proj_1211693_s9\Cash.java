//saleh salameeen
//1211693
//lecture 9

package  prj;
import java.util.*;

public class Cash extends CustomerPayment{
	
	
	private double discountRate;
	
	
	public Cash() {
		
		
	}
	
	

	public Cash(String customerName, int customerId, double amount,double discountRate) {
		super(customerName,customerId,amount);
		this.discountRate = discountRate;
	}
	
	
	

	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}
	
	
	
	
	/*@Override
	public String toString() {
		return "Cash [" + super.toString()+ ", discountRate=" + discountRate +"]"  ;
	}*/
	
	
	
	



	@Override
	 protected double calculatePayment() {
		 
		 return super.amount-(super.amount*this.discountRate);
	 }
	
	
	
	
    

		@Override
	public String toString() {
		return "Cash [" + "customerName=" + customerName + ", customerId=" + customerId
				 + "discountRate=" + discountRate + "]";
	}



		@Override
		public int compareTo(CustomerPayment other) {
			 return (int)(other.calculatePayment() - this.calculatePayment() );
		}
	    
	    
	  
	}