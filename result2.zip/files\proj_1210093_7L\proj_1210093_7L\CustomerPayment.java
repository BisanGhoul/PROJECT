//Mohamed Ahmed Obied
//1210093_7L
public  abstract class CustomerPayment  implements Comparable<CustomerPayment> {

    protected String customerName ;
    protected  int customerld ;
    protected double amount ;


    public CustomerPayment() {
    }

    public CustomerPayment(String customerName, int customerld,double amount) {
        this.customerName = customerName;
        this.customerld=customerld;
        this.amount=amount;

    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public void setCustomerld(int customerld) {
        this.customerld = customerld;
    }


    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public double getAmount() {
        return amount;
    }

    public int getCustomerld() {
        return customerld;
    }

    public String getCustomerName() {
        return customerName;
    }

    abstract protected double calculatePatment();
     public  void printPaymentinfo(){

         System.out.println(toString()  +"Payment = "+calculatePatment());

     }


    @Override
    public int compareTo(CustomerPayment x){

        if (this.calculatePatment() > x.calculatePatment()){
            return -1 ;

        }else if (this.calculatePatment() < x.calculatePatment())
        {
            return  1 ;

        }else {

            return 0;

        }
    }

    @Override
    public String toString() {
        return
                "customerName='" + customerName + '\'' +
                ", customerld=" + customerld +
                ", amount=" + amount+"]";
    }
}
