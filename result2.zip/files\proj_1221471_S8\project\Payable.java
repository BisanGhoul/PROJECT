//Sadeel Dar Assi    1221471   S8  // 
package project;
public interface Payable {

	boolean isAuthorized();
}
