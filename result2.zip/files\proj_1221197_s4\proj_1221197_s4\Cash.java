package Project;
/*     Name  :Maisam Ayed Iftayeh
ID num  :1221197
lecture sec:3
lab sec  :4 */
public class Cash extends CustomerPayment {
	private double discountRate;

	public Cash() {
	}

	public Cash(String customerName, int customerId,double amount,double discountRate) {
		super(customerName,customerId,amount);
		this.discountRate = discountRate;
	}

	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}

	@Override
	public String toString() {
		return "Cash [discountRate=" + discountRate + ", customerName=" + customerName + ", customerId=" + customerId
				+ ", amount=" + amount + "]";
	}
	@Override
    protected double calculatePayment() {
		return (amount-(discountRate*(amount/100)));
	}

}
