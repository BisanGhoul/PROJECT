//Name:Yasmin_Al_Shawawrh
//ID:1220848
//Lecture:3
//Lap:4

package project;
import java.util.*;
public class CreditCard extends CustomerPayment implements Payable{//It is a subclass for the CustomerPayment and implements the payable interface
	private double chargingFee;//private: accessible from this class just
	private Date expiryDate;//private: accessible from this class just
	public CreditCard() {
		//no-arg constructor
	}
	public CreditCard(String customerName, int customerld, double amount,double chargingFee, Date expiryDate) {//constructor with arguments (constructor from the superclass)
		//superclass constructor aren't inherited but we can invoked it by using super keyword
		super(customerName, customerld, amount);//call superclass constructor(with arguments)
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}
	public CreditCard(double chargingFee, Date expiryDate) {//constructor with arguments (constructor using fields)
		//superclass constructor aren't inherited but we can invoked it by using super keyword
		super();//call superclass constructor(with no-arg) 
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}
	public double getChargingFee() {//The get method returns chargingFee value
		return chargingFee;
	}
	public void setChargingFee(double chargingFee) {//The set method sets the value
		this.chargingFee = chargingFee;
	}
	public Date getExpiryDate() {//The get method returns expiryDate value
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {//The set method sets the value
		this.expiryDate = expiryDate;
	}
	@Override
	public String toString() {//The toString method returns the String representation of the object
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate +super.toString()+ "]";//we use super to call superclass method
	}
	@Override
	public boolean isAuthorized() {//A CreditCard payment is authorized if its expiryDate is greater than or equal to the current date
		if(expiryDate.compareTo(new Date())>=0)
			return true;//return true because it is Authorized
		return false; //return false because it isn't Authorized
	}
	@Override
	protected double calculatePayment(){//This method is calculated the payment which is the amount plus the chargingFee
		return (amount+chargingFee);
	}
}
