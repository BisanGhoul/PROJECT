/*Name :Hiba Abu Taha 
 * ID:1221211
 Dr.Yousuf Hasoneh
 */
package myproject22;

public class Check extends CustomerPayment implements Payable {
	public static final int CASHIER = 1, CERTIFIED = 2, PERSONAL = 3;

	private int accountNumber;
    private double accountBalance;
    private int type;

    public Check() {
    }

    public Check(String customerName, int customerId, double amount, int accountNumber, double accountBalance, int type) {
        super( customerName,customerId, amount);
        this.accountNumber = accountNumber;
        this.accountBalance = accountBalance;
        this.type = type;
    }

    public int getAccountNumber() {
        return accountNumber;
    }
    public double getAccountBalance() {
        return accountBalance;
    }
    
    public int getType() {
        return type;
    }
    
    
    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }
    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }
    public void setType(int type) {
        this.type = type;
    }

    
	public void deductAmountFromBalance() {
		accountBalance -= calculatePayment();
	}

    @Override
    public double calculatePayment() {
        return super.amount;
    }

    @Override
    public boolean isAuthorized() {
        boolean isAuthorized = type == CASHIER || accountBalance >= calculatePayment();

if ((type == CERTIFIED || type == PERSONAL) && accountBalance >= calculatePayment()){
			deductAmountFromBalance();
		}

		return isAuthorized;
    }

	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + " ,accountBalance=" + accountBalance + " ,type= " + type + ", customerName=" + super.customerName + ", customerId=" + super.customerId + ", amount=" + super.amount + "]";
	}
}
