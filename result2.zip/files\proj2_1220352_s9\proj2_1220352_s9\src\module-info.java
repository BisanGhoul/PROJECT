/**
 * 
 */
/**
 * @author az
 *
 */
module Projectone {
}