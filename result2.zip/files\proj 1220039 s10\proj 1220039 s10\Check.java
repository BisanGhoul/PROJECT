//marwa mahmmoud faqeeh 1220039 s10
public class Check extends Customerpayment implements Payable {
	private int accountNumber;
	private double accountbalance;
	private int type;
	static final int CASHIER = 1;
	static final int CERTIFIED = 2;
	static final int PERSONAL = 3;

	public Check() {

	}

	public Check(String customerName, int customerID, double amount, int accountNumber, double accountbalance,
			int type) {
		super(customerName, customerID, amount);
		this.accountNumber = accountNumber;
		this.accountbalance = accountbalance;
		this.type = type;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getAccountbalance() {
		return accountbalance;
	}

	public void setAccountbalance(double accountbalance) {
		this.accountbalance = accountbalance;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public double calculatePayment() {
		return amount;

	}

	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountbalance=" + accountbalance + ", type=" + type
				+ ", customerName=" + customerName + ", customerID=" + customerID + ", amount=" + amount + "]";
	}

	public boolean isAuthorized() {
		if (type == CASHIER || amount <= accountbalance) {
			if (type == CERTIFIED || type == PERSONAL)
				deductAmountFromBalance();
			return true;

		}

		else

			return false;
	}

	public double deductAmountFromBalance() {

		accountbalance -= amount;

		return accountbalance;

	}
}
