package project1;

public interface  Payable {
	public abstract boolean isAuthorized ();

}
