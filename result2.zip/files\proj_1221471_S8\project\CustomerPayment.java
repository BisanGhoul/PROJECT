//Sadeel Dar Assi    1221471   S8  // 
package project;
import java.lang.Comparable;
import java.util.Date;

public abstract class CustomerPayment implements Comparable<CustomerPayment> {
    

	    protected String customerName;
	    protected int customerId;
	    protected double amount;

	    public CustomerPayment() {
	       
	    }

	    public CustomerPayment(String customerName, int customerId, double amount) {
	        this.customerName = customerName;
	        this.customerId = customerId;
	        this.amount = amount;
	    }

	    public String getCustomerName() {
			return customerName;
		}

		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}

		public int getCustomerId() {
			return customerId;
		}

		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}

		public double getAmount() {
			return amount;
		}

		public void setAmount(double amount) {
			this.amount = amount;
		}

		public abstract double calculatePayment();
	    @Override
	    public String toString() {
	        return "customerName{" +
	                "customerName=" + customerName +
	                ", customerId=" + customerId +
	                ", amount=" + amount +
	                '}';
	    }
	    public void printPaymentInfo() {
	        System.out.println(this.toString());
	        System.out.println(" Payment: " + calculatePayment());
	    }
	    
	    @Override
	    public int compareTo(CustomerPayment other) {
	        
	        return Double.compare(other.calculatePayment(), this.calculatePayment());
	    }
	    }
	