package pay;

public class Cash extends CustomerPayment {

    //data field
    private double discountRate;

    //construtors
    public Cash() {
        super();//invoke  the constructor of the parent class
    }

    public Cash(String customerName, int customerId, double amount, double discountRate) {
        super(customerName, customerId, amount);//invoke  the constructor of the parent class
        this.discountRate = discountRate;
    }
    
    //getters and & setters
    public double getDiscountRate() {
        return discountRate;
    }

    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }
     
    //implimintation  of abstract methods from the parent class
    @Override
    public double calculatePayment() {
        double amount = (super.getAmount()) * (this.discountRate / 100);
        return super.getAmount() - amount;
    }
    
    @Override
    public String toString() {
        return "Cash [discountRate=" + discountRate + "]"+super.toString();
    }
    


}
