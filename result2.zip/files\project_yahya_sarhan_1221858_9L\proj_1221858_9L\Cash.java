//Name: yahya sarhan                       id: 1221858                          lab_sec: 9L        
public class Cash extends CustomerPayment {
    private double discountRate;

    public Cash() {

    }

    public Cash(String customerName, int customerld, double amount, double discountRate) {
        super(customerName, customerld, amount);
        this.discountRate = discountRate;
    }

    public double getDiscountRate() {
        return discountRate;
    }

    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }

    @Override
    public String toString() {
        return "Cash [discountRate=" + discountRate + "" + super.toString() + "]" + " " + "Payment = ";
    }

    @Override
    protected double calculatePayment() {
        return (amount - (amount * (discountRate / 100)));
    }

    @Override
    void printPaymentInfo() {
        System.out.println(toString() + calculatePayment());
    }
}
