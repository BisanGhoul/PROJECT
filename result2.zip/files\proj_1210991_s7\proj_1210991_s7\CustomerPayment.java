/*Haytham Hakam Aref Shehadeh
 * 1210991
 * 7L
 * */
package project; 
import java.util.Date; 
interface Comparable { 
    int compareTo(); 
} 
abstract class CustomerPayment implements java.lang.Comparable<CustomerPayment> { 
//define protected varibles 
    protected String customer_name; 
    protected int customer_id; 
    protected double amount; 
//default constructor 
    public CustomerPayment() { 
    } 
//parametrized constructor 
    public CustomerPayment(String customer_name, int customer_id, double amount) { 
        this.customer_name = customer_name; 
        this.customer_id = customer_id; 
        this.amount = amount; 
    } 
//setters and getters 
 
//customer name getter 
    public String get_customer_name() { 
        return customer_name; 
    } 
//customer name setter 
    public void set_customer_name(String customer_name) { 
        this.customer_name = customer_name; 
    } 
//customer Id getter 
    public int getCustomer_id() { 
        return customer_id; 
    } 
//customer Id setter 
    public void set_customer_id(int customer_id) { 
        this.customer_id = customer_id; 
    } 
//ammount getter 
    public double getAmount() { 
        return amount; 
    } 
//amount setter 
    public void setAmount(double amount) { 
        this.amount = amount; 
    } 
 
  
    public abstract double calculatePayment(); 
 
    public void printPaymentInfo() { 
        System.out.println(toString() + " Payment = " + calculatePayment()); 
    } 
    public int compareTo(CustomerPayment otherPayment) { 
        // Compare payments in descending order 
        return Double.compare(otherPayment.calculatePayment(), this.calculatePayment()); 
    } 
 
 public int compareTo() { 
  // TODO Auto-generated method stub 
  return 0; 
 } 
 
}