
//DAREEN ABUALHAJ   / 1220686  /  1L
public class Cash  extends  CustomerPayment{
	private double discountRate;
	//constructors
	public Cash() {

	}

	public Cash(String customerName, int customerId, double amount, double discountRate) {
		super(customerName, customerId, amount);
		this.discountRate = discountRate;
	}

	//setter and getter for DiscountRate 
	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}
	@Override
	public double calculatePayment() {

		return amount - (amount *( discountRate / 100.0));
	}


//toString method
	 
	@Override
	public String toString() {
		return "Cash [discountRate=" + discountRate + ", customerName=" + customerName + ", customerId=" + customerId
				+ ", amount=" + amount + "]";
	}

}
