package project;
//Name : Mohammad shasha'a     ID : 1220610      lab section : 3
public class Check extends CustomerPayment implements Payable {

	private int accountNumber;
	private double accountBalance;
	private int type;
    static final int CASHIER=1,CERTIFIED=2,PERSONAL=3;
	public Check () {
		
	}
	
	
	public Check(String customerName, int customerId, double amount,int accountNumber, double accountBalance, int type) {
		super(customerName,customerId,amount);
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
	}


	@Override
	public boolean isAuthorized() {
		if (type == CASHIER || amount <= accountBalance) {
			deductAmountFromBalance();
		return true;
		}
		else 
			return false;
	}


	
	
	
	public void deductAmountFromBalance() {
		if (type != CASHIER  && getAmount()<= getAccountBalance())
		setAccountBalance(accountBalance-amount);	
		
		
	}


	public int getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}


	public double getAccountBalance() {
		return accountBalance;
	}


	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}


	public int getType() {
		return type;
	}


	public void setType(int type) {
		this.type = type;
	}


	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type + super.toString()+"]";
	}


	@Override
	protected double calculatePayment() {
		
	  return getAmount();
	}



}
