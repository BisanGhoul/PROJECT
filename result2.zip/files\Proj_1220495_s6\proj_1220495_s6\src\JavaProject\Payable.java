package JavaProject;

public interface Payable {
    boolean isAuthorized();
}
