//interface payment
public interface Payable {
	public boolean isAuthorized();
}
