// Name : Amir Rasmi Al-Rashayda
// ID_Num : 1222596
// LabSec : 5     
    
    // Check class extends the abstract class CustomerPayment and implements the Payable interface
    public class Check extends CustomerPayment implements Payable {
        // private class variables
        private int accountNumber; // Account number for check payments
        private double accountBalance; // Account balance for check payments
        private int type; // Type of check payment

        // constant variables representing the types of check payments
        public static final int CASHIER = 1;
        public static final int CERTIFIED = 2;
        public static final int PERSONAL = 3;

        // full const
        public Check(String customerName, int customerId, double amount,int accountNumber, double accountBalance, int type) {
            super(customerName, customerId, amount); // Calling the constructor of the superclass
            this.accountNumber = accountNumber; // Initializing accountNumber with the passed value
            this.accountBalance = accountBalance; // Initializing accountBalance with the passed value
            this.type = type; // Initializing type with the passed value
        }

        // no argu const
        public Check() {

        }

        // getter/setter methods 
        public int getAccountNumber() {
            return accountNumber;
        }

      
        public void setAccountNumber(int accountNumber) {
            this.accountNumber = accountNumber;
        }

     
        public double getAccountBalance() {
            return accountBalance;
        }

     
        public void setAccountBalance(double accountBalance) {
            this.accountBalance = accountBalance;
        }

  
        public int getType() {
            return type;
        }

      
        public void setType(int type) {
            this.type = type;
        }

        // Overriding the isAuthorized method from the Payable interface
        @Override
        public boolean isAuthorized() {
            // A Check payment is authorized if either the type of the check is CASHIER or if the amount of the payment is less than or equal to the accountBalance
            return type == CASHIER || (type != CASHIER && amount <= accountBalance);
        }

        // method to deduct the amount from the account balance
        public void deductAmountFromBalance() {
            // If the type of the check is not CASHIER, deduct the amount from the account balance
            if (type != CASHIER) {
                accountBalance -= amount;
            }
        }

        // Overriding the calculatePayment method from the superclass
        @Override
        protected double calculatePayment() {
            // The payment is the same as the amount entered
            return amount;
        }

        // Overriding the toString method from the superclass
        @Override
        public String toString() {
            // Returning a string representation of the object exactly as shown in the example
            return "Check [" +
                    "accountNumber=" + accountNumber +
                    ", accountBalance=" + accountBalance +
                    ", type=" + type +
                    ", customerName=" + customerName +
                    ", customerId=" + customerId +
                    ", amount=" + amount +
                    ']';
        }
    }
