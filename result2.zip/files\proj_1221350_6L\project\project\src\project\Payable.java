package project;

/*
Name:Mohammad Abu Hijleh
ID: 1221350
Lab Section: 6L
*/
public interface Payable {
    boolean isAuthorized();
}

