//Aya abdelrahman fares shejaya ,1222654,lab 7

package proj;
import java.util.Date;

//Class representing a credit card payment, extends CustomerPayment class and implements Payable
public class CreditCard extends CustomerPayment implements Payable {
    private double chargingFee;
    private Date expiryDate;

 // Constructor to initialize customer name, customer ID, payment amount, charging fee, and expiry date
    public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
        super(customerName, customerId, amount);
        this.chargingFee = chargingFee;
        this.expiryDate = expiryDate;
    }

    @Override
    protected double calculatePayment() {
        return amount + chargingFee;
    }

 // Method to check if payment is authorized based on expiry date of the credit card
    @Override
    public boolean isAuthorized() {
        Date D = new Date();
        return expiryDate.compareTo(D) >= 0;
    }

    @Override
    public String toString() {
        return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", " + super.toString() + "]";
    }

    // Getters and Setters
    public double getChargingFee() {
        return chargingFee;
    }

    public void setChargingFee(double chargingFee) {
        this.chargingFee = chargingFee;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }
}
