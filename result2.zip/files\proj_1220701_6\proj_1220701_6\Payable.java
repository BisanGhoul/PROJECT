package projectJava;

interface Payable {
    boolean isAuthorized();
}