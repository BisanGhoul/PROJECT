/*Haytham Hakam Aref Shehadeh
 * 1210991
 * 7L
 * */
package project; 
class Check extends CustomerPayment implements Payable { 
//define private variables 
    private int account_number; 
    private double account_balance; 
    private int type; 
//define constants 
    public static final int CASHIER = 1; 
    public static final int CERTIFIED = 2; 
    public static final int PERSONAL = 3; 
//default constructor 
    public Check() { 
    } 
//parametrized constructor 
    public Check(String customerName, int customerId, double amount, int account_number, double account_balance, int type) { 
        super(customerName, customerId, amount); 
        this.account_number = account_number; 
        this.account_balance = account_balance; 
        this.type = type; 
    } 
 
//define setters and getters 
 
//getter for account nmber 
    public int get_account_number() { 
        return account_number; 
    } 
//setter for account number 
    public void set_account_number(int account_number) { 
        this.account_number = account_number; 
    } 
//getter for account balance 
    public double get_account_balance() { 
        return account_balance; 
    } 
//setter for account balance 
    public void set_account_balance(double account_balance) { 
        this.account_balance = account_balance; 
    } 
//getter for type 
    public int getType() { 
        return type; 
    } 
//setter for type 
    public void setType(int type) { 
        this.type = type; 
    } 
//overriden methods 
    @Override 
    public double calculatePayment() { 
        return amount; 
    } 
 
  
    @Override 
    public String toString() { 
        return "Check [account number=" + account_number + ", account balance=" + account_balance + ", type=" + type 
                + ", customer name=" + customer_name + ", customer id=" + customer_id + ", amount=" + amount + "]"; 
    } 
 
 @Override 
 public int compareTo() { 
  // TODO Auto-generated method stub 
  return 0; 
 } 
 
 @Override 
 public boolean isAuthorized() { 
  // TODO Auto-generated method stub 
  return false; 
 } 
}