/* Student Name: Wafaa Shaheen
 * Student Id: 1221769
 * Lab Section: 2
 */
package project;

public interface Payable {
	public boolean isAuthorized();
}
