//Yara Qaraqe
//1220505
//lab 4l

public class Cash extends CustomerPayment{
    private double discountRate;

    public Cash() {
    }

    public Cash(String customerName, int customerId, double amount, double discountRate) {
        super(customerName, customerId, amount);
        this.discountRate = discountRate;
    }

    public double getDiscountRate() {
        return discountRate;
    }

    @Override
    public String toString() {
        return "Cash [discountRate=" + discountRate + ", customerName=" + super.customerName + ", customerId=" + super.customerId + ", amount=" + super.amount + "]";
    }

    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }

    @Override
    protected double calculatePayment() {
        return getAmount() - (getAmount() * discountRate / 100);
    }

}