/* Name: Reema Nathem Qashoo
 * ID: 1221009
 * lecture Section: 3
 * lab Section: 5
 */
package project;

public abstract class CustomerPayment implements Comparable<CustomerPayment> {
	protected String customerName;
	protected int customerId;
	protected double amount;

	public CustomerPayment() {
		super();
	}

	public CustomerPayment(String customerName, int customerId, double amount) {
		super();
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
	}

	protected abstract double calculatePayment();

	void printPaymentInfo() {
		System.out.println(toString() +" Payment = " + calculatePayment());
	}

	@Override
	public int compareTo(CustomerPayment x) {
		if (calculatePayment() < x.calculatePayment())
			return 1;
		else if (calculatePayment() > x.calculatePayment())
			return -1;
		else
			return 0;
	}

	@Override
	public String toString() {
		return "CustomerPayment [customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount
				+ "]";
	}
	
}
