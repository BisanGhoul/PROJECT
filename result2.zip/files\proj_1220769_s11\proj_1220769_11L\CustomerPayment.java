//Name:Noor Nasir
//ID:1220769
//Lab Section : 11L

public abstract class CustomerPayment implements Comparable<CustomerPayment> {
	protected String customerName;
	protected int customerId;
	protected double amount;
	
	public CustomerPayment() {
		
	}
	
	//CustomerPayment ( customerName, customerId, amount )
	public CustomerPayment(String customerName,int customerId,double amount) {
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getCustomeId() {
		return customerId;
	}
	public void setCustomeId(int customeId) {
		this.customerId = customeId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	protected  abstract double calculatePayment();
	
	
	
	@Override
	public int compareTo(CustomerPayment x) {
		if(this.calculatePayment()<x.calculatePayment()) {
			return 1;
		}
		else if (this.calculatePayment()==x.calculatePayment()) {
			return 0;
		}
		else {
			return -1;
		}
		
	}
	
	@Override
	public String toString() {
		return "customer payment is " +"customer name :" + customerName +"customer id :" +customerId +"amount :"+amount;
	}
	
	 public void printPaymentInfo() {
	        System.out.println(toString() + "\n payment" +calculatePayment()); 
	    }
	}

