//Name:Ellen_Izz,ID:1220806,lecture section:3.lab section:5
package project1;

public class Cash extends CustomerPayment {
 private double discountRate;
   
public Cash() {
}

public Cash(String customerName, int customerId, double amount,double discountRate) {
	super(customerName,customerId,amount);
	this.discountRate = discountRate;
}




public double getDiscountRate() {
	return this.discountRate;
}

public void setDiscountRate(double discountRate) {
	this.discountRate = discountRate;
}
protected double CalculatePayment(){
	  return  amount-(amount*(discountRate/100.0));
	
}

@Override
public String toString() {
	return "Cash [discountRate=" + discountRate +","+super.toString();
}
 
}
