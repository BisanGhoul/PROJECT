/*Name: Maria Massad / ID:1221494 / lab_sec:8 */
package project;

public class Cash extends CustomerPayment{
private double discountRate ;
public Cash (){
	
}
public Cash(String customerName, int customerId, double amount,double discountRate){
	super (customerName,customerId,amount);
	this.discountRate = discountRate ;
}

public double getDiscountRate() {
	return discountRate;
}

public void setDiscountRate(double discountRate) {
	this.discountRate = discountRate;
}

//implement 
protected double calculatePayment () {
	double paymentValue = amount - (amount*(discountRate/100));
	return paymentValue;
}

@Override
public String toString() {
	return "Cash"+" [ discountRate="+discountRate +", "+super.toString()+"]";
}


}
