package projectBzu;

public interface Payable {
public boolean isAuthorized ();
}
