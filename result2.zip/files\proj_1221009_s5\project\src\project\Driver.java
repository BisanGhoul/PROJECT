/* Name: Reema Nathem Qashoo
 * ID: 1221009
 * lecture Section: 3
 * lab Section: 5
 */
package project;
import java.util.*;
public class Driver {

	public static void main(String[] args) {
		ArrayList<CustomerPayment> paymentsArray = new ArrayList<>();
		CustomerPayment check1 = new Check("Rana",7777,400,1111,350,Check.PERSONAL);
		if(((Check)check1).isAuthorized())
			paymentsArray.add(check1);
		CustomerPayment cash1 = new Cash("Ahmad",4444,150,5.0);
		paymentsArray.add(cash1);
		CustomerPayment check2 = new Check("Suha",5555,100,1111,200,Check.CASHIER);
		if(((Check)check2).isAuthorized())
			paymentsArray.add(check2);
		CustomerPayment check3 = new Check("Rania",7777,600.0,1111,750,Check.CERTIFIED);			   
		if(((Check)check3).isAuthorized())
			paymentsArray.add(check3);
		CustomerPayment creditCard1 = new CreditCard("Randa",9999,170,20, new Date(124,05,03));
		if(((CreditCard)creditCard1).isAuthorized())
			paymentsArray.add(creditCard1);
		CustomerPayment creditCard2 = new CreditCard("Hani",6666,150,10, new Date(120,06,07));
		if(((CreditCard)creditCard2).isAuthorized())
			paymentsArray.add(creditCard2);
		Collections.sort(paymentsArray);
		for(int i=0; i<paymentsArray.size();i++)
			paymentsArray.get(i).printPaymentInfo();

	}

}
