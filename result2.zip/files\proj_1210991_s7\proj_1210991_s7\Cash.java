/*Haytham Hakam Aref Shehadeh
 * 1210991
 * 7L
 * */
package project; 
class Cash extends CustomerPayment { 
   //define private variable  
    private double discount_rate; 
   //default constructor 
    public Cash() { 
    } 
//parametrized constructor 
    public Cash(String customer_name, int customer_Id, double amount, double discount_rate) { 
        super(customer_name, customer_Id, amount); 
        this.discount_rate = discount_rate; 
    } 
//disscount rate getter 
    public double get_discount_rate() { 
        return discount_rate; 
    } 
//discount rate setter 
    public void set_discount_rate(double discount_rate) { 
        this.discount_rate = discount_rate; 
    } 
//overriden methods 
    @Override 
    public double calculatePayment() { 
        return amount - (amount * (discount_rate / 100)); 
    } 
 
    @Override 
    public String toString() { 
        return "Cash [discount rate=" + discount_rate + ", customerName=" + customer_name + ", customerId=" + customer_id 
                + ", amount=" + amount + "]"; 
    } 
 
 @Override 
 public int compareTo() { 
  // TODO Auto-generated method stub 
  return 0; 
 } 
}