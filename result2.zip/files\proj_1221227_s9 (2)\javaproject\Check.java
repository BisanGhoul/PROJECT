//Name: Ali hamdan     ID: 1221227     Lab sec: 9
package javaproject;

public class Check extends CustomerPayment implements Payable{
	public static final int CASHIER = 1;
	public static final int CERTIFIED = 2;
	public static final int PERSONAL = 3;
	private int accountNumber;
	private double accountBalance;
	private int type;
	
	public void deductAmountFromBalance() {
		 this.accountBalance -= this.amount;
	}
	
	public Check() {}
	public Check(String CustomerName, int CustomerId, double amount, int accountNumber, double accountBalance, int type) {
		super(CustomerName,CustomerId,amount);
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
	}

	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public double calculatePayment() {
        return amount;
    }
	@Override
	public boolean isAuthorized() {
		 if (type == CASHIER || amount <= accountBalance) {
	            deductAmountFromBalance();
	            return true;
	        }
	        return false;
	}

	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type
				+ ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}

	
	
	
}
