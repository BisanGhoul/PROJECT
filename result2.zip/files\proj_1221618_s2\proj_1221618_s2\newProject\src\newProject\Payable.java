package newProject;

public interface Payable {
	public boolean isAuthorized();
	
}
