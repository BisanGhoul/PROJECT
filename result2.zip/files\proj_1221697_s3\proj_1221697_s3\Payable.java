// Name : Aws Hammad - ID : 1221697 - Lab : 3
public interface Payable {
	public boolean isAuthorized ();
}
