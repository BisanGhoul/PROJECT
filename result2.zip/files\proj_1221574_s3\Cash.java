//Name:Abdulrahman Orwah Fahmi Sawalmeh.
//ID:1221574.
//Lab section:3L.
public class Cash extends CustomerPayment {
    private double discountRate;

    public Cash() {
    }

    public Cash(String customerName, int customerId, double amount, double discountRate) {
        super(customerName, customerId, amount);
        this.discountRate = discountRate;
    }

    @Override
    public double calculatePayment(){
        return amount - (getDiscountRate()*amount)/100;
    }
    public double getDiscountRate() {
        return discountRate;
    }

    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }

    @Override
    public String toString() {
        return "Cash{" +
                "discountRate=" + discountRate +"} "+
                super.toString()+" "+
                "CalculatedPayment: ";
    }

}
