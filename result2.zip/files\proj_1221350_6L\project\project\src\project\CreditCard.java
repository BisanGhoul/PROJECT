package project;
/*
Name:Mohammad Abu Hijleh
ID: 1221350
Lab Section: 6L
*/
import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable{
    private double chargingFee;
    private Date expiryDate;

    public CreditCard() {
        super();
        chargingFee= 0.0;
        expiryDate= null;
    }

    public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
        super(customerName, customerId, amount);
        this.chargingFee = chargingFee;
        this.expiryDate = expiryDate;
    }

    public double getChargingFee() {
        return chargingFee;
    }

    public void setChargingFee(double chargingFee) {
        this.chargingFee = chargingFee;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    @Override
    public String toString() {
        return "creditCard{" +
                "chargingFee=" + chargingFee +
                ", expiryDate=" + expiryDate +
                ", customerName='" + customerName + '\'' +
                ", customerId=" + customerId +
                ", amount=" + amount +
                '}';
    }

    @Override
    protected double calculatePayment() {
        return amount+chargingFee;
    }

    @Override
    public boolean isAuthorized(){
        Date currentDate = new Date();
        if (this.expiryDate.equals(currentDate) || this.expiryDate.after(currentDate))
            return true;
            else
                return false;
    }

}
