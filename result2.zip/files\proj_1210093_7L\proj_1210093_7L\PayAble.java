//Mohamed Ahmed Obied
//1210093_7L
public interface PayAble {
     boolean isAuthorized();

}
