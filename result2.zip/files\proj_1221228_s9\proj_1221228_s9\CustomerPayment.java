//Name : Mohamad Tahan 
//ID : 1221228
//LAB SECTION : 9
public abstract class CustomerPayment implements Comparable<CustomerPayment>{
	protected String customerName;
	protected int customerId;
	protected double amount;
	
	
	
	public CustomerPayment() {}
	

	public CustomerPayment(String customerName, int customerId, double amount) {
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
	}


	protected abstract double calculatePayment();
	
	void printPaymentInfo(){
		 System.out.println(this.toString());
	        System.out.println("Payment: " + calculatePayment());
	}
	public int compareTo(CustomerPayment c) {
		if(this.calculatePayment()<c.calculatePayment()) {
			return 1;
		}
		else if(this.calculatePayment()>c.calculatePayment())
			return -1;
		else 
			return 0;
		
	}
	 @Override
	public String toString() {
		return "[customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount
				+ "]";
	}
}