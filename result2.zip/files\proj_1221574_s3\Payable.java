//Name:Abdulrahman Orwah Fahmi Sawalmeh.
//ID:1221574.
//Lab section:3L.
public interface Payable {
    boolean isAuthorized();
}
