//Name:Ellen_Izz,ID:1220806,lecture section:3.lab section:5
package project1;

public class Check extends CustomerPayment implements Payable{
	 
	public static final int CASHIER=1,CERTIFIED=2,PERSONAL=3;
	private int accountNumber;
	private double accountBalance;
	private int type;
			 
	
	public Check() {
	}
	public Check(String customerName, int customerId, double amount,int accountNumber, double accountBalance, int type) {
		super(customerName,customerId,amount);
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	@Override
	protected double CalculatePayment(){
		  return this.amount;
		
	}
	public void deductAmoutFromBalance() {
		this.accountBalance=this.accountBalance-amount;
		
	}
	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type+","+super.toString() ;
	}
	 
	@Override
	public  boolean isAuthorized() {
		//if the type is cashier then it is authorized 
		//if the type is not cashier then deductAmount from Balance  
		
		if(type==CASHIER) {
		return true;
	}
		else if(amount<accountBalance||amount==accountBalance) { 
			this.deductAmoutFromBalance();
			
			
				return true;
		}
		else
			return false;	 
       }
}
