//Layan Salem Salem 
//1221026
//sec:4L
package javaProject;

public interface Payable {
 public abstract boolean isAuthorized();
}
