//marwa mahmmoud faqeeh 1220039 s10
public class Cash extends Customerpayment {
	private double discountRate;

	public Cash() {

	}

	public Cash(String customerName, int customerID, double amount, double discountRate) {
		super(customerName, customerID, amount);
		this.discountRate = discountRate;

	}

	public double getDiscounRate() {
		return discountRate;
	}

	public void setDiscounRate(double discounRate) {
		this.discountRate = discounRate;
	}

	public double calculatePayment() {
		return amount - (amount * (discountRate / 100));

	}

	@Override
	public String toString() {
		return "Cash [discountRate=" + discountRate + ", customerName=" + customerName + ", customerID=" + customerID
				+ ", amount=" + amount + "]";
	}


}
