package ProjectOneJava;
//an interface with an abstract method isAuthorized 
public interface Payable {
   public boolean isAuthorized();
}
