//subset class from customerPayment and implement interface payable by implementing the method isAuthorized()
public class Check extends CustomerPayment implements Payable{
	
	private int accountNumber;
	private double accountBalance;
	private int type;
	//variable type int which (constant) so we use final  
	public static final int CASHIER=1;
	public static final int CERTIFIED=2;
	public static final int PERSONAL=3;
	
	public Check () {//no argument costructor 
		super();
	}
	
	public Check (String customerName,int customerId,double amount,int accountNumber,double accountBalance,int type) {//parametrization constructor
		super(customerName,customerId,amount);//for CustomerPayment probalities
		this.accountNumber=accountNumber;
		this.accountBalance=accountBalance;
		this.type=type;
	}
    //setters and getters
	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
	//payment return the same as the the amount entered
	@Override
	public double calculatePayment() {
		return getAmount();
	}
	//dedcut the amount of authorized check payments (CERTIFIED and PERSONALjusttt not CASHIER)
	public void deductAmountFromBalance() {
		if(type == CERTIFIED || type == PERSONAL) {
			accountBalance-=getAmount();
		}	
	}
	@Override
	public boolean isAuthorized() {
		if(type==CASHIER || getAmount()<=accountBalance) {//if the type of the check CASHIER or if the amount of the payment is less than or equal accountBalance
			deductAmountFromBalance();//call the deductAmountFromBalance() inside the check class isAuthorized()
		return true;
		}
		
		else {//other wise it is not authorized
			return false;
		}
	}
	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type +","+ super.toString();
	}
	
}
