//Name:Ellen_Izz,ID:1220806,lecture section:3.lab section:5
package project1;

public interface Payable {
	public abstract boolean isAuthorized();

}
