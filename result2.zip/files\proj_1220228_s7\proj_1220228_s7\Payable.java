/*Labiba Sharia 
  1220228
  lab 7 */
 
package project;

public interface Payable {
	
	public boolean isAuthorized();

}
