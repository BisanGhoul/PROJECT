/**
 * 
 */
/**
 * @author DELL
 *
 */
module newProject {
}