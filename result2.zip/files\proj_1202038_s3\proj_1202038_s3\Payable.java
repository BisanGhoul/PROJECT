/*
 Sahar Hazem Hatem Hmidat 
 1202038
 3L
 */
package project;

public interface Payable {
	
	public boolean isAuthorized();
}
