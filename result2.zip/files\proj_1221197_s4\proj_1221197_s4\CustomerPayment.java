package Project;
/*     Name  :Maisam Ayed Iftayeh
ID num  :1221197
lecture sec:3
lab sec  :4 */

public abstract class CustomerPayment implements Comparable <CustomerPayment> {
	protected String customerName;
	protected int customerId;
	protected double amount;
	
	public CustomerPayment() {
	}
	
	public CustomerPayment(String customerName, int customerId, double amount) {
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
	}

	public String getCustomerName() {
		return customerName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public double getAmount() {
		return amount;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "CustomerPayment [customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount
				+ "]";
	}
	@Override
	public int compareTo(CustomerPayment c) {
		if(calculatePayment()>c.calculatePayment())
			return -1;
		else if(calculatePayment()<c.calculatePayment())
			return 1;
		else return 0;
		
	}
	protected abstract double calculatePayment();
	void printPaymentInfo() {
		System.out.println(this.toString()+" Payment: " + calculatePayment());
	}
}
