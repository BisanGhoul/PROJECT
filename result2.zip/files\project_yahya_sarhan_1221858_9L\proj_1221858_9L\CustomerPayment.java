//Name: yahya sarhan                       id: 1221858                          lab_sec: 9L     
public abstract class CustomerPayment implements Comparable<CustomerPayment> {

    protected String customerName;
    protected int customerld;
    protected double amount;

    public CustomerPayment() {
    }

    public CustomerPayment(String customerName, int customerld, double amount) {
        this.customerName = customerName;
        this.customerld = customerld;
        this.amount = amount;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getCustomerld() {
        return customerld;
    }

    public void setCustomerld(int customerld) {
        this.customerld = customerld;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    protected abstract double calculatePayment();

    void printPaymentInfo() {
        System.out.println(toString() + " " + calculatePayment());
    }

    @Override
    public String toString() {
        return ", " + "customerName=" + customerName + ", customerld=" + customerld + ", amount=" + amount;
    }

    public int compareTo(CustomerPayment i) {
        return (int) (i.calculatePayment() - calculatePayment());
    }

}
