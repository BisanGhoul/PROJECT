package project;

public interface Payable {
	
	 boolean isAuthorized(); //create an abstract method 
}
