//Name: yahya sarhan                       id: 1221858                          lab_sec: 9L     
public interface Payable {
    public boolean isAuthorized();
}
