package Project;
/*     Name  :Maisam Ayed Iftayeh
ID num  :1221197
lecture sec:3
lab sec  :4 */
import java.util.*;

public class CreditCard extends CustomerPayment implements Payable {
	private double chargingFee;
	private Date expiryDate;

	public CreditCard() {
	}

	public CreditCard(String customerName, int customerId,int amount,double chargingFee, Date expiryDate) {
		super(customerName,customerId,amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}

	public double getChargingFee() {
		return chargingFee;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", customerName="
				+ customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}

	@Override
	public boolean isAuthorized() {
		Date date = new Date();
		if (expiryDate.compareTo(date) <= 0)
			return false;
		else
			return true;
	}

	@Override
	protected double calculatePayment() {
		return amount + chargingFee;
	}

}
