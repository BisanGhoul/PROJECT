// Qusai Assi
// 1211204
// lab_sec_10

package finalproject;

public interface Payable {
	boolean isAuthorized();
}