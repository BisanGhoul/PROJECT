package project1;

public abstract class CustomerPayment implements Comparable<CustomerPayment> {
	
	protected String customerName;
	protected int customerId;
	protected double amount;
	
	public CustomerPayment() {//no_arg constructor
	}
	public CustomerPayment(String customerName,int customerId,double amount ) {//arg constructor
		this.customerName=customerName;
		this.customerId=customerId;
		this.amount=amount;
	}
//setters and getters 
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	//to string method
	public String toString() {
		return "CustomerPayment [customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount
				+ "]";
	}
	protected abstract double calculatePayment();//abstract method 
	
    void printPaymentInfo () {
		System.out.print("\n" +toString());	//calling to string method
		System.out.println(" payment = "+calculatePayment());//calling payment method 
    }
    @Override
    public int compareTo(CustomerPayment obj) {//override for the method compare to coming from th comparable interface
 			if (calculatePayment() >(obj.calculatePayment()))
 				return -1;
 			else if (calculatePayment() <( obj.calculatePayment()))//i do it like this to sort the array in descending way 
 				return 1;
 			else 
 				return 0;		
 		
    }
    
}
