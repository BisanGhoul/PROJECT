//Mohammad Yousef
//1220041
//sec10



package project;

public interface Payable<E> {
public boolean isAuthorized();
}
