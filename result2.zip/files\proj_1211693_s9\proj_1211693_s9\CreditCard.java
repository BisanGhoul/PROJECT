//saleh salameeen
//1211693
//lecture 9

package  prj;
import java.util.*;

public class CreditCard extends CustomerPayment implements Payable <CustomerPayment>{
	
	private double chargingFee;
	private Date expiryDate ;
	
	
	
	public CreditCard() {
			
	}
	
	
	
	
	public CreditCard(String customerName, int customerId, double amount,double chargingFee, Date expiryDate) {
		super( customerName,  customerId,  amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}
	
	
	
	
	
	public double getChargingFee() {
		return chargingFee;
	}
	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}



	
/*
	@Override
	public String toString() {
		return "CreditCard ["+super.toString()+"chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + "]";
	}
	*/
	
	
	
	@Override
	public String toString() {
		return "CreditCard ["+"customerName=" + customerName + ", customerId=" + customerId
				+ ", amount=" + amount +"chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + "]";
	}




	@Override
	double calculatePayment() {
		 
		 return super.amount + this.chargingFee;
	 }
	
	
	
	public boolean isAuthorized() { 
		Date date = new Date();
		
		return  this.expiryDate.getTime() <= date.getTime(); 	
		
	}
	


	@Override
	public int compareTo(CustomerPayment other) {
		 return (int)(  other.calculatePayment() - this.calculatePayment());
	}
	

}
