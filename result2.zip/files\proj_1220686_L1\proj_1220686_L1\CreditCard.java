
import java.util.*;
//DAREEN ABUALHAJ   / 1220686  /  1L
public class CreditCard extends  CustomerPayment implements Payable {

	private double changingFee;
	private Date expiryDate;
	//constructors
	public CreditCard() {

	}
	public CreditCard(String customerName, int customerId, double amount, double changingFee, Date expiryData) {
		super(customerName, customerId, amount);
		this.changingFee = changingFee;
		this.expiryDate = expiryData;
	}

	//getter and setter for ChangingFee
	public double getChangingFee() {
		return changingFee;
	}
	public void setChangingFee(double changingFee) {
		this.changingFee = changingFee;
	}
	//getter and setter for ExpiryData
	public Date getExpiryData() {
		return expiryDate;
	}
	public void setExpiryData(Date expiryData) {
		this.expiryDate = expiryData;
	}
	@Override
	public boolean isAuthorized() {

		Date currentlyDate = new Date(); 
		if(this.expiryDate.compareTo(currentlyDate) >= 0) {
			return true;
		}

		return false;

	}

	public double calculatePayment() {
		// TODO Auto-generated method stub
		return amount+changingFee;
	}

	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + changingFee + ", expiryDate=" + expiryDate + ", customerName="
				+ customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}


}
