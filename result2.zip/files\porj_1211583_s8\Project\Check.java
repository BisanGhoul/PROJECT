package Project;
/*
 *  Name  : Rami Ayman Rimawi
 *   ID   : 1211583
 * LabSec : 8L
 */
public class Check extends CustomerPayment implements Payable{
	private int accountNumber;
	private double accountBalance;
	private int type;
	static final int CASHIER = 1;
	static final int CERTIFIED = 2;
	static final int PERSONAL = 3;
	
	public Check() {
		
	}
	public Check(String customerName, int customerId, double amount,int accountNumber, double accountBalance, int type) {
		super(customerName, customerId, amount);
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
	}
	
	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		if(type == CASHIER) 
			this.type = 1;
		else if(type == CERTIFIED)
			this.type = 2;
		else if(type == PERSONAL)
			this.type = 3;
	}

	@Override
	public boolean isAuthorized() {
		if(type == CASHIER || amount <= this.accountBalance) {
			deductAmountFromBalance();
			return true;
		}
		return false;
	}
	
	@Override
	protected double calculatePayment() {
		return this.amount;
	}
	
	public void deductAmountFromBalance() {
		if(this.type == CERTIFIED || this.type == PERSONAL)
			accountBalance -= amount;
	}
	
	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type
				+ ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}
}
