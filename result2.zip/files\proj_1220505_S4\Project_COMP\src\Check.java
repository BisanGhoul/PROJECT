//Yara Qaraqe
//1220505
//lab 4l
public class Check extends CustomerPayment implements Payable{
    public static final int CASHIER = 1;
    public static final int CERTIFIED = 2;
    public static final int PERSONAL = 3;

    private int accountNumber;
    private double accountBalance;
    private int type;

    public Check() {
    }

    public Check(String customerName, int customerId, double amount, int accountNumber, double accountBalance, int type) {
        super(customerName, customerId, amount);
        if (type == CASHIER || type == CERTIFIED || type == PERSONAL) {
            this.type = type;
        } else {
            System.out.println("Invalid type for Check");
        }
        this.accountNumber = accountNumber;
        this.accountBalance = accountBalance;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public double getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        if (type == CASHIER || type == CERTIFIED || type == PERSONAL) {
            this.type = type;
        } else {
            System.out.println("Invalid type for Check");
        }
    }

    @Override
    public String toString() {
        return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type + ", customerName=" + super.customerName + ", customerId=" + super.customerId + ", amount=" + super.amount + "]";
    }

    @Override
    protected double calculatePayment() {
        return getAmount();
    }

    public boolean isAuthorized() {
        boolean authorized = this.type == CASHIER || this.getAmount() <= this.accountBalance;
        if (authorized && (this.type == CERTIFIED || this.type == PERSONAL)) {
            deductAmountFromBalance();
        }
        return authorized;
    }
    public void deductAmountFromBalance() {
        this.accountBalance -= this.getAmount();
    }
}

