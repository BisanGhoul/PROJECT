//Yara Qaraqe
//1220505
//lab 4l
public interface Payable {
    public abstract boolean isAuthorized();
}
