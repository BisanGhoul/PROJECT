//nawras eyad omar yacoob,1221904,sec3,lab5//
package CustomerPackage;

import java.util.*;

public class Driver {

    public static void main(String[] args) {
        ArrayList<CustomerPayment> payments = new ArrayList<CustomerPayment>();
        CustomerPayment C_Cash = new Cash("Ahmad", 4444, 150, 5.0);
        payments.add(C_Cash);

        CustomerPayment C_Check1 = new Check("Rana", 7777, 400, 1111, 350, Check.PERSONAL);
        if (((Check) C_Check1).isAuthorized()) {
			payments.add(C_Check1);
		}

        CustomerPayment C_Check2 = new Check("Suha", 5555, 100, 1111, 200, Check.CASHIER);
        if (((Check) C_Check2).isAuthorized()) {
			payments.add(C_Check2);
		}

        CustomerPayment C_Check3 = new Check("Rania", 7777, 600.0, 1111, 750, Check.CERTIFIED);
        if (((Check) C_Check3).isAuthorized()) {
			payments.add(C_Check3);
		}

        CustomerPayment C_CreditCard1 = new CreditCard("Randa", 9999, 170, 20, new Date(124, 05, 03));
        if (((CreditCard) C_CreditCard1).isAuthorized()) {
			payments.add(C_CreditCard1);
		}

        CustomerPayment C_CreditCard2 = new CreditCard("Hani", 6666, 150, 10, new Date(120, 06, 07));
        if (((CreditCard) C_CreditCard2).isAuthorized()) {
			payments.add(C_CreditCard2);
		}

        Collections.sort(payments);
        for (int i = 0; i < payments.size(); i++) {
            payments.get(i).printPaymentInfo();
        }
    }

}
