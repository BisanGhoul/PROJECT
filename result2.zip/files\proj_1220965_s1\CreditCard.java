import java.util.*;
//subset class from customerPayment and implement interface payable by implementing the method isAuthorized()
public class CreditCard extends CustomerPayment implements Payable{
	private double chargingFee;
	private Date expiryDate;
	
	public CreditCard() {//no argument constuctor to CreditCard class
		super();
	}
	
	public CreditCard(String customerName,int customerId,double amount, double chargingFee,Date expiryDate) {
		super(customerName,customerId,amount);//calling super class
		this.chargingFee=chargingFee;
		this.expiryDate=expiryDate;
	}
    //setters and getters for CreditCard class
	public double getChargingFee() {
		return chargingFee;
	}

	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	//the method for calculating payment creditCard class, payment is the amount plus the chargingFee
	@Override
	public double calculatePayment() {
		return getAmount()+this.chargingFee;
	}
	@Override
	public boolean isAuthorized(){
		Date T=new Date();//T is a current date
		return expiryDate.compareTo(T)>=0;//A CreditCard payment is authorized if its expiryDate is less than or equal the current date
		
	}
	//to string for CreditCard class
	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate +","+ super.toString();
	}
	


}
