/*name: izzeldeen sallam
 *id : 1222285
 * lab sec : 3
 * 
 * 
 * */
package project;

import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable{
	private double chargingFee;
	private Date expiryDate;
	Date currentDate = new Date();
	
	public CreditCard(){
		
	}

	public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
		super(customerName, customerId, amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}
	
	

	public double getChargingFee() {
		return chargingFee;
	}

	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public boolean isAuthorized() {//check if authorized
		
		if(expiryDate.compareTo(currentDate) >= 0) {
			return true;
		}
		else
			return false;
	}


	@Override
	protected double calculatePayment() {//adding the chargingfee amount 
		
		return super.amount + chargingFee;
	}

	

	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", customerName="
				+ customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}

	
	
	
	
 }
