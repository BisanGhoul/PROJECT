//Malak Hamdi Obaid
//1220203 
//Lab section 5
package proj_1220203_sec5;

public interface Payable {
	 boolean isAuthorized();
}
