/* Nagham Massis
 * 1220149
 * Lab-Sec = 7
 */
package Project;

public class Cash extends CustomerPayment {
	private double discountRate;
	
	public Cash() {
	}

	public Cash(String customerName, int customerId, double amount,double discountRate) {
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
		this.discountRate = discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}
	
	public double getDiscountRate() {
		return discountRate;
	}

	@Override
	public String toString() {
		return "Cash [discountRate=" + discountRate + ", customerName=" + customerName + ", customerId=" + customerId
				+ ", amount=" + amount + "]";
	}

	@Override
	protected double calculatePayment() {
		return amount - amount * (discountRate / 100);
	}

}
