//  Ahmad Rahimi, 1220890 , s6
package project;

public interface Payable {

	public boolean isAuthorized();
}
