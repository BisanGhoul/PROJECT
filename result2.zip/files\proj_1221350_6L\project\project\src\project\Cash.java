package project;
/*
Name:Mohammad Abu Hijleh
ID: 1221350
Lab Section: 6L
*/
public class Cash extends CustomerPayment{
    private double discountRate;

    public Cash() {
        super();
        discountRate= 0.0;
    }

    public Cash(String customerName, int customerId, double amount, double discountRate) {
        super(customerName, customerId, amount);
        this.discountRate = discountRate;
    }

    public double getDiscountRate() {
        return discountRate;
    }

    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }

    @Override
    protected double calculatePayment() {
        return amount- ((discountRate/100)*amount);
    }

    @Override
    public String toString() {
        return "cash{" +
                "discountRate=" + discountRate +
                ", customerName='" + customerName + '\'' +
                ", customerId=" + customerId +
                ", amount=" + amount +
                '}';
    }
}
