/*
 * String name = "Yazeed Alhaddad";
 * int id = 1221902;
 * int labSec = 2;
 */
package ps;

import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable{
	//vars
	private double chargingFee;
	private Date expiryDate;
	Date currentDate = new Date();
	//no-arg constructor
	public CreditCard(){}
	//all-arg constructor
	public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
		super(customerName, customerId, amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}
	//getter
	public double getChargingFee() {
		return chargingFee;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}
	//setter
	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	//overrided methods
	@Override
	public boolean isAuthorized() {
		if(expiryDate.compareTo(currentDate) >= 0) return true;
		else return false;
	}

	@Override
	protected double calculatePayment() {
		return super.amount + chargingFee;
	}

	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}
 }
