//Name:Yasmin_Al_Shawawrh
//ID:1220848
//Lecture:3
//Lap:4

package project;

public class Check extends CustomerPayment implements Payable {//It is a subclass for the CustomerPayment and implements the payable interface
	private int accountNumber;//private: accessible from this class just
	private double accountBalance;//private: accessible from this class just
	private int type;//private: accessible from this class just
	
	final static int CASHIER=1;
	final static int CERTIFIED=2;
	final static int PERSONAL=3;
	//constants and because they are static we can call them in static method by the class name without define an object 

	public Check() {
		//no-arg constructor
	}
	public Check(String customerName, int customerld, double amount,int accountNumber, double accountBalance, int type) {//constructor with arguments (constructor from the superclass)
		//superclass constructor aren't inherited but we can invoked it by using super keyword
		super(customerName, customerld, amount);//call superclass constructor(with arguments)
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
	}
	public Check(int accountNumber, double accountBalance, int type) {//constructor with arguments (constructor using fields)
		//superclass constructor aren't inherited but we can invoked it by using super keyword
		super();//call superclass constructor(with no-arg) 
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
	}
	public int getAccountNumber() {//The get method returns accountNumber value
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {//The set method sets the value
		this.accountNumber = accountNumber;
	}
	public double getAccountBalance() {//The get method returns accountBalance value
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {//The set method sets the value
		this.accountBalance = accountBalance;
	}
	public int getType() {//The get method returns type value
		return type;
	}
	public void setType(int type) {//The set method sets the value
		this.type = type;
	}
	@Override
	public String toString() {//The toString method returns the String representation of the object
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type +super.toString()+ "]";//we use super to call superclass method
	}
	@Override
	public boolean isAuthorized() {//A Check payment is authorized if either the type of the check is CASHIER or if the amount of the payment is less than or equal to the accountBalance, otherwise it is not authorized.
		if(type == CASHIER || amount <= accountBalance) {
			deductAmountFromBalance() ;//if it's Authorized we deduct the amount from the accoutBalane 
			return true;//return true because it is Authorized
		}
		else 
		{
			return false;//return false because it isn't Authorized
		}
	}
	@Override
	protected double calculatePayment() {//This method is calculated the payment which is the same as the amount entered.
		return amount;
	}
	public void deductAmountFromBalance() {//this method is deduct the amount of authorized Check payments 
		if(type!=CASHIER)
		accountBalance-=getAmount();
	}

}
