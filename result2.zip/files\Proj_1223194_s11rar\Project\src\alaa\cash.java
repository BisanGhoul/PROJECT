// Alaa Mansour 1223194 lab section 11
package alaa;

class cash extends CustomerPayment {
    private double discountRate;

    public cash(String customerName, int customerID, double amount, double discountRate) {
        super(customerName, customerID, amount);
        this.discountRate = discountRate;
    }
    
    

    public double getDiscountRate() {
		return discountRate;
	}



	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}



	@Override
    public double calculatePayment() {
        return amount - (amount * (discountRate / 100.0));
    }

    @Override
    public String toString() {
        return "Cash [discountRate=" + discountRate + ", " + super.toString() + "]";
    }



	@Override
	public int compareTo(CustomerPayment other) {
		return Double.compare(other.calculatePayment(), this.calculatePayment());
	}



	
}



