//Name:Noor Nasir
//ID:1220769
//Lab Section : 11L

public class Cash extends CustomerPayment  {
	private double discountRate;
	public Cash() {
		
	}

	//Cash ( customerName, customerId, amount, discountRate )
 public Cash(String customerName, int customerId, double amount, double discountRate ) {
		super(customerName, customerId, amount);
		this.discountRate=discountRate;
	}

public double getDiscountRate() {
	return discountRate;
}

public void setDiscountRate(double discountRate) {
	this.discountRate = discountRate;
}


@Override
protected double calculatePayment() {
	return amount-discountRate/100*amount;

}

@Override
public String toString() {
    return "Cash [discountRate=" + discountRate + ", customerName=" + customerName +
            ", customerId=" + customerId + ", amount=" + amount + "]";
}



}
