// Name : Amir Rasmi Al-Rashayda
// ID_Num : 1222596
// LabSec : 5 

    // cash class extends the abstract class CustomerPayment
    public class Cash extends CustomerPayment {
        // private variable "-"
        private double discountRate; // discount rate for cash payments

        // full const
        public Cash(String customerName, int customerId, double amount, double discountRate) {
            super(customerName, customerId, amount); // calling the constructor of the superclass
            this.discountRate = discountRate; // Initializing discountRate with the passed value
        }

        // No argu const
        public Cash() {

        }

        // getter/setter methods
        public double getDiscountRate() {
            return discountRate;
        }

        public void setDiscountRate(double discountRate) {
            this.discountRate = discountRate;
        }

        // Overriding the calculatePayment method from the superclass
        @Override
        protected double calculatePayment() {
            // calculating the payment after applying the discount
            return amount - (amount * discountRate / 100);
        }

        // Overriding the toString method from the superclass
        @Override
        public String toString() {
            // Returning a string representation of the object exactly as shown in the example
            return "Cash [" +
                    "discountRate=" + discountRate +
                    ", customerName=" + customerName +
                    ", customerId=" + customerId +
                    ", amount=" + amount +
                    ']';
        }
    }
