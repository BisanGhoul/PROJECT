/*name: izzeldeen sallam
 *id : 1222285
 * lab sec : 3
 * 
 * 
 * */
package project;

public class Check extends CustomerPayment implements Payable {
private int accountNumber;
private double accountBalance;
private int type;
public static final int CASHIER=1;
public static final int CERTIFIED=2;
public static final int PERSONAL=3;

 public Check(){
	
}

public Check(String customerName, int customerId, double amount, int accountNumber, double accountBalance, int type) {
	super(customerName, customerId, amount);
	this.accountNumber = accountNumber;
	this.accountBalance = accountBalance;
	this.type = type;
}

public int getAccountNumber() {
	return accountNumber;
}

public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}

public double getAccountBalance() {
	return accountBalance;
}

public void setAccountBalance(double accountBalance) {
	this.accountBalance = accountBalance;
}

public int getType() {
	return type;
}

public void setType(int type) {
	this.type = type;
}

@Override
protected double calculatePayment() {//no change in the value
	
	return super.amount;
}



@Override
public String toString() {
	return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type
			+ ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
}



public void deductAmountFromBalance() {
	this.accountBalance = this.accountBalance - this.amount;
}

@Override
public boolean isAuthorized() {//checking the authorization
	
	if(type == CASHIER || this.amount <= getAccountBalance()) {
		
		if(type == CERTIFIED || type == PERSONAL) {
			
			deductAmountFromBalance();
		}
		
		return true;
	}
	else
		return false;
}





}
