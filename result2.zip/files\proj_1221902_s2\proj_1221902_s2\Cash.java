/*
 * String name = "Yazeed Alhaddad";
 * int id = 1221902;
 * int labSec = 2;
 */
package ps;
//Create subclass of CustomerPayment
public class Cash extends CustomerPayment {

	private double discountRate;
	//no-arg constructor
	public Cash(){}

	//all-arg constructor
	public Cash(String customerName, int customerId, double amount ,double discountRate) {
			super(customerName, customerId, amount);
			this.discountRate = discountRate;
		}
	//getter
	public double getDiscountRate() {
		return discountRate;
	}
	//setter
	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}

	//override toString method
	@Override
	public String toString() {
		String rt = "Cash [discountRate=" + discountRate + ", customerName=" + customerName + ", customerId=" + customerId+ ", amount=" + amount + "]";
		return rt;
	}
	//override calculatePament
	@Override
	protected double calculatePayment(){
		return amount - (amount * (discountRate/100.0));
	}
}
