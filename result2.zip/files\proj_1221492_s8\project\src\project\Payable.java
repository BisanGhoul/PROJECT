/*Name: Maria Massad / ID:1221494 / lab_sec:8 */
package project;

public interface Payable {
public boolean isAuthorized ();

}
