// Name: [ Faris Ahmad Sawalmeh ].
// Id: [ 1220013 ].
// Lap Section No: [ 6L ].

public interface Payable{
    public boolean isAuthorized();
}