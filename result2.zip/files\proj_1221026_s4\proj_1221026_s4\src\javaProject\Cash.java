//Layan Salem Salem 
//1221026
//sec:4L
package javaProject;

public class Cash extends CustomerPayment {
	
private double discountRate;


public Cash() {
	
}


public Cash(String customerName, int customerId, double amount,double discountRate) {
	super(customerName,  customerId, amount);
	this.discountRate = discountRate;
}


public double getDiscountRate() {
	return discountRate;
}


public void setDiscountRate(double discountRate) {
	this.discountRate = discountRate;
}

@Override
protected   double calculatePayment() {
	return amount-(amount*discountRate/100);
}


@Override
public String toString() {
	return "Cash [discountRate=" + discountRate + ", customerName=" + customerName + ", customerId=" + customerId
			+ ", amount=" + amount + "]";
}


}
