//Name: Ali hamdan     ID: 1221227      Lab sec: 9
package javaproject;

public interface Payable {
	public boolean isAuthorized();
}
