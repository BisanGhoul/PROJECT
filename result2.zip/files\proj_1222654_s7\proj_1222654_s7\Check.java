//Aya abdelrahman fares shejaya ,1222654,lab 7

package proj;


//Class for check payment, extends CustomerPayment and implements Payable {
class Check extends CustomerPayment implements Payable {
	 // Constants for check types
    public static final int CASHIER = 1;
    public static final int CERTIFIED = 2;
    public static final int PERSONAL = 3;
    
    private int type;
    private int accountNumber;
    private double accountBalance;
    


 // Constructor to initialize customer name, customer ID, payment amount, account number, account balance, and check type
    public Check(String customerName, int customerId, double amount, int accountNumber, double accountBalance, int type) {
        super(customerName, customerId, amount);
        this.accountNumber = accountNumber;
        this.accountBalance = accountBalance;
        this.type = type;
    }

 // Method to calculate payment amount that returns the amount
    @Override
    protected double calculatePayment() {
        return amount;
    }

 // Method to check if payment is authorized based on check type and account balance
    @Override
    public boolean isAuthorized() {
        if (type == CASHIER || amount <= accountBalance) {
        	deductAmountFromBalance();
            return true;
        } else {
            return false;
        }
    }

 // Method to deduct payment amount from account balance (if the check type is certified or personal)
    public void deductAmountFromBalance() {
        if (type == CERTIFIED || type == PERSONAL) {
            accountBalance = accountBalance - amount;
        }
    }

    @Override
    public String toString() {
        return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type + ", " + super.toString() + "]";
    }

   // Getters and Setters
    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public double getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}

