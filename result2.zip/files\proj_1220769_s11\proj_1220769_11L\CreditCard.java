//Name:Noor Nasir
//ID:1220769
//Lab Section : 11L

import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable {
private double chargingFee;
private Date expiryDate;

public CreditCard() {
	
}
//CreditCard ( customerName, customerId, amount, chargingFee, expiryDate)
public CreditCard(String customerName, int customeId, double amount, double chargingFee, Date expiryDate ) {
	super(customerName, customeId, amount);
	this.chargingFee=chargingFee;
	this.expiryDate=expiryDate;
	
	
}

public double getChargingFee() {
	return chargingFee;
}
public void setChargingFee(double chargingFee) {
	this.chargingFee = chargingFee;
}
public Date getExpiryDate() {
	return expiryDate;
}
public void setExpiryDate(Date expiryDate) {
	this.expiryDate = expiryDate;
}
@Override
protected double calculatePayment() {
	return 	(amount+chargingFee);

}

@Override
public boolean isAuthorized(){
	Date currentDate = new Date();
	if(expiryDate!=null && !expiryDate.before(currentDate)) {
		return true;
}
	else {
		return false;
	}
}

@Override
public String toString() {
    return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate +
            ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
}



}
