package projectjava;
/*sara shrouf
 1220481
 lap8
 */
public class Cash extends CustomerPayment  {
	
    public Cash() {
		super();
		
	}
   public Cash(String customerName, int customerId, double amount,double discountRate) {
		super(customerName, customerId, amount);
		this.discountRate= discountRate;
	}
	private double discountRate;

	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}

	

	
	@Override
	public double calculatePayment() {
		return this.amount-(this.amount*(this.discountRate/100));
	}
	@Override
	public String toString() {
		return "cash[discountRate= "+this.discountRate +super.toString()+"]";
	}
	

}
