//Aya abdelrahman fares shejaya ,1222654,lab 7

package proj;
//Interface defining a Payable entity
public interface Payable {
	// Method to check if payment is authorized
    boolean isAuthorized();
}
