package project;
/*Ali Mashour Mohammad Kok
 * 1220375
 * Lab 4
 */
@SuppressWarnings("hiding")
public interface Payable<Object > {
	
	public boolean isAuthorized();

}
