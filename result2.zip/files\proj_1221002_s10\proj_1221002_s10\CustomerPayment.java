//Name:Tawba Atta Ibrahim Abdallah Id:1221002 Sec:10L.
package projectjava;

public abstract class CustomerPayment implements Comparable<CustomerPayment>{
 protected String customerName;
protected int  customerId;
 protected double  amount ;
 protected abstract double calculatepayment();
  void printPaymentInfo(){
   System.out.println(toString()+calculatepayment());
}
  public CustomerPayment() {
	  super();
	  this.customerName=null;
	  this.customerId=0;
	  this.amount=0.0;
	 
  }

	public CustomerPayment(String custumerName, int custumerId, double amount) {
		
		this.customerName = custumerName;
		this.customerId = custumerId;
		this.amount = amount;
	}
   public String getCustumerName() {
		return customerName;
	}
	public void setCustumerName(String custumerName) {
		this.customerName = custumerName;
	}
	public int getCustumerId() {
		return customerId;
	}
	public void setCustumerId(int custumerId) {
		this.customerId = custumerId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount+"]";
	}
	@Override
     public int compareTo(CustomerPayment ob){
		if ((ob).calculatepayment()>this.calculatepayment()) {
			return 1;
		}else if ((ob).calculatepayment()<this.calculatepayment()) {
			return -1;
		}else {
			return 0;
		}
    	
		
		
	}
	
}
