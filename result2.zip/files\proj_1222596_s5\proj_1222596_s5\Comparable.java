// Name : Amir Rasmi Al-Rashayda
// ID_Num : 1222596
// LabSec : 5 
interface Comparable {
    public int compareTo();
}