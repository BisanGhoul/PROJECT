/* Name:Dina Daoud
 * ID:1221928
 * Lab Section "6"
 */
package project;
// SuperClass CustomerPayment that implements the interface Comparable 
public abstract class CustomerPayment implements Comparable<CustomerPayment>{
	//defining data fields 
	protected String customerName;   
	protected int customerId;
	protected double amount;
	//n-ard constructor
	public CustomerPayment() {
		
	}
	//
	public CustomerPayment(String customerName, int customerId, double amount) {
		super();   //for SuperCalss object 
		this.customerName = customerName;  //set the value the user enters inside customerName
		this.customerId = customerId;
		this.amount = amount;
	}
    // Setters and Getters to set and get data fields
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	
	public int getCustomerId() {
		return customerId;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	public double getAmount() {
		return amount;
	}

	protected abstract double calculatePayment();  //abstract method which is common between subclasses Cash , Check and CreditCard 
	
	// overriding 
	//compareTo interface to compare the objects created from the subclasses according to Calculating Payment in descending order
	@Override
	public int compareTo(CustomerPayment c){
		if (calculatePayment()>c.calculatePayment())       
	       return -1;
	    else if (calculatePayment()<c.calculatePayment())
	       return 1;
	    else
	       return 0;
	}

	
	@Override
	public String toString() {
		return "CustomerPayment [customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount
				+ "]";
	}
    //To print the information on the screen
	public void printPaymentInfo() {
		System.out.println(toString()+" payment = "+calculatePayment());
	}
}
