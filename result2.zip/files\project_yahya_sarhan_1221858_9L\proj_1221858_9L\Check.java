//Name: yahya sarhan                       id: 1221858                          lab_sec: 9L     
public class Check extends CustomerPayment implements Payable {

    private int accountNumber;
    private double accountBalance;
    private int type;
    final static int CASHIER = 1;
    final static int CERTIFIED = 2;
    final static int PERSONAL = 3;

    public Check() {

    }

    public Check(String customerName, int customerld, double amount, int accountNumber, double accountBalance,
            int type) {
        super(customerName, customerld, amount);
        this.accountNumber = accountNumber;
        this.accountBalance = accountBalance;
        this.type = type;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public double getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public void deductAmountFromBalance(double amount) {
        this.accountBalance -= amount;
    }

    @Override
    public boolean isAuthorized() {
        if (type == CASHIER || calculatePayment() <= accountBalance) {
            return true;
        } else if (this.type == Check.CERTIFIED || this.type == Check.PERSONAL && calculatePayment() < accountBalance) {
            this.deductAmountFromBalance(calculatePayment());

            return true;
        } else
            return false;
    }

    @Override
    public String toString() {
        return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type + ""
                + super.toString() + "]" + " " + "Payment = ";
    }

    @Override
    protected double calculatePayment() {
        return amount;
    }

    @Override
    void printPaymentInfo() {
        System.out.println(toString() + calculatePayment());
    }
}
