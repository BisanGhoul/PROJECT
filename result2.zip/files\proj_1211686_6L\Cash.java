//name: malik arqoup
//id = 1211686
public class Cash extends  CustomerPayment{
    private double discountRate ;

    public Cash() {
    }

    public Cash(String customerName, int customerld, double amount, double discountRate) {
        super(customerName, customerld, amount);
        this.discountRate = discountRate;
    }

    public void setDiscountRate(double discountRate) {
       this.discountRate = discountRate;
    }

    public double getDiscountRate() {
        return discountRate;
    }

    @Override
    public double CalculatePatment(){
        double x =getAmount() - (getAmount()*(getDiscountRate()/100));

        return x;
    }



    @Override
    public String toString() {
        return "Cash[" +
                "DiscountRate=" + discountRate +
                super.toString();

    }
}
