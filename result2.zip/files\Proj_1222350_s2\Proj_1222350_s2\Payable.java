//Samir Ali , 1222350 , Lab sec.2

package project;

public interface Payable {

    public boolean isAuthorized();
}
