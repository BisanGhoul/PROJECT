package projectjava;

/*sara shrouf
122081
lap 8*/
public abstract  class CustomerPayment implements Comparable<CustomerPayment>{
	protected String customerName;
	protected int customerId;
	protected double amount;
	
	public CustomerPayment() {
		
	}

	public CustomerPayment(String customerName, int customerId, double amount) {
		super();
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
	}
	
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public abstract double calculatePayment() ;
	
	@Override
	public String toString() {
		return " customerName: "+this.customerName+" customerId: "+this.customerId+" amount: "+this.amount;
	}
	public void printPaymentInfo() {
		System.out.println(toString()+ " Payment = "+this.calculatePayment());
		
	}
	@Override
	public int compareTo (CustomerPayment other) {
		return Double.compare(other.calculatePayment(),this.calculatePayment());
	}
	
		
	
	
	
}
