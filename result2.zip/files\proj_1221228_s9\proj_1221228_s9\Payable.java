//Name : Mohamad Tahan 
//ID : 1221228
//LAB SECTION : 9
public interface Payable {
	
	public boolean isAuthorized();
	
}