package project;
//Name:Mohammad Khawaja 		ID:1220153  	 LAB:1 		 SEC:1
public class Cash extends CustomerPayment {
	private double discountRate;

	public Cash() {
		super();
	}

	public Cash(String customerName, int customerId, double amount, double discountRate) {
		super(customerName, customerId, amount);
		this.discountRate = discountRate;
	}

	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}

	@Override
	protected double calculatePayment() {
		double Payment = amount - amount * (discountRate / 100);
		return Payment;
	}

	@Override
	public String toString() {
		return "Cash [discountRate=" + discountRate + super.toString() + "]";
	}

	@Override
	public int compareTo(CustomerPayment o) {
		if (this.calculatePayment() > o.calculatePayment()) {
			return -1;
		} else if (this.calculatePayment() < o.calculatePayment()) {
			return 1;
		} else {
			return 0;
		}
	}

}
