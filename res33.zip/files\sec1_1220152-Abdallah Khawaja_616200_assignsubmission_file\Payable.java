//Name :Abdallah Khawaja  ID:1220152   SEC:1   LAB:1
package project1;

public interface Payable {
	public boolean isAuthorized();
}