/*name:manar zitawi
id:1221806
sec 1*/
package project;

import java.util.Date;

public class CreditCard extends CustomerPayment implements Payaple{
	private double chargingFee;
	private Date expiryDate;
	
	public CreditCard() {
	}
	
	public CreditCard(String customerName, int customerId, double amount,double chargingFree,Date expiryDate) {
		super(customerName,  customerId, amount);
		this.chargingFee=chargingFree;
		this.expiryDate=expiryDate;
	}

	public double getChargingFree() {
		return chargingFee;
	}

	public void setChargingFree(double chargingFree) {
		this.chargingFee = chargingFree;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	 @Override
	    public double calculatePayment() {
	        return super.amount + chargingFee;
	    }
	
	    public boolean isAuthorized() {
	        Date currentDate = new Date();
	        return expiryDate.compareTo(currentDate) >= 0;
	    }

		@Override
		public String toString() {
			return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", customerName="
					+ customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
		}
	

}
