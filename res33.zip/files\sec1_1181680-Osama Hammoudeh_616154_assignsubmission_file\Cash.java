
//osama hammoudeh 1181680 dr.mohammad helal-1
package project;

public class Cash extends CustomerPayment {
    private double discountRate;

    public Cash(String customerName, int customerId, double amount, double discountRate) {
        super(customerName, customerId, amount);
        this.discountRate = discountRate;
    }

    @Override
    public double calculatePayment() {
        return super.amount * (1 - discountRate / 100);
    }

    @Override
    public String toString() {
        return "Cash{" + "discountRate=" + discountRate +"} " + super.toString();
    }
}
