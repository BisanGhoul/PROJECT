package Projc1;

//elissarKharoub1220433sec1

public abstract class CustomerPayment implements Comparable<CustomerPayment>{ 
	
	
	protected String customerName;
	
	protected int customerId;
	
	protected double amount;
	
	public CustomerPayment() {//no argument constructor
		
	}
public CustomerPayment(String customerName,int customerId,double amount) {// constructor with parameter
	  
	 this.customerName = customerName;
	 this.customerId = customerId;
	 this.amount=amount;
		
	}
	

public String getCustomerName() {
	  
	 return customerName;
}
public void setCustomerName(String customerName) {
	 
	this.customerName = customerName;
}
public int getCustomerId() {
	 
	return customerId;
}
public void setCustomerId(int customerId) {
	
	this.customerId = customerId;
}
public double getAmount() {
	 
	return amount;
}
public void setAmount(double amount) {
	
	this.amount = amount;
}

protected  abstract  double CalculatePayment(); // without body 
	 
	 

public void printPaymentInfo() {
	  
	//print the properties and the calculated payment by calling both the toString as well as the calculatePaymentsmethods
	  	  
	// CalculatePayment();
	  
	System.out.println(toString());
	
	System.out.println(" Payment = " + CalculatePayment());
	  
}

@Override
public String toString() {
	 
	return "CustomerPayment [customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
}

@Override

public int compareTo(CustomerPayment p) {
	 
	 if(this.CalculatePayment()<p.CalculatePayment())//due to descending
	 
        return 1;

 else if(this.CalculatePayment()>p.CalculatePayment())

        return -1;
 else

        return 0;	 

}

}

