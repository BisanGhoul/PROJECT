//AbdullahSadaqa , 1220321 , 1

package project1;

public class Cash extends CustomerPayment {

	private double discountRate;

	public Cash(String customerName , int customerId ,double amount, double discountRate) {
		super(customerName , customerId , amount);
		this.discountRate = discountRate;
	}


	public double getDiscountRate() {
		return discountRate;
	}


	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}
	
	protected double calculatePayment() {
		double b = discountRate/100;
		return super.amount-(super.amount*b);
		
	}
	
	public String toString () {
	return "Cash[" + "discountRate=" + discountRate +super.toString()+']';
	
	}
}
