//AbdullahSadaqa , 1220321 , 1
package project1;

import project1.CustomerPayment;

public abstract class CustomerPayment implements Comparable<CustomerPayment>{
	protected String customerName; 
	protected int customerId ;
	protected double amount ;
	
	public CustomerPayment(String customerName, int customerId, double amount) {
		
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
	}
	
	public CustomerPayment() {
	}
	




	public String getCustomerName() {
		return customerName;
	}



	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}



	public int getCustomerId() {
		return customerId;
	}



	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}



	public double getAmount() {
		return amount;
	}



	public void setAmount(double amount) {
		this.amount = amount;
	}



	protected double calculatePayment() {
		
		return amount ;
		
	}
	
	void printPaymentInfo() {
		
		System.out.println(toString() +"Payment = "+calculatePayment());
		
	}
	
	public int compareTo(CustomerPayment otherPayment) {
        
        return Double.compare(this.calculatePayment(), otherPayment.calculatePayment());
    }

	//@Override
	public String toString() {
		return ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount;
				
	}

}
