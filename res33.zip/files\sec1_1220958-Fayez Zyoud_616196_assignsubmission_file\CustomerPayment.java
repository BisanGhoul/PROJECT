// Fayez Zyoud ,1220958,Lab 1
package project1;
import java.util.*;
public abstract class CustomerPayment implements Comparable<CustomerPayment> {
protected String customerName;
protected int customerId;
protected double amount;

public CustomerPayment() {
}
public CustomerPayment(String customerName, int customerId, double amount) {
	this.customerName = customerName;
	this.customerId = customerId;
	this.amount = amount;
}
protected abstract double calculatePayment();
public abstract void printPaymentInfo();
public abstract String toString();
// setters and getters
public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}







}
