package project;
//Name:Mohammad Khawaja 		ID:1220153  	 LAB:1 		 SEC:1
public interface Payable {
	public abstract boolean isAuthorized();

}
