/* Name : Mohammed Jamil Saada
   ID : 1221972
   Lab Section : 1
 */

package project;
import java.util.*;

//subclass from the CustomerPayment class and implements the Payable interfece
public class CreditCard extends CustomerPayment implements Payable {
	
	private double chargingFee;
	private Date expiryDate;
	
	//no arg. Constructor
	public CreditCard() {
		super();
		this.chargingFee = 0.0;
		this.expiryDate = new Date();
	}
	
	//all field constructor 
	public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
		super(customerName, customerId, amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}

	//getters and setters 
	public double getChargingFee() {
		return chargingFee;
	}

	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", customerName=" + super.customerName + ", customerId=" + super.customerId + ", amount=" + super.amount + "]";
	}
	
	//implementation of the method that is an abstract in the superclass CustomerPayment
	public double calculatePayment() {
		return (super.amount+this.chargingFee);
	}
	
	//implementation of the method that is an abstract in Payable interface 
	public boolean isAuthorized() {
	//compare the CreditCard expiryDate with the date now ... new Date() (no arg. constructor Date()) give the date now 
		return (this.expiryDate.compareTo(new Date())>=0);
	}
	
	
	

}
