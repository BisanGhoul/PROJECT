/* Name : Mohammed Jamil Saada
   ID : 1221972
   Lab Section : 1
 */

package project;

//subclass from CustomerPayment Class
public class Cash extends CustomerPayment {
	
	private double discountRate;
	
	//no arg. Constructor 
	public Cash() {
		super();
		this.discountRate = 0.0;
	}
	
	//all field Constructor
	public Cash(String customerName, int customerId, double amount,double discountRate) {
		super(customerName, customerId, amount);
		this.discountRate = discountRate;
	}

	//getters and setters 
	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}

	@Override
	public String toString() {
		return "Cash [discountRate=" + discountRate + ", customerName=" + super.customerName + ", customerId=" + super.customerId + ", amount=" + super.amount + "]";
	}
	
	//implementation of the method that is an abstract in the superclass CustomerPayment 
	public double calculatePayment() {
		return (super.amount - ((this.discountRate/100)*super.amount));
	}
	

}
