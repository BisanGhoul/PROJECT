package project2024;

public interface Payable {
	
	public boolean isAuthorized();
	
}
