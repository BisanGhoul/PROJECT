//Kamel Nimer Saleh Aqel, #1200874, sec# 1
package proj_1200874_s1;

public class Check extends CustomerPayment implements Payable {

	private int accountNumber;
	private double accountBalance;
	private int type;
	public static final int CASHIER = 1;
	public static final int CERTIFIED = 2;
	public static final int PERSONAL = 3;

	public Check() {

	}

	public Check(String customerName, int customerId, double amount, int accountNumber, double accountBalance,
			int type) {
		super(customerName, customerId, amount);
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;

	}

	public void deductAmountFromBalance() {
		accountBalance = accountBalance - amount;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getAccountbalance() {
		return accountBalance;
	}

	public void setAccountbalance(double accountbalance) {
		this.accountBalance = accountbalance;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	@Override
	public boolean isAuthorized() {

		if (type == CASHIER || amount <= accountBalance) {
			if (type == Check.CERTIFIED || type == Check.PERSONAL)
				deductAmountFromBalance();

			return true;
		} else
			return false;

	}

	@Override
	public double calculatePayment() {

		return amount;
	}

	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type + ","
				+ super.toString();
	}

}
