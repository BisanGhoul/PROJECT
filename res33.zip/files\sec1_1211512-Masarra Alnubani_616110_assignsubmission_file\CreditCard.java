//Name: Masarra Nubani	ID:1211512	Lab :1

package project0;

import java.text.SimpleDateFormat;
import java.util.Date;

class CreditCard extends CustomerPayment implements Payable {
// instance variables
    private double chargingFee;
    private Date expiryDate;
 // constructor for all field
    
    public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
        super(customerName, customerId, amount);
        this.chargingFee = chargingFee;
        this.expiryDate = expiryDate;
    }

  //setter and getter for expire date

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }
   //setter and getter for charging fee

     public double getChargingFee() {
        return chargingFee;
    }

    public void setChargingFee(double chargingFee) {
        this.chargingFee = chargingFee;
    }
// method for payment check 
    @Override
    public boolean isAuthorized(){
    	
//get the current date 
        Date currentDate = new Date();
// create a date formatter & get the current and expire year
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy");
        int currentYear = Integer.parseInt(sdf.format(currentDate));
        int expiryYear = Integer.parseInt(sdf.format(expiryDate));
//check for the expire year return false if expired, return true otherwise
        
       if (expiryYear < currentYear) {
            return false;
        }
        return true;
    }
 // method to calculate payment & return the amount plus the charging fee as the payment
    @Override
    public double calculatePayment() {
        return amount + chargingFee;
    }
 // method to return a string representation of the credit card object
    @Override
    public String toString() {
        return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
    }
}
