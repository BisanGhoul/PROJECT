//Name: Masarra Nubani	ID:1211512	Lab :1

package project0;

interface Payable {
	boolean isAuthorized();

}
