 /*
Full Name: [layan mohammad fakhry khalaf]
Student ID: [1222732]
Lab Section: [1]
*/

 package application;



	
		
		public class Cash extends CustomerPayment {
			 private double	discountRate;
	
		
		
		
			
		
public Cash(String customerName,int customerId,double  amount,double	discountRate) {
	
	super(customerName, customerId,  amount);
	this.discountRate = discountRate;
	
			
		}


@Override 
public double calculatePayment () {
	return ( amount * (1 - discountRate / 100) )  ;
}


@Override 
public  void printPaymentInfo () {
	
	  System.out.println  (" Cash = " + toString() );
	  System.out.println (" Payment = " + calculatePayment());
	
	
	
}


















 


		















}
