// Fayez Zyoud ,1220958,Lab 1
package project1;

import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable {
private double chargingfee;
private Date expiryDate;

public CreditCard(String customerName, int customerId, double amount,double chargingfee,Date expiryDate) {
	super(customerName, customerId, amount);
	this.chargingfee=chargingfee;
    this.expiryDate=expiryDate;
}
public CreditCard() {
	super();
}
@Override
protected double calculatePayment() {
	
	return super.getAmount()+chargingfee;
}
@Override
public void printPaymentInfo() {
	System.out.println(toString()+"Payment= "+calculatePayment());
	
}
@Override
public String toString() {
	return "CreditCard [chargingfee=" + chargingfee + ", expiryDate=" + expiryDate + ", customerName=" + super.customerName
			+ ", customerId=" + super.getCustomerId() + ", amount=" + super.getAmount() + "]";
}
public double getChargingfee() {
	return chargingfee;
}
public void setChargingfee(double chargingfee) {
	this.chargingfee = chargingfee;
}
public Date getExpiryDate() {
	return expiryDate;
}
public void setExpiryDate(Date expiryDate) {
	this.expiryDate = expiryDate;
}

@Override
public int compareTo(CustomerPayment o) {
       if(calculatePayment()<o.calculatePayment())
          return 1;
       else if(calculatePayment()>o.calculatePayment())
    	   return -1;
       else return 0;
    		   
    		   
}
@Override
public boolean isAuthurized() {
	  if (this.expiryDate.equals(new Date()) || this.expiryDate.after(new Date()))
          return true;
      else
          return false;
}

}
