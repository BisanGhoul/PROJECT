package project2;
//bahaabukhalil-1210442-sec1
import java.time.LocalDate;
import java.util.Date;

class CreditCard extends CustomerPayment implements Payable {
	private double chargingFee;
	private LocalDate expiryDate;

	CreditCard() {

	}

	CreditCard(String Customername, int Customerid, double amount,double chargingFee, LocalDate expiryDate) {
		super(Customername, Customerid, amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}

	
	@Override
	public boolean isAuthorized() {
		
    LocalDate currentDate = LocalDate.now();
	if ( expiryDate.isBefore(currentDate) || expiryDate.equals(currentDate)) {
		
		return true;
	}
	else {
		
		return false;
	}
	}
	
	@Override
	protected double calculatePayment() {
		double payment;
		payment = amount + chargingFee;
		return payment;
	}


	public double getChargingFee() {
		return chargingFee;
	}

	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}

	public LocalDate getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public String toString() {
		return " [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", Customername="
				+ Customername + ", Customerid=" + Customerid + ", amount=" + amount + "]";
	}

	@Override
	public void printPaymentInfo() {

		System.out.println("CreditCard = " + this.toString() +"\n"+ "Payment with chargingFee = " + calculatePayment());

	}
	

}
