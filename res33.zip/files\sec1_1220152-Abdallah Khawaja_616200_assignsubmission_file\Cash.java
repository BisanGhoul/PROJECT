//Name :Abdallah Khawaja  ID:1220152   SEC:1   LAB:1
package project1;
public class Cash extends CustomerPayment {
	private double discountRate;

	public Cash() {
	
	}

	public Cash(double discountRate) {
		super();
		this.discountRate = discountRate;
	}

	public Cash(String coustemercustomerName, int customerId, double amount, double discountRate) {
		super(coustemercustomerName, customerId, amount);
		this.discountRate = discountRate;

	}

	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}
    @Override
	protected double calculatePayment() {
		double percentege = amount * discountRate / 100;
		double count=amount - percentege;
		return count;
	}

	@Override
	public String toString() {
		return "Cash [discountRate=" + discountRate + super.toString() + "]";
	}
	@Override
	void printPaymentInfo() {
		System.out.println(toString() + "Payment =" + calculatePayment());
	}

}