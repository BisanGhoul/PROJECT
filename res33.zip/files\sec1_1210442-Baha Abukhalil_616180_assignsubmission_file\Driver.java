//bahaabukhalil-1210442-sec1
package project2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;


public class Driver {
    public static void main(String[] args) {
        ArrayList<CustomerPayment> payments = new ArrayList<>();

        Check check1 = new Check("Rana", 7777, 400, 1111, 350, Check.PERSONAL);
        if (check1.isAuthorized()) {
            check1.deductAmountFromBalance();
            payments.add(check1);
        }
        Cash cash1 = new Cash("Ahmad", 4444, 150, 5.0);
        payments.add(cash1); //isAuthorized
        Check check2 = new Check("Suha", 5555, 100, 1111, 200, Check.CASHIER);
        if (check2.isAuthorized()) {
            check2.deductAmountFromBalance();
            payments.add(check2);
        }
        Check check3 = new Check("Rania", 7777, 600.0, 1111, 750, Check.CERTIFIED);
        if (check3.isAuthorized()) {
            check3.deductAmountFromBalance();
            payments.add(check3);
        }
        CreditCard creditCard1 = new CreditCard("Randa", 9999, 170, 20, LocalDate.of(124,05,03));
        if (creditCard1.isAuthorized()) {
            payments.add(creditCard1);
        }
        CreditCard creditCard2 = new CreditCard("Hani", 6666, 150, 10, LocalDate.of(120,06,07));
        if (creditCard2.isAuthorized()) {
            payments.add(creditCard2);
        }

       Collections.sort(payments);

        for (int i = 0; i < payments.size(); i++) {
            CustomerPayment payment = payments.get(i);
            payment.printPaymentInfo();
        }

    }
}
