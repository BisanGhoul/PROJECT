package p1;

import java.util.Date;

class CreditCard extends CustomerPayment implements Payable { // Reda Mohammad Raja Srour _ 1201656 _ Section 1
	private double chargingFee;
	private Date expiryDate;

	public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
		super(customerName, customerId, amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}

	@Override
	public double calculatePayment() {

		return (amount + chargingFee);
	}

	@Override
	public void printPaymentInfo() {
		System.out.println(this.toString());
		System.out.println(" Payment = " + this.calculatePayment());
	}

	public boolean isAuthorized() {
		return expiryDate.after(new Date()) || expiryDate.equals(new Date());
	}

	public double getChargingFee() {
		return chargingFee;
	}

	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", customerName="
				+ customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}

}