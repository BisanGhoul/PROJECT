package project;
/* Tamer Zahi Sabri Ballout (1203152) s1 */
import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable {
    private double chargingFee;
    private Date expiryDate;

    public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
        super(customerName, customerId, amount);
        this.chargingFee = chargingFee;
        this.expiryDate = expiryDate;
    }

    @Override
    public boolean isAuthorized() {
        return expiryDate.after(new Date());
    }

    @Override
    public double calculatePayment() {
        return getAmount() + chargingFee;
    }

    @Override
    public String toString() {
        return "CreditCard{" +
               "customerName='" + getCustomerName() + '\'' +
               ", customerId=" + getCustomerId() +
               ", amount=" + getAmount() +
               ", chargingFee=" + chargingFee +
               ", expiryDate=" + expiryDate +
               '}';
    }
}
