/* Name : Mohammed Jamil Saada
   ID : 1221972
   Lab Section : 1
 */

package project;
import java.util.*;

public class Driver {

	public static void main(String[] args) {
		//ArrayList of type CustomerPayment 
		ArrayList<CustomerPayment> paymentArray = new ArrayList<>();
		
		//adding different types of payments to the ArrayList (customerArray)
		CustomerPayment check1 = new Check("Rana",7777,400,1111,350,Check.PERSONAL);
		//before adding the payment of type Check we should checked if it is authorized , if yes add it, else don't add it
		//if it is authorized and either CERTIFIED OR PERSONAL then deductAmountFromBalance, this step is done in isAuthorized method(beforeAdding)
		if(((Check)check1).isAuthorized())
			paymentArray.add(check1);
		
		CustomerPayment cash1 = new Cash("Ahmad",4444,150,5.0);
		paymentArray.add(cash1);
		
		//before adding the payment of type Check we should checked if it is authorized , if yes add it, else don't add it
		//if it is authorized and either CERTIFIED OR PERSONAL then deductAmountFromBalance, this step is done in isAuthorized method (beforeAdding)
		CustomerPayment check2 = new Check("Suha",5555,100,1111,200,Check.CASHIER);
		if(((Check)check2).isAuthorized())
			paymentArray.add(check2);
		
		//before adding the payment of type Check we should checked if it is authorized , if yes add it, else don't add it
		//if it is authorized and either CERTIFIED OR PERSONAL then deductAmountFromBalance, this step is done in isAuthorized method(beforeAdding)
		CustomerPayment check3 = new Check("Rania",7777,600.0,1111,750,Check.CERTIFIED);
		if(((Check)check3).isAuthorized())
			paymentArray.add(check3);
		
		//before adding the payment of type CreditCard we should checked if it is authorized , if yes add it, else don't add it
		CustomerPayment creditCard1 = new CreditCard("Randa",9999,170,20,new Date(124,05,03));
		if(((CreditCard)creditCard1).isAuthorized())
			paymentArray.add(creditCard1);
		
		//before adding the payment of type CreditCard we should checked if it is authorized , if yes add it, else don't add it
		CustomerPayment creditCard2 = new CreditCard("Hani",6666,150,10,new Date(120,06,07));
		if(((CreditCard)creditCard2).isAuthorized())
			paymentArray.add(creditCard2);
		
		//Sort the ArrayList (customerArray) in descending order based on the calculatePayment
		Collections.sort(paymentArray);
		
		//print the List to the screen 
		for(int i=0; i<paymentArray.size(); i++)
			(paymentArray.get(i)).printPaymentInfo();

	}

}
