//Waleed Faris Ayesh
//11902244
//lab section 1

package project;

public abstract class CustomerPayment implements Comparable<CustomerPayment> {
	protected String customerName;
	protected int custmerId;
	protected double amount;
	
	//no-arg constructors
	public CustomerPayment() {
		
	}

    //all field constructors
	public CustomerPayment(String customerName, int custmerId, double amount) {
		this.customerName = customerName;
		this.custmerId = custmerId;
		this.amount = amount;
	}

	//setters and getters
	public String getName() {
		return customerName;
	}


	public void setName(String customerName) {
		this.customerName = customerName;
	}


	public int getCustmerId() {
		return custmerId;
	}


	public void setCustmerId(int custmerId) {
		this.custmerId = custmerId;
	}


	public double getAmount() {
		return amount;
	}


	public void setAmount(double amount) {
		this.amount = amount;
	}


	@Override
	public int compareTo(CustomerPayment o) {
		if(this.calculatePayment()>o.calculatePayment()) {	
		return 1;
		}
		else if(this.calculatePayment()<o.calculatePayment())
			return -1;
		else 
			return 0;
	}


	@Override
	public String toString() {
		return " customerName = " + customerName + ", custmerId = " + 
	custmerId + ", amount = " + amount + "";
	}
	
	protected abstract double calculatePayment();
	
	
	void printPaymentinfo() {
		System.out.println(this.toString());
		
	}

	
	
	

}
