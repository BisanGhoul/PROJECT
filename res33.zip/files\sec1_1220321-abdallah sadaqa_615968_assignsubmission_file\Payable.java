//AbdullahSadaqa , 1220321 , 1

package project1;

public interface Payable {
	
	public boolean isAuthorized () ;
}
