/*
Full Name: [layan mohammad fakhry khalaf]
Student ID: [1222732]
Lab Section: [1]
*/

package application;

public class Check extends CustomerPayment {
	  
	
	public static final int CASHIER=1;
	public static final int CERTIFIED=2;
	public static final int PERSONAL=3;
	

	
	private int accountNumber;
    private double  accountBalance;
    private int type;
      
    
    
	
	
	

	
	
	
	

	public Check( String  customerName, int customerId, double amount, int accountNumber, double accountBalance, int type) {
		
		super(customerName, customerId,  amount);

		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
		
		
	}
	
	
	
	
	
	
	
	
	
	@Override 
	public double calculatePayment (){
		return      (amount) ;
	}
	
	
	public boolean isAuthorized() {
		 
		 if (type == CASHIER)
		    {
			 
			 return true;
	        } 
 else if   (amount <= accountBalance) 
          {
	 deductAmountFromBalance();
     return true;
	        }
 else    
 {
	 return false ;
   }
	}
	
	
	
	
	
	private void deductAmountFromBalance() {
        accountBalance -= amount;
    }
	
	@Override 
	public  void printPaymentInfo () {
		
		  System.out.println  (" Check = " + toString() );
		  System.out.println (" Payment = " + calculatePayment());
		
		
		
	}
	


}
