
//DAREEN ABUALHAJ   / 1220686  /  1L
public class Check  extends  CustomerPayment implements Payable {
	private int accountNumber;
	private double accountBalance;
	private int type;
	//primative data type should define in this class
	static final int CASHIER = 1;
	static final int CERTIFIED = 2;
	static final int PERSONAL = 3;

	//constructors
	public Check() {

	}
	public Check(String customerName, int customerId, double amount, int accountNumber, double accountBalance,int type) {
		super(customerName, customerId, amount);
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
	}


	//getter and setter for AccountNumber
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	//getter and setter for AccountBalance
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	// getter and setter for Type 
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}

	public void deductAmountFromBalance() {

		/*if (type == CERTIFIED || type == PERSONAL) {  //another way to solve 
			accountBalance -= amount;
		}*/
		if (type !=CASHIER) {
			accountBalance -= amount;
		}
	}
	@Override
	protected double calculatePayment() {
		return amount;
	}

	@Override
	public boolean isAuthorized() {
		if (type == CASHIER) {
			return true;
		} 
		else if (amount <= accountBalance) {
			deductAmountFromBalance();
			return true;
		}
		else {
			return false;
		}
	}
	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type
				+ ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
	}


}
