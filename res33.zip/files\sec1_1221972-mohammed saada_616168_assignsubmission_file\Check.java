/* Name : Mohammed Jamil Saada
   ID : 1221972
   Lab Section : 1
 */

package project;

//subclass of CustomerPayment class and implements the Payable interface
public class Check extends CustomerPayment implements Payable {
	
	//Constants in this class
	final public static int CASHIER = 1;
	final public static int CERTIFIED = 2;
	final public static int PERSONAL = 3;
	
	private int accountNumber; 
	private double accountBalance;
	private int type;
	
	//no arg. Constructor
	public Check() {
		super();
		this.accountNumber = 0;
		this.accountBalance = 0.0;
		this.type = 0;
	}
	
	//all field Constructor
	public Check(String customerName, int customerId, double amount, int accountNumber, double accountBalance, int type) {
		super(customerName, customerId, amount);
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
	}

	//getters and setters 
	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type + ", customerName=" + super.customerName + ", customerId=" + super.customerId + ", amount=" + super.amount + "]";
	}
	
	//implementation of the method that is an abstract in the superclass CustomerPayment
	public double calculatePayment() {
		return super.amount;
	}
	
	public void deductAmountFromBalance() {
	//deduct the amount from account balance if Check is of type CERTIFIED or PERSONAL 
	//Check of type CASHIER does not subtract the amount from the account balance
		if(this.type != CASHIER)
			accountBalance -= super.amount;
	}
	
	//implementation of the method that is an abstract in Payable interface 
	public boolean isAuthorized() {
		if (type == CASHIER || super.amount <= accountBalance) {
			this.deductAmountFromBalance();      //deductAmountFromBalance only if the check is Authorized, then we call this method here
			return true ;
		}
		
		else return false;
		}
	
	

}
