//Kamel Nimer Saleh Aqel, #1200874, sec# 1
package proj_1200874_s1;

import java.util.*;

public class CreditCard extends CustomerPayment implements Payable {

	private double chargingFee;
	private Date expiryDate;

	public CreditCard() {

	}

	public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
		super(customerName, customerId, amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}

	public double getChangFee() {
		return chargingFee;
	}

	public void setChangFee(double changFee) {
		this.chargingFee = changFee;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public boolean isAuthorized() {
		Date currentDate = new Date();
		if (expiryDate.compareTo(currentDate) >= 0 ){
			return true;
		}
		else
			return false;
	}

	@Override
	public double calculatePayment() {
		return amount + chargingFee;
	}

	@Override
	public String toString() {
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate +"," +super.toString();
	}

}
