/* Name : Mohammed Jamil Saada
   ID : 1221972
   Lab Section : 1
 */

package project;
//CustomerPayment is an abstract class - the Superclass in this project
public abstract class CustomerPayment implements Comparable<CustomerPayment> {
	
	protected String customerName;
	protected int customerId;
	protected double amount;
	
	//No arg. Constructor
	public CustomerPayment() {
		this(null,0,0.0);
	}
	//all field Constructor
	public CustomerPayment(String customerName, int customerId, double amount) {
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
	}
	
	//getters and setters 
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	// calculatePayment is an abstract method ... to be implemented in the subclasses 
	protected abstract double calculatePayment();
	
	//print the information by call toString and calculatePayment method
	public void printPaymentInfo() {
		System.out.println(this.toString()+" Payment = " + this.calculatePayment());
		
	}

	@Override
	public String toString() {
		return "CustomerPayment [customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount
				+ "]";
	}
	
	//implementation of compareTo method because this class implements Comparable interface.
	//compareTo method is comparing based on the value of calculatePayment method 
	public int compareTo(CustomerPayment c) {
		return (int)(c.calculatePayment()-this.calculatePayment());
		
	}
	
	
	

}
