package project;
/* Tamer Zahi Sabri Ballout (1203152) s1 */
public class Check extends CustomerPayment implements Payable {
    public static final int CASHIER = 1;
    public static final int CERTIFIED = 2;
    public static final int PERSONAL = 3;

    private int accountNumber;
    private double accountBalance;
    private int type;

    public Check(String customerName, int customerId, double amount, int accountNumber, double accountBalance, int type) {
        super(customerName, customerId, amount);
        this.accountNumber = accountNumber;
        this.accountBalance = accountBalance;
        this.type = type;
    }

    @Override
    public boolean isAuthorized() {
        if (type == CASHIER) {
            return true;
        } else {
            return getAmount() <= accountBalance;
        }
    }

    @Override
    public double calculatePayment() {
        return getAmount();
    }

    @Override
    public String toString() {
        return "Check{" +
               "customerName='" + getCustomerName() + '\'' +
               ", customerId=" + getCustomerId() +
               ", amount=" + getAmount() +
               ", accountNumber=" + accountNumber +
               ", accountBalance=" + accountBalance +
               ", type=" + type +
               '}';
    }
}
