//AbdullahSadaqa , 1220321 , 1
package project1;

import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable{
	
	private double charginingFee ;
	private Date expiryDate;
	
	
	
	public CreditCard(String customerName ,int customerId, double amount, double charginingFee, Date expiryDate) {
		super(customerName , customerId , amount);
		this.charginingFee = charginingFee;
		this.expiryDate = expiryDate;
	}



	public double getCharginingFee() {
		return charginingFee;
	}



	public void setCharginingFee(double charginingFee) {
		this.charginingFee = charginingFee;
	}



	public Date getExpiryDate() {
		return expiryDate;
	}



	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	protected double calculatePayment () {
		 
		return super.amount+this.charginingFee;
	}
	
	public boolean isAuthorized () {
		
		if(expiryDate.after(new Date())) 
			return true ;
		else
			return false ;
		
	}

	@Override
	public String toString() {
		return "CreditCard [charginingFee=" + charginingFee + ", expiryDate=" + expiryDate + super.toString() +"]";
	}
}
