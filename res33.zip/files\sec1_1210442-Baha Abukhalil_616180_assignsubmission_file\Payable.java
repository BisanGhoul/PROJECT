//bahaabukhalil-1210442-sec1
package project2;

public interface Payable {
	boolean isAuthorized();
}
