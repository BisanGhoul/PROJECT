//osama hammoudeh 1181680 dr.mohammad helal-1
package project;
import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable {
    private double chargingFee;
    private Date expiryDate;

    public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
        super(customerName, customerId, amount);
        this.chargingFee = chargingFee;
        this.expiryDate = expiryDate;
    }

    @Override
    public double calculatePayment() {
        return super.amount + chargingFee;
    }

    @Override
    public boolean isAuthorized() {
        return expiryDate.after(new Date());
    }

    @Override
    public String toString() {
        return "CreditCard{" +"chargingFee=" + chargingFee +", expiryDate=" + expiryDate + "} " + super.toString();
    }
}
