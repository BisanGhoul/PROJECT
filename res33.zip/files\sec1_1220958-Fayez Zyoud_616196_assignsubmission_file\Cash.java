// Fayez Zyoud ,1220958,Lab 1
package project1;

public class Cash extends CustomerPayment {
private double discountRate;




public Cash(String customerName, int customerId, double amount,double discountRate) {
	super(customerName, customerId, amount);
	this.discountRate=discountRate;
}


public Cash() {
	
}


@Override
protected double calculatePayment() {
	
	return super.getAmount()*(1- (discountRate/100));
}

	

@Override
public String toString() {
	return "Cash [discountRate=" + discountRate + ", customerName=" + super.getCustomerName() + ", customerId=" +super.getCustomerId()
			+ ", amount=" +super.getAmount()+ "]";
}




@Override
public void printPaymentInfo() {
System.out.println(toString()+"payment="+calculatePayment());
	
}
@Override
public int compareTo(CustomerPayment o) {
	if(calculatePayment()<o.calculatePayment())
	return 1;
	else if(calculatePayment()>o.calculatePayment())
     return -1;
	else return 0;
}


public double getDiscountRate() {
	return discountRate;
}


public void setDiscountRate(double discountRate) {
	this.discountRate = discountRate;
}









}
