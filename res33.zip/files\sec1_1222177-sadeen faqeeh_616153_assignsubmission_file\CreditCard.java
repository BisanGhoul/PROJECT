// SADEEN JEHAD MOHAMMED FAQEEH
// ID: 1222177
// LAB SEC 1
package proj;

import java.util.Date;
//this class is a subclass of CustomerPayment and implement from CustomerPayment which its implement from the interface Comparable
public class CreditCard extends CustomerPayment implements CustomerPayment.Payable{ 
	private double chargingFee;
	private Date expiryDate;
	
	public CreditCard(){// initialize constructor without arguments
	}
	public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate){ // initialize constructor with arguments
		super(customerName, customerId, amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}

	// write the getters and setters
	public double getChargingFee() {
		return chargingFee;
	}
	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	
	@Override
	public double calculatePayment() { // to calculate the total payment include charging fee
		return amount + chargingFee ;
	}
	@Override
	public boolean isAuthorized() { // to check if the credit card is expired
		return !expiryDate.before(new Date());
	}
	


	@Override 
	public String toString() { // this provides string representation of the CreditCard detail
		return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", calculatePayment()="
				+ calculatePayment() + ", isAuthorized()=" + isAuthorized() + ", getChargingFee()=" + getChargingFee()
				+ ", getExpiryDate()=" + getExpiryDate() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}

	@Override
	public int compareTo(CustomerPayment o) { 
	    if (o instanceof CreditCard) { //to check the object is a CreditCard
	        CreditCard otherCreditCard = (CreditCard) o; //return to creditCard
	        return this.expiryDate.compareTo(otherCreditCard.expiryDate); // compare the date
	    } 
	    else { //let it equal if its not CreditCadr
	        return 0;
	    }
	}

	

}
