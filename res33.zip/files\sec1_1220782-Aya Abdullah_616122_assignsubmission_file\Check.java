// name :aya abdullah    student id :1220782  lab section :1
import java.util.*;
public class Check extends CustomerPayment implements Payable  {
private int accountNumber ;
private double accountBlance ;
public int type ;
public static final int  CASHIER=1;
public static final int   CERTIFIED=2;
public static final int PERSONAL=3	;

public Check(String customerName, int customerId, double amount,int accountNumber,double accountBlance,int type ) {
	super(customerName, customerId, amount);
	this.accountNumber= accountNumber;
	this.accountBlance= accountBlance;
	this.type= type ;
}

public  double calculatPayment () {
	return amount ;
}
	
  public boolean isAuthorized ()
  {
	
	  if (type==CASHIER  || amount<=accountBlance ) {
	deductAmountFromBalance();
	  return true ;}
	  
	  else 
		  return false ;
  }

public int getAccountNumber() {
	return accountNumber;
}

public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}

public double getAccountBlance() {
	return accountBlance;
}

public void setAccountBlance(double accountBlance) {
	this.accountBlance = accountBlance;
}

public int getType() {
	return type;
}

public void setType(int type) {
	this.type = type;
}

@Override
public String toString() {
	return "Check [accountNumber=" + accountNumber + ", accountBlance=" + accountBlance + ", type=" + type
			+ ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
}
	
public void deductAmountFromBalance() {
	if (type==PERSONAL ||type == CERTIFIED)
		accountBlance-=amount ;}
	
}
	

