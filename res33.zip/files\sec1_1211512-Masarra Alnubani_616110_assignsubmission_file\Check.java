//Name: Masarra Nubani	ID:1211512	Lab :1

package project0;

//class for check payments
 class Check extends CustomerPayment implements Payable {
    
// constants check types
    public static final int CASHIER = 1;
    public static final int CERTIFIED = 2;
    public static final int PERSONAL = 3;
    
 //declare variables 
    private int accountNumber;
    private double accountBalance;
    private int type;

 //  constructor for all field
    public Check(String customerName, int customerId, double amount, int accountNumber, double accountBalance, int type) {
    // call the constructor superclass
        super(customerName, customerId, amount);
        
  // assign the account number,account balance,and the check type
        this.accountNumber = accountNumber;
        this.accountBalance = accountBalance;
        this.type = type;
    }

  //setter and getter for account balance
    public double getAccountBalance() {
        return accountBalance;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }
  //setter and getter for account number
    
    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }
   ////setter and getter for type to check

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
 // method to check for payment  if the check is cashier or the amount is less than or equal to the balance
    @Override
    public boolean isAuthorized() {
        if (type == CASHIER || amount <= accountBalance) {
            return true;
        }// return true if authorized & return false if it's not
        return false;
    }

    @Override
 // this method  calculate payment & return the amount of the payment
    public double calculatePayment() {
        return amount;
    }
 // method to deduct amount from balance & subtract the amount from the balance
    public void deductAmountFromBalance() {
        accountBalance -= amount;
    }
 // method to return a string representation of the check object
    @Override
    public String toString() {
        return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type + ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
    }
}

