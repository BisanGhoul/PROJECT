package project2024;

public class Abstarct {

}
