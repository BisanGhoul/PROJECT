 /*
Full Name: [layan mohammad fakhry khalaf]
Student ID: [1222732]
Lab Section: [1]
*/

package application;



import java.util.Date;


	public class CreditCard extends CustomerPayment {
		
		private double  chargingFee;
	    private Date expiryDate;

	
		
	
	
	
	
public CreditCard(String customerName, int customerId,double amount, double chargingFee, Date expiryDate) {
	
	super(customerName, customerId,  amount);
	
	this.chargingFee = chargingFee;
	this.expiryDate = expiryDate;
		
	}


@Override
public double calculatePayment (){
	return (     (amount) +  chargingFee  ) ;
	
}


@Override 
public  void printPaymentInfo () {
	
	  System.out.println  (" CreditCard = " + toString() );
	  System.out.println (" Payment = " + calculatePayment());
}




public  boolean isAuthorized() {
	 
	 
	    
	return (expiryDate.compareTo(new Date()) >= 0);
       }
	 




	
	


}
