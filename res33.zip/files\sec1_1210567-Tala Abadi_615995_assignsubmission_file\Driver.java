//Tala Abadi 
//1210567
//

package project2024;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class Driver {

	public static void main(String[] args) {

		//making an array list for customer payment
		ArrayList<CustomerPayment> customersPaymemt = new ArrayList<>();

		customersPaymemt.add(new Cash("Ahmad", 4444, 150, 5.0));

		Check payment1 = new Check("Rana", 7777, 400, 1111, 350, Check.PERSONAL);
		//checking if the payment1 is authorized for adding it to the list
		if(payment1.isAuthorized()) {
			customersPaymemt.add(payment1);
		}
		
		Check payment2 = new Check("Suha", 5555, 100, 1111, 200, Check.CASHER);
		//checking if the payment2 is authorized for adding it to the list
		if(payment2.isAuthorized()) {
			customersPaymemt.add(payment2);
		}
		
		Check payment3 = new Check("Rania", 7777, 600.0, 1111, 750, Check.CERTIFIED);
		//checking if the payment3 is authorized for adding it to the list
		if(payment3.isAuthorized()) {
			customersPaymemt.add(payment3);
		}
		
		CreditCard payment4 = new CreditCard("Randa", 9999, 170, 20, new Date(124, 05, 03));
		//checking if the payment4 is authorized for adding it to the list
		if(payment4.isAuthorized()) {
			customersPaymemt.add(payment4);
		}
		
		
		CreditCard payment5 = new CreditCard("Hani", 6666, 150, 10, new Date(120, 06, 07));
		//checking if the payment5 is authorized for adding it to the list
		if(payment5.isAuthorized()) {
			customersPaymemt.add(payment5);
		}
		
		
		Collections.sort(customersPaymemt);
		
		for(CustomerPayment i : customersPaymemt) {
			i.printPaymentInfo();
		}
	}

}
