/*
Full Name: [layan mohammad fakhry khalaf]
Student ID: [1222732]
Lab Section: [1]
*/

package application;




public abstract class CustomerPayment implements Comparable <CustomerPayment>{

	
	private String customerName;
    private int customerId;
    protected double  amount;
    
    
	
	
	
	
	
	
public CustomerPayment(String customerName,int customerId,double  amount) {
	
	this.customerName = customerName;
    this. customerId =  customerId;
    this. amount =  amount;
	}

public String getcustomerName() {
	return customerName;
}

public double getamount() {
	return amount;
}


public int getcustomerId() {
	return customerId;
}



public void setcustomerName(String customerName) {
	this.customerName = customerName;
}

public void setcustomerId(int customerId) {
	this.customerId = customerId;
}

public void setamount(double amount) {
	this.amount = amount;
}




@Override
public String toString() {
	 return String.format (" CustomerPayment [customerId=%d,amount=%f,customerName=%s] ", customerId, amount, customerName);
}






public   abstract double calculatePayment ();
	


public abstract void printPaymentInfo ();





@Override 
public int compareTo(CustomerPayment other) {
	return -Double.compare(this.calculatePayment(),other.calculatePayment());
}













}
