// Fayez Zyoud ,1220958,Lab 1
package project1;

public interface Payable {
public abstract boolean isAuthurized();
}
