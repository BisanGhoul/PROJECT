package project2;
//bahaabukhalil-1210442-sec1

class Check extends CustomerPayment implements Payable {

	private int accountnumber;
	private double accountBalance;
	private int type;

	static int CASHIER = 1;
	static int CERTIFIED = 2;
	static int PERSONAL = 3;

	Check() {

	}

	Check(String Customername, int Customerid, double amount ,int accountnumber, double accountBalance, int type) {
		super(Customername, Customerid, amount);
		this.accountnumber = accountnumber;
		this.accountBalance = accountBalance;
		this.type = type;

	}

	public void deductAmountFromBalance() {
		if (isAuthorized() && type != CASHIER) {
            accountBalance = accountBalance -  amount;
        }
	}
	

	@Override
	public boolean isAuthorized() {

		if (type == CASHIER || amount <= accountBalance) {
			return true;
		}

		else {
			return false;
		}
	}

	@Override
	protected double calculatePayment() {

		return amount;
	}


	public int getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getCASHIER() {
		return CASHIER;
	}

	public void setCASHIER(int cASHIER) {
		CASHIER = cASHIER;
	}

	public int getCERTIFIED() {
		return CERTIFIED;
	}

	public void setCERTIFIED(int cERTIFIED) {
		CERTIFIED = cERTIFIED;
	}

	public int getPERSONAL() {
		return PERSONAL;
	}

	public void setPERSONAL(int pERSONAL) {
		PERSONAL = pERSONAL;
	}

	@Override
	public String toString() {
		return " [accountnumber=" + accountnumber + ", accountBalance=" + accountBalance + ", type=" + type
				+ ", Customername=" + Customername + ", Customerid=" + Customerid + ", amount=" + amount + "]";
	}

	@Override
	public void printPaymentInfo() {
		System.out.println("Check = " + this.toString() +"\n"+ "Payment = " + calculatePayment());

	}
	
	
	

}
