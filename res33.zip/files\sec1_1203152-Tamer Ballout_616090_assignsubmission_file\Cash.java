package project;
/* Tamer Zahi Sabri Ballout (1203152) s1 */
public class Cash extends CustomerPayment {
    private double discountRate;

    public Cash(String customerName, int customerId, double amount, double discountRate) {
        super(customerName, customerId, amount);
        this.discountRate = discountRate;
    }

    @Override
    public double calculatePayment() {
        return getAmount() - (getAmount() * discountRate / 100);
    }

    @Override
    public String toString() {
        return "Cash{" +
               "customerName='" + getCustomerName() + '\'' +
               ", customerId=" + getCustomerId() +
               ", amount=" + getAmount() +
               ", discountRate=" + discountRate +
               '}';
    }
}
