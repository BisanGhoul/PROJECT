//Waleed Faris Ayesh
//11902244
//lab section 1

package project;

public class Cash extends CustomerPayment {

	private double discountRate;
    
	
	//no-arg constructors
	public Cash() {
		super();
	
	}

        //all field constructors
	public Cash(String customerName, int custmerId, double amount,double discountRate) {
		super(customerName, custmerId, amount);
		this.discountRate = discountRate;
	}

	//setters and getters
	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate ) {
		this.discountRate = discountRate;
	}
	
	protected double calculatePayment(){
	 	
		return   amount - amount*(discountRate/100.0) ;
		
	}
	
	@Override
	public String toString() {
		return "CASH [discountRate = " + discountRate + 
				super.toString() + "] \npayment = " +this.calculatePayment() + "\n";
	}
	
	

	
	

}
