// SADEEN JEHAD MOHAMMED FAQEEH
// ID: 1222177
// LAB SEC 1
package proj;
//this class is a subclass of CustomerPayment
public class Cash extends CustomerPayment {
	private double discountRate;
	
	public Cash() { // initialize constructor without arguments
	}
	public Cash(String customerName , int customerId , double amount , double discountRate) { // initialize constructor with arguments
		super(customerName , customerId , amount);
		this.discountRate = discountRate;
	}

	// write the getters and setters
	public double getDiscountRate() {
		return discountRate;
	}
	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}

	
	@Override
	public double calculatePayment() {  // this method to calculate the payment after discount
		return amount -(amount * discountRate /100);
	}
	@Override
	public String toString() {  //this provides string representation of the Cash detail
		return "Cash [discountRate=" + discountRate + ", calculatePayment()=" + calculatePayment()
				+ ", getDiscountRate()=" + getDiscountRate() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}
	@Override
	public int compareTo(CustomerPayment o) {
	    double x = this.amount - o.amount;
	    if (x < 0) {
	        return -1; // This is less 
	    } else if (x > 0) {
	        return 1; // this is greater
	    } else {
	        return 0; // are equal
	    }
	}


}
