// name :aya abdullah    student id :1220782  lab section :1
import java.util.*;
public class CreditCard extends CustomerPayment implements  Payable {
private double chargingFee ;
private Date expiryDate ;
public CreditCard(String customerName, int customerId, double amount, double chargingFee,Date expiryDate) {
	super(customerName, customerId, amount);
	this.chargingFee=chargingFee;
	this.expiryDate=expiryDate;
}
public double getChargingFee() {
	return chargingFee;
}
public void setChargingFee(double chargingFee) {
	this.chargingFee = chargingFee;
}
public Date getExpiryDate() {
	return expiryDate;
}
public void setExpiryDate(Date expiryDate) {
	this.expiryDate = expiryDate;
}
@Override
public String toString() {
	return "CreditCard [chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + ", customerName=" + customerName
			+ ", customerId=" + customerId + ", amount=" + amount + "]";
}
public  double calculatPayment () {
	return( amount+ chargingFee ) ;
}

Date d1 = new Date ();
public boolean isAuthorized ()
{
if (expiryDate.compareTo(d1)==0||expiryDate.compareTo(d1)==1)
    return true ;
else 
	 return false  ;

}













}
