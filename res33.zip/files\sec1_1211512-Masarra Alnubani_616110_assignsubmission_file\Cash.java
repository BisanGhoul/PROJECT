//Name: Masarra Nubani	 ID: 1211512 	Lab:1

package project0;

class Cash extends CustomerPayment {
    private double discountRate;
 // all field constructor for cash payments call the superclass constructor & assign the discount rate
    public Cash(String customerName, int customerId, double amount, double discountRate) {
        super(customerName, customerId, amount);
        this.discountRate = discountRate;
    }
//setter sand getter for discount rate 
    public double getDiscountRate() {
        return discountRate;
    }

    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }
//method to calculate payment with discount rate
    @Override
    public double calculatePayment() {
        return amount - (amount * (discountRate / 100));
    }
// method to return a string representation of the cash object
    @Override
    public String toString() {
        return "Cash [discountRate=" + discountRate + ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
    }
}
