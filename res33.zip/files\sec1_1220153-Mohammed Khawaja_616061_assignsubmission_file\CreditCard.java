package project;
//Name:Mohammad Khawaja 		ID:1220153  	 LAB:1 		 SEC:1
import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable {

	private double chargingFee;
	private Date expiryDate;

	public CreditCard() {
		super();
	}

	public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
		super(customerName, customerId, amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}

	public double getChargingFree() {
		return chargingFee;
	}

	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public String toString() {
		return "CreditCard [chargingFree=" + chargingFee + ", expiryDate=" + expiryDate + super.toString() + "]";
	}

	@Override
	public boolean isAuthorized() {

		Date currentDate = new Date();
		if (expiryDate.compareTo(currentDate) >= 0) {

			return true;
		} else
			return false;
	}

	@Override
	protected double calculatePayment() {
		double Payment = amount + chargingFee;
		return Payment;
	}

	@Override
	public int compareTo(CustomerPayment o) {

		if (this.calculatePayment() > o.calculatePayment()) {
			return -1;
		} else if (this.calculatePayment() < o.calculatePayment()) {
			return 1;
		} else {
			return 0;
		}

	}
}
