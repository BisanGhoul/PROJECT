//Name: Masarra Nubani	ID:1211512	Lab :1

package project0;

import java.util.Date;

abstract class CustomerPayment implements Comparable<CustomerPayment> {
    protected String customerName;
    protected int customerId;
    protected double amount;

    public CustomerPayment(String customerName, int customerId, double amount) {
        this.customerName = customerName;
        this.customerId = customerId;
        this.amount = amount;
    }
//setter and getter for customer id , customer id & amount.
    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
 // method to compare customer payments based on calculated payment & use the Double class method to compare two double values
    @Override
    public int compareTo(CustomerPayment o) {
        return Double.compare(o.calculatePayment(), this.calculatePayment());
    }
 // abstract method to calculate payment
    public abstract double calculatePayment();
 // use the toString method and the String class method to format the output
    public void printPaymentInfo() {
        System.out.println(this.toString() + " Payment = " + String.format("%.2f", this.calculatePayment()));
    }
}
