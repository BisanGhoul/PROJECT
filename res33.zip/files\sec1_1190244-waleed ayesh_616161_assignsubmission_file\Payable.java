//Waleed Faris Ayesh
//11902244
//lab section 1

package project;

public interface Payable {
	
	public boolean isAuthorized(); 
	

}
