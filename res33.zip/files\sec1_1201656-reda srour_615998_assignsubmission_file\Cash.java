package p1;

class Cash extends CustomerPayment { // Reda Mohammad Raja Srour _ 1201656 _ Section 1
	
	private double discountRate;

	public Cash(String customerName, int customerId, double amount, double discountRate) {
		super(customerName, customerId, amount);
		this.discountRate = discountRate;
	}

	@Override
	public double calculatePayment() {

		return (amount - (amount * (discountRate / 100)));
	}

	@Override
	public void printPaymentInfo() {
		System.out.println(this.toString());
		System.out.println(" Payment = " + this.calculatePayment());
	}

	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}

	@Override
	public String toString() {
		return "Cash [discountRate=" + discountRate + ", customerName=" + customerName + ", customerId=" + customerId
				+ ", amount=" + amount + "]";
	}

}
