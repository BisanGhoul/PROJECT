// name :aya abdullah    student id :1220782  lab section :1
import java.util.*;
public class Cash extends CustomerPayment {
private double discountRate ;

public Cash(String customerName, int customerId, double amount,double discountRate) {
	super(customerName, customerId, amount);
	this.discountRate=discountRate;
}

public double getDiscountRate() {
	return discountRate;
}

public void setDiscountRate(double discountRate) {
	this.discountRate = discountRate;
}

@Override
public String toString() {
	return "Cash [discountRate=" + discountRate + ", customerName=" + customerName + ", customerId=" + customerId
			+ ", amount=" + amount + "]";
}
public  double calculatPayment () {
	return (amount-(amount*(discountRate/100))) ;
}



















}
