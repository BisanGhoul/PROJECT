//The super class in this progect
public abstract class CustomerPayment implements Comparable<CustomerPayment> {
		protected String customerName;
		protected int customerId;
		protected double amount;
		public CustomerPayment() {//no argument constructor
			
		}
		//parametrization constructor
		public CustomerPayment(String customerName,int customerId,double amount) {
			super();
			this.customerName=customerName;
			this.customerId=customerId;
			this.amount=amount;
		}
		//The setters and getter for the prberities super class
		public String getCustomerName() {
			return customerName;
		}
		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}
		public int getCustomerId() {
			return customerId;
		}
		public void setCustomerId(int customerId) {
			this.customerId = customerId;
		}
		public double getAmount() {
			return amount;
		}
		public void setAmount(double amount) {
			this.amount = amount;
		}
		//Abstract method for abstact class because the method calculatePayment is implement differently in each of the concert claass(Cash,Check and CreditCard)
		protected abstract double calculatePayment();
        //this method prints the probabilities and calculate payment by calling both to string and calculatepayment method
		public void printPaymentInfo() {
			System.out.println(this.toString()+" Payment = "+calculatePayment());
					
		}
		//this method evaluate dates based on payment
		@Override
        public int compareTo(CustomerPayment c) {
        	if(this.calculatePayment()>c.calculatePayment())
        		return -1;
        	else if(this.calculatePayment()<c.calculatePayment())
        		return 1;
        	else
        		return 0;
			
		}
		//to string for super class
        @Override
		public String toString() {
			return " customerName=" +customerName + ", customerId=" +customerId + ", amount=" +amount+"]";
		}
		
}
