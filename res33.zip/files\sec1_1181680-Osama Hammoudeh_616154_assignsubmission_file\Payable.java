//osama hammoudeh 1181680 dr.mohammad helal-
package project;

public interface Payable {
   boolean isAuthorized();
}
