//Kamel Nimer Saleh Aqel, #1200874, sec# 1
package proj_1200874_s1;

public interface Payable {

	public boolean isAuthorized();
}
