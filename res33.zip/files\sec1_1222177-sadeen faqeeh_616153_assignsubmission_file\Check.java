// SADEEN JEHAD MOHAMMED FAQEEH
// ID: 1222177
// LAB SEC 1
package proj;
// this class is a subclass of CustomerPayment and implement the interface Payable
public class Check extends CustomerPayment implements CustomerPayment.Payable{
	private int accountNumber;
	private double accountBalance;
	private int type;
	
	public static final int CASHIER=1;
	public static final int CERTIFIED=2;
	public static final int PERSONAL=3;
	
	public Check() { // initialize constructor without arguments
	}
	public Check(String customerName , int customerId , double amount , int accountNumber , double accountBalance , int type) { // initialize constructor with arguments
		super(customerName , customerId , amount);
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type=type;
	}
	
	// write the getters and setters
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}

	public void deductAmountFromBalance() { //this method returns the payment amount for the check
		this.accountBalance -= amount;
	}

	
	@Override
	public double calculatePayment() { // this method just to return the amount
		return amount;
	}
	@Override
	public boolean isAuthorized() { //this method t check if the Check is Authorized, based on balance and its type 
		 if (type == CASHIER || amount <= accountBalance) {
	            if (type == CERTIFIED || type == PERSONAL) {
	                deductAmountFromBalance();
	            }
	            return true;
	        }
	        return false;
	}
	@Override
	public String toString() { //this method provides a string representation of the Check object
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type
				+ ", calculatePayment()=" + calculatePayment() + ", isAuthorized()=" + isAuthorized()
				+ ", getAccountNumber()=" + getAccountNumber() + ", getAccountBalance()=" + getAccountBalance()
				+ ", getType()=" + getType() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	@Override
	public int compareTo(CustomerPayment o) { 
		// to check if its instance of Check 
	    if (o instanceof Check) {
	        Check otherCheck = (Check) o;
	        return Integer.compare(this.accountNumber, otherCheck.accountNumber);
	    }
	    return 1; // if (o) its not instance of Check then let it be greater
	}

}
