package project;
//Name:Mohammad Khawaja 		ID:1220153  	 LAB:1 		 SEC:1
public class Check extends CustomerPayment implements Payable {
	private int accountNumber;
	private double accountBalance;
	private int type;
	public static int CASHIER = 1;
	public static int CERTIFIED = 2;
	public static int PERSONAL = 3;

	public Check() {
		super();
	}

	public Check(String customerName, int customerId, double amount, int accountNumber, double accountBalance,
			int type) {
		super(customerName, customerId, amount);
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public void deductAmountFormBalance() {
		if (type == PERSONAL || type == CERTIFIED) {
			accountBalance -= amount;
		}
	}

	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type
				+ super.toString() + "]";
	}

	@Override
	public boolean isAuthorized() {
	
		if (type == CASHIER || amount <= accountBalance) {
			deductAmountFormBalance();
			return true;
		}
		else
			return false;

	}

	@Override
	protected double calculatePayment() {
		double Payment = amount;
		return Payment;
	}

	@Override
	public int compareTo(CustomerPayment o) {

		if (this.calculatePayment() > o.calculatePayment()) {
			return -1;
		} else if (this.calculatePayment() < o.calculatePayment()) {
			return 1;
		} else {
			return 0;
		}

	}
}
