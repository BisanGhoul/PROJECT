package project2;
//bahaabukhalil-1210442-sec1

abstract class CustomerPayment implements Comparable<CustomerPayment> {

	protected String Customername;
	protected int Customerid;
	protected double amount;

	CustomerPayment() {

	}

	CustomerPayment(String Customername, int Customerid, double amount) {
		this.Customername = Customername;
		this.Customerid = Customerid;
		this.amount = amount;

	}

	protected abstract double calculatePayment();

	public abstract void printPaymentInfo();

	public String getCustomername() {
		return Customername;
	}

	public void setCustomername(String customername) {
		Customername = customername;
	}

	public int getCustomerid() {
		return Customerid;
	}

	public void setCustomerid(int customerid) {
		Customerid = customerid;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	
	 @Override
	    public int compareTo(CustomerPayment X) {
	        return (int) (X.calculatePayment() - this.calculatePayment());
	    }

	@Override
	public String toString() {
		return "CustomerPayment [Customername=" + Customername + ", Customerid=" + Customerid + ", amount=" + amount
				+ "]";
	}
	 
	 
}