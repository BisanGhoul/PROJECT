package p1;

abstract class CustomerPayment implements Comparable { // Reda Mohammad Raja Srour _ 1201656 _ Section 1
	protected String customerName;
	protected int customerId;
	protected double amount;

	public CustomerPayment(String customerName, int customerId, double amount) {
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
	}

	public abstract double calculatePayment();

	public abstract void printPaymentInfo();

	public int compareTo(Object R) {
		CustomerPayment other = (CustomerPayment) R;

		return Double.compare(other.calculatePayment(), this.calculatePayment());
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "CustomerPayment [customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount
				+ "]";
	}

}
