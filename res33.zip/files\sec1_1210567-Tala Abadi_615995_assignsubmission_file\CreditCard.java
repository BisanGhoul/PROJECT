package project2024;

import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable {

	private double chargingFee;
	private Date expiryDate;

	public CreditCard() {
		super();
	}

	public CreditCard(String customerName, int customerId, double amount, double chargingFee, Date expiryDate) {
		super(customerName, customerId, amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}

	public double getChargingFee() {
		return chargingFee;
	}

	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public boolean isAuthorized() {
        Date currentDate = new Date();
        if(expiryDate.after(currentDate) || expiryDate.equals(currentDate))
        return true;
        
        return false;
	}

	
	//getting the amount adding to it the fee
	@Override
	protected double calculatePayment() {
		return getAmount() + chargingFee;
	}

	@Override
	public String toString() {
		return "[CreditCard : chargingFee=" + chargingFee + ", expiryDate=" + expiryDate + super.toString();
	}
	
	

}
