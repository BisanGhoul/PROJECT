package Projc1;

//elissarKharoub1220433sec1
public interface Payable{
	 
public boolean isAuthorized();

}