package project2024;

public abstract class CustomerPayment implements Comparable<CustomerPayment> {

	protected String customerName;
	protected int customerId;
	protected double amount;

	public CustomerPayment() {
		super();
	}

	public CustomerPayment(String customerName, int customerId, double amount) {
		super();
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amout) {
		this.amount = amount;
	}

	protected abstract double calculatePayment();

	//compareTo according to customerPayment
	public int compareTo(CustomerPayment CA) {
		if (this.calculatePayment() < CA.calculatePayment()) {
			return 1;
		} else if (this.calculatePayment() > CA.calculatePayment()) {
			return -1;
		}else {
			return 0;
		}
	}

	
	@Override
	public String toString() {
		return " customerName = " + customerName + ", customerId=" + customerId + ", amout=" + amount
				+ "]";
		
	}
	
	//method that print the paymentInfo
	public void printPaymentInfo() {
		//calling the toString method
		System.out.println(toString()+" payment:"+calculatePayment());
		//System.out.print();
	}


}
