//Waleed Faris Ayesh
//11902244
//lab section 1

package project;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;

public class CreditCard extends CustomerPayment implements Payable {

	private double chargingFee;
	private Date expiryDate;
	

	//no-arg constructors
	public CreditCard() {
		super();
	
	}
	
	
    //all field constructors
	public CreditCard(String customerName, int custmerId, double amount, double chargingFee,Date expiryDate) {
		super(customerName, custmerId, amount);
		this.chargingFee = chargingFee;
		this.expiryDate = expiryDate;
	}
	

	//setters and getters
	public double getChargingFee() {
		return chargingFee;
	}
	public void setChargingFee(double chargingFee) {
		this.chargingFee = chargingFee;
	}
	public Date getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}
	
	
	protected double calculatePayment(){
		return amount + chargingFee;
		
	}
	
	@Override
	public boolean isAuthorized() {
	 
		Date date = new Date();
		if(expiryDate.after(date)) {
			return true;
		}
		return false ; 

	}
	
	@Override
	public String toString() {
		return "CREDIT CARD [chargingFee = " + chargingFee +  " expiryDate = " + expiryDate +
				super.toString() +"] \npayment = " + this.calculatePayment()+ "\n";
	}
	
	
}
