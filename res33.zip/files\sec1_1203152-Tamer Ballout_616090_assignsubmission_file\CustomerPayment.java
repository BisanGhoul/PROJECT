package project;
/* Tamer Zahi Sabri Ballout (1203152) s1 */
public abstract class CustomerPayment implements Comparable<CustomerPayment> {
    private String customerName;
    private int customerId;
    private double amount;

    public CustomerPayment(String customerName, int customerId, double amount) {
        this.customerName = customerName;
        this.customerId = customerId;
        this.amount = amount;
    }

    public abstract double calculatePayment();

    public String getCustomerName() {
        return customerName;
    }

    public int getCustomerId() {
        return customerId;
    }

    public double getAmount() {
        return amount;
    }

    @Override
    public int compareTo(CustomerPayment other) {
        return Double.compare(other.calculatePayment(), this.calculatePayment());
    }

    public void printPaymentInfo() {
        System.out.println(this.toString());
    }

    @Override
    public String toString() {
        return "CustomerPayment{" +
               "customerName='" + customerName + '\'' +
               ", customerId=" + customerId +
               ", amount=" + amount +
               '}';
    }
}
