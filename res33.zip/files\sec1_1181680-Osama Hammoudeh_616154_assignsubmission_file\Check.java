//osama hammoudeh 1181680 dr.mohammad helal-1
package project;

public class Check extends CustomerPayment implements Payable {
    private int accountNumber;
    private double accountBalance;
    private int type;
    public static final int CASHIER = 1, CERTIFIED = 2, PERSONAL = 3;

    public Check(String customerName, int customerId, double amount, int accountNumber, double accountBalance, int type) {
        super(customerName, customerId, amount);
        this.accountNumber = accountNumber;
        this.accountBalance = accountBalance;
        this.type = type;
    }

    @Override
    public double calculatePayment() {
        return super.amount;
    }

    @Override
    public boolean isAuthorized() {
    	if (type == CASHIER) {
            return true;
        } else if (super.amount <= accountBalance) {
            deductAmountFromBalance();
            return true;
        } else {
            return false;
        }
    }

    public void deductAmountFromBalance() {
    	if (type != CASHIER) {
            this.accountBalance -= super.amount;
        }
    }

    @Override
    public String toString() {
        return "Check{" +"accountNumber=" + accountNumber +", accountBalance=" + accountBalance +", type=" + type + "} " + super.toString();
    }
}
