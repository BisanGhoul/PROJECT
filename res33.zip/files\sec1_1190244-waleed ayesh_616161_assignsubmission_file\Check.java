//Waleed Faris Ayesh
//11902244
//lab section 1

package project;

public class Check extends CustomerPayment implements Payable {

	private int accountNumber;
	private double accountBalance;
	private int type;

	//constant varible
	public final static int CASHIER=1;
	public final static int CERTIFIED=2;
	public final static int  PERSONAL=3;
	
	//no-ar constructors
	public   Check() {
		super();
		
	}
	
    //all field constructors
	public Check(String customerName, int custmerId, double amount, int accountNumber, double accountBalance, int type) {
		super(customerName, custmerId, amount);
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
	}
	
	
	//setters and getters
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getAccountBalance() {
		return accountBalance ;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	
	 protected double calculatePayment(){
			return amount ;
			
		}
	 
		@Override
		public boolean isAuthorized() {
			if(type == CASHIER || getAmount() <= accountBalance) {
				if(type !=CASHIER ) {
					accountBalance = accountBalance - super.getAmount();
				}
				return true;
			}
			else {
			
			return false;
		}
			}
	
	public void deductAmountFromBalance() {
		accountBalance = accountBalance - amount;
		
		}
		
	

		
	@Override
	public String toString() {
		
		return "CHECK [CheckaccountNumber = " + accountNumber + " accountBalance = " + this.accountBalance + " type = " + type +  
				super.toString() + "] \npayment = " + this.calculatePayment()+ "\n" ;
	}
	
	


}
