// Fayez Zyoud ,1220958,Lab 1
package project1;

public class Check extends CustomerPayment implements Payable{
private int accountNumber;
private double accountBalance;
private int type;
public static final int CASHIER=1;
public static final int CERTIFIED=2;
public static final int PERSONAL=3;

public Check(String customerName, int customerId, double amount,int accountNumber,double accountBalance,int type) {
	super(customerName, customerId, amount);
	this.accountNumber=accountNumber;
	this.accountBalance=accountBalance;
	this.type=type;
}
public Check() {
	super();
}
public void deductAmountFromBalance() {
	accountBalance-=amount;
	
}
@Override
protected double calculatePayment() {
	
	return super.getAmount();
}
@Override
public void printPaymentInfo() {
	System.out.println(toString()+"Payment="+calculatePayment());
}
@Override
public String toString() {
	return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type
			+ ", customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount + "]";
}
public int getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}
public double getAccountBalance() {
	return accountBalance;
}
public void setAccountBalance(double accountBalance) {
	this.accountBalance = accountBalance;
}
@Override
public int compareTo(CustomerPayment o) {
	if(calculatePayment()<o.calculatePayment())
	return 1;
	else if(calculatePayment()>o.calculatePayment())
		return -1;
	else return 0;

}

@Override
public boolean isAuthurized() {
	if (this.type==CASHIER || calculatePayment()<= this.accountBalance){
        if(this.type == CERTIFIED || this.type == PERSONAL){
            this.deductAmountFromBalance();
        }
        return true;
    }

    else
        return false;
	
}









}
