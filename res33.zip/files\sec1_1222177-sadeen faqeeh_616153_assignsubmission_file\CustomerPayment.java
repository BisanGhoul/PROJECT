// SADEEN JEHAD MOHAMMED FAQEEH
// ID: 1222177
// LAB SEC 1
package proj;
//this is the abstract class   (super class)
public abstract class CustomerPayment implements Comparable<CustomerPayment>{
	protected String customerName;
	protected int customerId;
	protected double amount;
	
	public CustomerPayment(){  // initialize constructor without arguments
	}
	public CustomerPayment(String customerName, int customerId, double amount) { // initialize constructor with arguments
		this.customerName = customerName;
		this.customerId = customerId;
		this.amount = amount;
	}
	
	// write the getters and setters 
	// i wanna mention that i don't need the getters and setters because i set the values(field) protected so they are accessible directly inside the class and the subclasses
	// but i put them just in case if there is anything i need to update or to add and to make it more readable :)
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	
	protected abstract double calculatePayment();  //this method used to calculate the total payment, and its an abstract method to be implemented in Drive
	public void printPaymentInfo() { // to print the payment info
		System.out.println(this.toString()+ " PAYMENT: "+ calculatePayment());
	}
	
	// for the interfaces now
	 interface Comparable<T> { // this method from Comparable interface 
	        int compareTo(T other);
	    }
	    interface Payable {
	        boolean isAuthorized();
	    }
	    
	@Override
	public String toString() {
		return "CustomerPayment [customerName=" + customerName + ", customerId=" + customerId + ", amount=" + amount
				+ ", calculatePayment()=" + calculatePayment() + ", getCustomerName()=" + getCustomerName()
				+ ", getCustomerId()=" + getCustomerId() + ", getAmount()=" + getAmount() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	  public boolean isAuthorized() {   // a default implementation that always returns false. It should be overridden in derived classes if necessary
			return false;
		}
	
}
