//DAREEN ABUALHAJ   / 1220686  /  1L
public interface Payable {

	public abstract  boolean isAuthorized() ;

}