package project;
/* Tamer Zahi Sabri Ballout (1203152) s1 */
public interface Payable {
    boolean isAuthorized();
}
