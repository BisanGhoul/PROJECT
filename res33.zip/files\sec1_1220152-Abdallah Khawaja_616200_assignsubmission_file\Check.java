//Name :Abdallah Khawaja  ID:1220152   SEC:1   LAB:1
package project1;
public class Check extends CustomerPayment implements Payable {
	public static final int CASHIER = 1, CERTIFIED = 2, PERSONAL = 3;
	private int accountNumber;
	private double accountBalance;
	private int type;

	public Check() {
		
	}

	public Check(int accountNumber, double accountBalance, int type) {
		super();
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
	}

	public Check(String coustemercustomerName, int customerId, double amount, int accountNumber, double accountBalance,
			int type) {
		super(coustemercustomerName, customerId, amount);
		this.accountNumber = accountNumber;
		this.accountBalance = accountBalance;
		this.type = type;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public double getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
	@Override
	protected double calculatePayment() {
		return amount;
	}

	@Override
	public String toString() {
		return "Check [accountNumber=" + accountNumber + ", accountBalance=" + accountBalance + ", type=" + type
				+ super.toString() + "]";
	}

	@Override
	void printPaymentInfo() {
		System.out.println(toString() + "Payment =" + calculatePayment());
	}

	public boolean isAuthorized() {
		if (type == CASHIER || amount <= accountBalance) {
			deductAmountFromBalance();
			return true;
		} else
			return false;
	}

	public void deductAmountFromBalance() {
		if (type == CERTIFIED || type == PERSONAL)
			accountBalance -= amount;
	}
}