/* Name : Mohammed Jamil Saada
   ID : 1221972
   Lab Section : 1
 */

package project;

public interface Payable {
	
	public abstract boolean isAuthorized();   //interfaces contains only constants and abstract methods 

}
