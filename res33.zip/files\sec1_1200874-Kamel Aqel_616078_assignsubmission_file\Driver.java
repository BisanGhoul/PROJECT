//Kamel Nimer Saleh Aqel, #1200874, sec1
package proj_1200874_s1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class Driver {

	public static void main(String[] args) {

		ArrayList<CustomerPayment> customerPayments = new ArrayList<CustomerPayment>();

		Check check1 = new Check("Rana", 7777, 400, 1111, 350, Check.PERSONAL);
		if (check1.isAuthorized()) {
			customerPayments.add(check1);
		}

		customerPayments.add(new Cash("Ahmad", 4444, 150, 5.0));

		Check check2 = new Check("Suha", 5555, 100, 1111, 200, Check.CASHIER);
		if (check2.isAuthorized()) {
			customerPayments.add(check2);
		}

		Check check3 = new Check("Rania", 7777, 600.0, 1111, 750, Check.CERTIFIED);
		if (check3.isAuthorized()) {
			customerPayments.add(check3);
		}

		CreditCard creditCard1 = new CreditCard("Randa", 9999, 170, 20, new Date(124, 05, 03));
		if (creditCard1.isAuthorized())
			customerPayments.add(creditCard1);

		CreditCard creditCard2 = new CreditCard("Hani", 6666, 150, 10, new Date(120, 06, 07));
		if (creditCard2.isAuthorized())
			customerPayments.add(creditCard2);

		Collections.sort(customerPayments);

		for (int i = 0; i < customerPayments.size(); i++) {
			customerPayments.get(i).printPaymentlInfo();
			System.out.println("-------------------------");
		}

	}

}
