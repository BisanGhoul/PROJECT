package Project;

public interface Payable {
	public abstract boolean isAuthorized();
		
	

}
