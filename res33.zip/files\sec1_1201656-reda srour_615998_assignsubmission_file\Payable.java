package p1;

interface Payable { // Reda Mohammad Raja Srour _ 1201656 _ Section 1
	boolean isAuthorized();
}
