package project2;
//bahaabukhalil-1210442-sec1

class Cash extends CustomerPayment {
	private double discountRate;

	Cash() {

	}

	Cash(String Customername, int Customerid, double amount,double discountRate) {
		super(Customername, Customerid, amount);
		this.discountRate = discountRate;
	}
	

	@Override
	protected double calculatePayment() {
		 
		double afterdisc ;
		double a = amount;
		afterdisc = amount - (a * ( discountRate / 100));
		return afterdisc;
	}
	

	public double getDiscountRate() {
		return discountRate;
	}

	public void setDiscountRate(double discountRate) {
		this.discountRate = discountRate;
	}

	

	@Override
	public String toString() {
		return " [discountRate=" + discountRate + ", Customername=" + Customername + ", Customerid=" + Customerid
				+ ", amount=" + amount + "]";
	}

	@Override
	public void printPaymentInfo() {
		System.out.println("Cash = " + toString() +"\n"+ "Payment after discount = " + calculatePayment());

	}
	
}
